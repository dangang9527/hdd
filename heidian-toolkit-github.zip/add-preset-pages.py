"""Add 35 long-tail preset pages to the static toolkit.

Each page is a real, independent URL with its own title / body / FAQ / JSON-LD,
but it reuses a host tool's engine with parameters pre-filled. Preset pages are
kept OUT of TOOLS so the 62-tool catalogue, navigation and counters stay intact.

Usage:
  python add-preset-pages.py patch     # inject into app.js + css
  python add-preset-pages.py render   # prerender static html via Playwright
  python add-preset-pages.py sync     # sitemap / llms / entry links / sw
  python add-preset-pages.py verify   # browser checks
  python add-preset-pages.py all
"""
import os
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).parent
DIST = ROOT / 'dist'
APP = DIST / 'assets' / 'app.js'
CSS = DIST / 'assets' / 'ui-2026.css'
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')
ORIGIN = 'https://example.com'
TODAY = '2026-11-13'

# --------------------------------------------------------------------------
# Page data. Every entry carries its OWN usage / caveat copy so the 35 pages
# are not template clones with one number swapped.
# --------------------------------------------------------------------------
COMPRESS = [
    (20, '20KB', '老式报名系统、手写签名图、论坛极小头像等几乎不留余量的上传限制',
     '20KB 非常紧，通常需要把最长边一并缩到 400–600 px 并接受明显画质损失。若平台允许更大体积，不要为了凑数把证件照压到看不清。'),
    (50, '50KB', '考试报名照片、政务平台旧表单、二手平台头像',
     '建议按 45KB 左右留出缓冲：平台有时按 1000 字节换算 1KB，正好压到上限容易被判超限。'),
    (100, '100KB', '签证与护照照片、招聘网站头像、各类报名表上传',
     '100KB 是出现频率最高的证件照档位。人像建议保留 600 px 以上宽度，避免缩小后五官边缘发糊。'),
    (200, '200KB', '考研报名、政务服务网材料、学信网照片上传',
     '扫描件文字较多时，200KB 比 100KB 更能保住笔画边缘；压完请放大检查小字是否还能辨认。'),
    (300, '300KB', '部分事业单位报名系统、老旧 OA 附件、邮件签名图',
     '这个档位介于证件照与通用配图之间，画质余量较大；若系统只写「不超过 300KB」，压到 280KB 左右更稳妥。'),
    (500, '500KB', '邮件附件、电商主图、博客配图、扫描件归档',
     '500KB 画质接近原图，适合既要清晰又要控制附件大小的场景；纯色或线条图通常远小于这个上限。'),
    (1024, '1MB', '微信发送原图避免被二次压缩、社交平台高清图、作品预览',
     '1MB 档位很少需要动尺寸，主要靠编码质量达标；发微信前压到这一档，通常比直接发数 MB 原图更不容易被平台压糊。'),
    (2048, '2MB', '打印输出、摄影作品集、4K 壁纸投稿',
     '2MB 属于轻度压缩，细节保留较好。若要印刷，别同时把最长边调小，尺寸损失比编码损失更难挽回。'),
]

SIZES = [
    (64, 64, 'favicon 小图标、后台列表缩略图、极小的占位图', '64px 以下人脸和文字基本不可辨认，适合图标而非照片；做网站图标建议改用「Favicon 生成」一次出多尺寸。'),
    (100, 100, '论坛头像、评论区用户图、旧 CMS 的头像字段', '正方形输出会拉伸非方图；想保留原比例请先关闭「锁定宽高比」并只填一个方向，或用裁剪工具处理。'),
    (128, 128, '应用图标、旧版系统头像、桌面快捷方式图', '128px 是很多老系统的标准档；带细线的 Logo 缩到这个尺寸建议检查边缘是否糊成一团。'),
    (150, 150, '商品缩略图、后台列表图、二维码旁的小配图', '电商列表图常被二次裁切，导出后建议在真实列表页看一眼，确认主体没有被切掉。'),
    (200, 200, '个人资料头像、社交账号小图、店铺 Logo 位', '头像是圆形裁切时，重要内容尽量放在画面中央的正方形安全区内。'),
    (256, 256, 'App 图标、PWA 图标、部分社区平台的头像上限', '256px 兼顾清晰度与体积；需要同时出 16/32/48/180/192/512 一套图标时用「Favicon 生成」更省事。'),
    (360, 360, '移动端卡片图、公众号次条封面、聊天里转发的方图', '手机端一般按 2x 或 3x 渲染，360px 方图在高清屏上会略软，纯文字图建议适当加大。'),
    (400, 400, 'X / Twitter 头像、常见平台的方形头像规格', '平台上传后往往还会再压缩一次，导出时保留一点画质余量比压到极限更好。'),
    (500, 500, '电商方形主图、社媒方形卡片、商品对比图', '商品图若带白底，放大检查边缘有没有因重采样出现灰边或锯齿。'),
    (512, 512, '应用商店图标、PWA 与桌面图标、AI 工具常用输入尺寸', '512px 是很多图标规范的基准尺寸；需要透明背景时请保持 PNG 输出，不要勾成 JPG。'),
    (1024, 576, '16:9 视频缩略图、博客横幅、Google 商家资料封面', '非 16:9 的原图会被直接拉伸；先用裁剪工具切到 16:9 再定尺寸，观感会好很多。'),
    (1080, 1080, 'Instagram / 小红书方形帖、朋友圈方图', '社媒平台会二次压缩，文字建议离边缘留 80px 以上，避免被界面元素盖住。'),
    (1200, 1200, '电商详情方图、社媒方形大图、作品集方图', '从小于 1200px 的原图放大到这个尺寸不会变清晰，只是把像素插值变大。'),
    (1280, 720, '视频封面、PPT 封面、演示大屏配图、YouTube 缩略图', '16:9 是最常见的横版规格；封面上的标题字请在实际缩略图大小下预览一次。'),
    (1440, 2560, '9:16 手机壁纸、竖屏故事背景、锁屏图', '竖屏长图内存占用明显高于同宽度方图，批量处理时建议分批，别一次塞几十张。'),
    (1500, 500, 'X / Twitter 头图横幅、极宽的网页 Banner', '3:1 的极宽比例很难靠缩放得到，绝大多数原图都应先裁剪再定尺寸。'),
    (1500, 1000, '博客头图、3:2 横幅、新闻配图', '3:2 接近多数相机原生比例，缩放时变形最小，是横版配图比较安全的档位。'),
    (1500, 1500, '印刷方图、高分辨率社媒图、相册封面', '若用于印刷，还要单独确认 DPI；像素尺寸够了不代表物理尺寸够，可配合 DPI 工具核验。'),
    (2560, 1440, '2K 壁纸、演示大屏背景、双屏拼接素材', '2K 输出单张解码后内存占用较大，批量处理时留意浏览器标签页是否变卡。'),
    (3000, 3000, '印刷方图、高分辨率商品图、需要后期裁切余量的母版', '3000×3000 属于大图，原图分辨率不足时放大只会变糊；导出 PNG 体积也可能很大。'),
]

FORMATS = [
    ('png-to-jpg', 'PNG 转 JPG', 'png', 'jpg', 'PNG 截图、设计稿要上传只收 JPG 的表单或旧系统',
     'JPG 不支持透明，透明区域会按「透明区域填充」的颜色处理，默认白色。需要保留透明请改选 PNG 或 WebP。'),
    ('webp-to-jpg', 'WebP 转 JPG', 'webp', 'jpg', '网页上存下来的 WebP 图要在 Word、PPT 或旧看图软件里打开',
     'WebP 多为有损编码，转 JPG 会再编码一次；质量滑块调高一点可以减少二次损失，但无法还原已经丢掉的细节。'),
    ('to-jpg', '图片转 JPG', '', 'jpg', '把一批不同格式的图片统一成 JPG 交给只认 JPG 的系统',
     '浏览器能解码的输入格式都可以混着传，但 HEIC / HEIF 请走专门的「HEIC 照片转换」，这里不负责解码 HEVC。'),
    ('to-png', '图片转 PNG', '', 'png', 'Logo、截图、设计素材需要无损与透明通道',
     'PNG 是无损编码，质量滑块对它无效，体积可能比原图更大；透明输入可保留，JPG 输入不会凭空变出透明通道。'),
    ('to-webp', '图片转 WebP', '', 'webp', '给网页和小程序用，通常比 JPG 更省体积',
     'WebP 在很老的软件里打不开；上线前请确认目标环境支持，必要时保留一份 JPG 兜底。'),
    ('avif-to-jpg', 'AVIF 转 JPG', 'avif', 'jpg', 'AVIF 照片在旧版 Windows 看图工具、办公软件里打不开',
     'Chrome / Edge / Firefox 目前都能解码 AVIF，Safari 与老系统不一定；转 JPG 会重新有损编码，建议质量设为 88 以上。'),
    ('avif-to-png', 'AVIF 转 PNG', 'avif', 'png', 'AVIF 转无损 PNG，避免二次有损并保留透明',
     'PNG 不再二次损失，但也无法还原 AVIF 编码时已经丢掉的细节；体积往往会明显变大。'),
]

FMT_NAME = {'jpg': 'JPG', 'png': 'PNG', 'webp': 'WebP'}
HOST_NAME = {'image-compress': '图片压缩', 'image-resize': '调整图片尺寸', 'image-convert': '图片格式转换'}


def common_what(name, setup, use, host):
    return (f'这个页面把「{name}」单独做成一页，打开时参数已经预填好：{setup}。'
            f'它用的是本站「{host}」的同一套处理引擎，文件始终在浏览器内读取和重新编码，'
            f'不会上传到处理服务器。{use}。页面上的参数都可以继续手动改，不是只能按预设走。')


def common_details(setup_detail, tip):
    return [
        setup_detail,
        tip,
        '处理在浏览器本地完成后逐张下载或打包 ZIP；原文件不会被覆盖。画质与体积随图片内容变化很大，'
        '同一组参数对照片、截图、线条图的效果可能完全不同，请以实际下载结果为准。',
    ]


def build_pages():
    pages = []

    # --- group 1: compress to a target size ---
    for kb, label, use, tip in COMPRESS:
        slug = 'compress-to-' + label.lower()
        name = f'图片压缩到 {label}'
        setup = f'开启「按目标体积压缩」，目标填 {label}，输出格式预置为 JPG'
        qa = [
            {'q': f'压到 {label} 会不会很糊？',
             'a': f'取决于原图内容和尺寸。{tip} 建议先用一张代表性图片试压，放大检查人脸、文字边缘和暗部噪点，再决定要不要放宽体积或缩小尺寸。'},
            {'q': f'为什么有的图片压不到 {label}？',
             'a': '目标体积模式会在不超过上限的前提下自动找最高质量；如果连最低质量仍然超出，工具会明确提示。这时需要同时调小「最大边长」，或换一张更简单的图，不能靠质量参数解决。'},
            {'q': f'{label} 是按 1000 字节还是 1024 字节算？',
             'a': '工具内部按 1024 字节 = 1KB 计算。部分平台按 1000 字节换算，卡在上限时容易超一点，所以建议留出 5%–10% 的余量。'},
            {'q': f'压到 {label} 时还能输出 PNG 吗？',
             'a': f'不能直接按目标体积压：PNG 是无损编码，没有质量参数可以按比例缩小体积。要 {label} 以内请保持预置的 JPG，或改用 WebP；确实需要 PNG 时只能靠缩小尺寸间接减体积。'},
        ]
        pages.append(dict(
            slug=slug, host='image-compress', name=name,
            desc=f'把 JPG / PNG / WebP 图片压缩到 {label} 以内，自动找最高画质，支持批量与打包下载',
            title=f'图片压缩到 {label} 以内 — 在线免费、本地处理',
            tags=['压缩到' + label, label + '压缩', '照片压缩', '指定大小', '压缩', label.lower()],
            preset={'kind': 'target', 'kb': kb},
            seo=dict(
                what=common_what(name, setup, use, HOST_NAME['image-compress']),
                howto=[
                    '把要上传的图片拖进虚线框，可以一次选多张；页面已预填目标体积与 JPG 输出',
                    f'确认「目标体积」是 {label}，如需留缓冲可改小一点',
                    '照片类图片若提示压不下来，把「最大边长」从 1920 调小再试；文字截图优先保住尺寸',
                    '点「开始处理」，检查每张结果的实际体积与画质，再逐张下载或打包 ZIP',
                ],
                scenarios=[use, f'一次有多张图片都要满足 {label} 的上限，批量处理比逐个调质量省时间',
                           f'上传系统反复提示「文件不能超过 {label}」，需要一个能直接指定体积的压缩方式'],
                details=common_details(
                    '输入为浏览器可解码的 JPG / PNG / WebP；输出为 JPG（可在页面上改）。'
                    '目标体积模式会自动尝试不同编码质量，在不超过上限的前提下选最高的一档，'
                    '并在最低质量仍超标时给出提示，不会悄悄交付一个超限的文件。',
                    tip),
                bench=f'比较时用同一张原图，记录实际下载字节数，并放大检查细节；不要只看工具里显示的百分比。'
                      f'目标体积是上限不是目标画质，{label} 以内能保留多少细节取决于画面复杂度。',
                qa=qa,
            )))

    # --- group 2: exact pixel size ---
    for w, h, use, tip in SIZES:
        slug = f'resize-to-{w}x{h}'
        dim = f'{w}×{h}'
        name = f'图片调整为 {dim} 像素'
        setup = f'缩放方式为「按像素」，宽 {w} px、高 {h} px，并已关闭比例锁'
        square = w == h
        qa = [
            {'q': f'一定要正好 {dim} 吗？能保持原比例吗？',
             'a': f'默认输出精确 {dim}，非同比例的原图会被拉伸。想不失真，请先勾选「锁定宽高比」只填一个方向，'
                  f'或用「图片裁剪」先把画面切到目标比例再调整尺寸。'},
            {'q': f'小图放大到 {dim} 会变清晰吗？',
             'a': '不会。浏览器通过 Canvas 重采样，插值方式由浏览器决定，放大无法凭空生成细节。请从接近或大于目标尺寸的原图出发。'},
            {'q': f'批量导出 {dim} 时每张都会用同一组尺寸吗？',
             'a': f'会。{dim} 这组宽高对整批文件生效，结果文件名会带上实际输出宽高。若原图比例各不相同，建议先分组或逐批检查拉伸情况。'},
            {'q': f'输出 {dim} 时图片格式会变吗？',
             'a': f'默认「保持原格式」开启，PNG / JPG / WebP 按各自原格式导出 {dim}；关闭后统一输出 PNG。GIF 动图会被当作静态帧处理，不会保留动画。'},
        ]
        pages.append(dict(
            slug=slug, host='image-resize', name=name,
            desc=f'把图片精确调整为 {dim} 像素，支持批量、关闭比例锁与保持原格式输出',
            title=f'图片调整为 {dim} 像素 — 在线批量改尺寸',
            tags=[dim, f'{w}x{h}', '调整尺寸', '改像素', '缩放', 'resize'],
            preset={'kind': 'size', 'w': w, 'h': h},
            seo=dict(
                what=common_what(name, setup, use, HOST_NAME['image-resize']),
                howto=[
                    '把图片拖进虚线框，可以一次选多张；页面的宽高和比例锁已按本页规格预填',
                    f'核对「宽度 {w}」「高度 {h}」，确认「缩放方式」是按像素',
                    square and '方图会拉伸非正方形原图；不想变形就先开「锁定宽高比」或改用裁剪工具' or '注意目标比例与常见横竖版不同，必要时先裁剪再定尺寸',
                    '点「调整尺寸」，检查预览与下载结果的实际像素尺寸，再逐张下载或打包 ZIP',
                ],
                scenarios=[use, f'一批素材需要统一成 {dim}，避免后台或平台自动裁切造成版面错乱',
                           '表单或设计稿写死了像素要求，需要一个打开就是这组数值的页面'],
                details=common_details(
                    f'输入为浏览器可解码的 JPG / PNG / WebP / BMP 等图片，输出精确 {w} × {h} px。'
                    '比例锁默认关闭，宽高各自独立生效；原图比例与目标不一致时会直接拉伸，不是自动裁切或补边。',
                    tip),
                bench=f'导出后用看图工具核对实际像素是否为 {w} × {h}，并在最终展示尺寸下检查文字与边缘。'
                      '像素尺寸达标不等于观感达标，拉伸和重采样带来的变形要肉眼确认。',
                qa=qa,
            )))

    # --- group 3: directed format conversion ---
    for slug, name, src, fmt, use, tip in FORMATS:
        to = FMT_NAME[fmt]
        desc_head = f'把 {src.upper()} 等图片批量转换为 {to}' if src else f'把图片批量转换为 {to}'
        setup = f'「目标格式」预置为 {to}，质量 88%，透明区域默认填白'
        input_hint = f'把 {src.upper()} 等图片拖进虚线框' if src else '把图片拖进虚线框'
        qa = [
            {'q': f'{name} 会损失画质吗？',
             'a': ('JPG / WebP 按所选质量重新编码，会叠加一次有损损失，建议从原图处理并调高质量；'
                   'PNG 无损，但也无法还原输入中已丢失的细节。' if fmt != 'png' else
                   'PNG 使用无损编码，不会因这次转换再丢像素，但不能还原输入本身已经损失的内容，也不保证保留原文件元数据。')},
            {'q': f'{name} 之后透明背景还在吗？',
             'a': f'PNG 与 WebP 保留透明通道；JPG 不支持透明，会按「透明区域填充」的颜色处理，默认白色。本页预置 {to}，需要透明请改选支持透明的格式。'},
            {'q': f'{name} 支持 GIF 动图或 HEIC 吗？',
             'a': 'GIF 只会取解码后的静态画面，不保留动画；HEIC / HEIF 请用「HEIC 照片转换」，本页不加载 HEVC 解码引擎。需要动图请到「GIF 工具箱」。'},
            {'q': f'转成 {to} 后文件为什么反而更大？',
             'a': ('选 PNG 时很常见：无损编码通常比有损的 JPG / WebP 大。'
                   if fmt == 'png' else '重新编码不保证变小，尤其从已经有损压缩的图转成高质量档位时。可下调质量或换用 WebP。')},
        ]
        pages.append(dict(
            slug=slug, host='image-convert', name=name,
            desc=desc_head + ('，透明区域自动填白' if fmt == 'jpg' else '，保留透明通道') + '，画质可调',
            title=f'{name} — 在线批量转换、本地处理',
            tags=[x for x in [name, (src + '转' + fmt) if src else ('转' + fmt),
                              '格式转换', 'convert', fmt, src] if x],
            preset={'kind': 'format', 'fmt': fmt, 'from': src},
            seo=dict(
                what=common_what(name, setup, use, HOST_NAME['image-convert']),
                howto=[
                    f'{input_hint}，支持一次多张；页面已预选 {to}',
                    f'核对「目标格式」为 {to}；{("透明区域填充保留白色" if fmt == "jpg" else "需要透明时保持默认设置")}',
                    'JPG / WebP 可调质量，PNG 无需调；预览会给出按面积估算的原尺寸体积',
                    '点「开始转换」，检查下载文件的扩展名与实际打开效果',
                ],
                scenarios=[use, f'一次拿到多种格式的文件，需要统一成 {to} 再交给下游系统',
                           f'只想直接打开一个已选好 {to} 的转换页面，不想每次都手动切格式'],
                details=common_details(
                    '输入为浏览器可解码的图片（PNG / JPG / WebP / BMP / GIF / AVIF），'
                    f'输出 {to}。转换会把解码后的画面绘制到 Canvas 再重新编码，动画只保留静态帧，'
                    'EXIF 拍摄时间、GPS 等元数据默认不写入输出文件。',
                    tip),
                bench=f'用同一张原图比较转换前后的体积与放大后的细节；格式兼容性请在实际目标软件里验证，'
                      f'能在本站导出 {to} 不代表所有旧系统都能打开。',
                qa=qa,
            )))

    assert len(pages) == 35, len(pages)
    slugs = [p['slug'] for p in pages]
    assert len(set(slugs)) == 35, 'duplicate slug'
    return pages


PAGES = build_pages()

# --------------------------------------------------------------------------
# JS block appended just before boot(). Function declarations are hoisted to
# global scope so renderTool() can call variantNav().
# --------------------------------------------------------------------------
JS_BLOCK = """
/* ===== 长尾规格页：独立 URL + 独立 SEO，复用宿主工具引擎并预填参数 ===== */
const PRESET_PAGES = __PAGES_JSON__;

/** 按 label 文字找 Field 生成的 .opt，返回其中的表单控件。 */
function presetOpt(root, text) {
  return Array.from(root.querySelectorAll('div.opt')).find((el) => {
    const l = el.querySelector(':scope > label');
    return l && l.textContent.replace(/\\s+/g, '').startsWith(text);
  });
}
function presetSet(root, text, value) {
  const opt = presetOpt(root, text);
  const inp = opt && opt.querySelector('input, select');
  if (!inp) return false;
  if (inp.type === 'checkbox') {
    if (inp.checked !== Boolean(value)) {
      inp.checked = Boolean(value);
      inp.dispatchEvent(new Event('change', { bubbles: true }));
    }
  } else {
    inp.value = String(value);
    inp.dispatchEvent(new Event('input', { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
  }
  return true;
}
function applyVariantPreset(root, v) {
  const p = v.preset;
  if (p.kind === 'target') {
    presetSet(root, '按目标体积压缩', true);
    presetSet(root, '目标体积', p.kb);
    presetSet(root, '输出格式', 'jpg');
  } else if (p.kind === 'size') {
    presetSet(root, '锁定宽高比', false);
    presetSet(root, '宽度', p.w);
    presetSet(root, '高度', p.h);
  } else if (p.kind === 'format') {
    presetSet(root, '目标格式', p.fmt);
    if (p.fmt === 'jpg') presetSet(root, '透明区域填充', '#ffffff');
  }
}

/** 规格页内链：宿主工具页列出全部规格，规格页可回到完整参数版。 */
function variantNav(t) {
  const hostId = t.variantOf || t.id;
  const list = VARIANTS.filter((v) => v.variantOf === hostId);
  if (!list.length) return null;
  const host = toolById(hostId);
  return h('div.variant-nav', null,
    h('div.sec-hd', null, h('h2', { style: { fontSize: '15px' } }, '常用规格')),
    h('p', { class: 'hint' }, t.variantOf
      ? '本页已预填对应参数，仍可在上方手动调整；需要完整控制请打开基础工具。'
      : '下面是常见的目标规格，点进去参数已经预填好，也能在本页直接改。'),
    h('div.chips', null, list.map((v) => h('a', {
      class: v.id === t.id ? 'chip on' : 'chip', href: toolUrl(v),
      'aria-current': v.id === t.id ? 'page' : null,
    }, v.name))),
    t.variantOf && host ? h('a', { class: 'btn btn-ghost variant-back', href: toolUrl(host) },
      '打开' + host.name + '（完整参数）') : null);
}

(function registerPresetPages() {
  for (const v of PRESET_PAGES) {
    const host = TOOLS.find((t) => t.id === v.host);
    if (!host) { console.warn('[preset] missing host', v.host); continue; }
    const t = {
      ...host,
      id: 'image-' + v.slug,
      slug: v.slug,
      path: '/image/' + v.slug + '/',
      name: v.name,
      desc: v.desc,
      tags: Array.from(new Set([...(host.tags || []), ...(v.tags || [])])),
      faq: [],
      variantOf: host.id,
      preset: v.preset,
      hidden: true,
      priority: 900,
      mount(root, ctx) {
        host.mount(root, v.preset.kind === 'size'
          ? { ...ctx, fixedSize: [v.preset.w, v.preset.h] } : ctx);
        try { applyVariantPreset(root, v); }
        catch (e) { console.warn('[preset] apply failed', v.slug, e); }
      },
    };
    VARIANTS.push(t);
    SEO_CONTENT[t.id] = v.seo;
    TOOL_TITLE_OVERRIDE[t.id] = v.title;
  }
})();

"""


def patch():
    s = APP.read_text(encoding='utf-8')
    assert 'PRESET_PAGES' not in s, 'already patched'

    def rep(old, new):
        nonlocal s
        assert s.count(old) == 1, (s.count(old), old[:80])
        s = s.replace(old, new, 1)

    rep('const TOOLS = [];\nlet routeCleanup = null;',
        'const TOOLS = [];\nconst VARIANTS = [];\nlet routeCleanup = null;')

    rep("const toolById = (id) => TOOLS.find((t) => t.id === id);\nconst toolByPath = (p) => TOOLS.find((t) => t.path === p);",
        "const toolById = (id) => TOOLS.find((t) => t.id === id) || VARIANTS.find((t) => t.id === id);\n"
        "const toolByPath = (p) => TOOLS.find((t) => t.path === p) || VARIANTS.find((t) => t.path === p);")

    rep('          if (mode.get() === \'px\') { w.input.value = natW; hh.input.value = natH; }',
        '          if (mode.get() === \'px\') {\n'
        '            w.input.value = ctx.fixedSize ? ctx.fixedSize[0] : natW;\n'
        '            hh.input.value = ctx.fixedSize ? ctx.fixedSize[1] : natH;\n'
        '          }')

    rep('    body,\n    docBlock(t),\n    relatedBlock(t),\n    siblingNav(t)));',
        '    body,\n    docBlock(t),\n    variantNav(t),\n    relatedBlock(t),\n    siblingNav(t)));')

    block = JS_BLOCK.replace('__PAGES_JSON__', json.dumps(PAGES, ensure_ascii=False, indent=2))
    at = s.rfind('boot();')
    assert at > 0 and s[at:].strip() == 'boot();', 'boot() not at end'
    s = s[:at] + block + s[at:]
    APP.write_text(s, encoding='utf-8')
    print('patched app.js:', len(s), 'bytes,', len(PAGES), 'preset pages')

    c = CSS.read_text(encoding='utf-8')
    if '.variant-nav' not in c:
        c += """
/* 长尾规格页：宿主工具页与规格页共用的紧凑入口 */
.variant-nav{margin-top:26px}
.variant-nav .chips{display:flex;flex-wrap:wrap;gap:8px;margin:12px 0 0}
.variant-nav .chip{font-size:12.5px;padding:6px 11px}
.variant-nav .chip.on{border-color:var(--accent,#b64f30);color:var(--accent,#b64f30);font-weight:500}
.variant-nav .variant-back{margin-top:14px}
"""
        CSS.write_text(c, encoding='utf-8')
        print('patched ui-2026.css')


# --------------------------------------------------------------------------
SHELL = ROOT / '.shell-convert.html'
if not SHELL.exists():
    SHELL = ROOT / 'preset-shell-template.html'


def normalize_head(html, page_path):
    """Make prerendered head deployable: restore <head> tags and drop the
    localhost URLs that ui-2026.js writes through DOM .href (absolute)."""
    depth = len(page_path.relative_to(DIST).parts) - 1
    prefix = '../' * depth
    html = html.replace('http://127.0.0.1:8765/', prefix)
    if '<head>' not in html[:1500]:
        m = re.search(r'<html[^>]*>', html)
        html = html[:m.end()] + '\n<head>' + html[m.end():]
        b = re.search(r'<body[^>]*>', html)
        html = html[:b.start()] + '</head>\n' + html[b.start():]
    return html


def fixall():
    fixed = 0
    for p in sorted(DIST.rglob('index.html')):
        s = p.read_text(encoding='utf-8')
        n = normalize_head(s, p)
        if n != s:
            p.write_text(n, encoding='utf-8')
            fixed += 1
    print('normalized head in', fixed, 'html files')


def render():
    from playwright.sync_api import sync_playwright
    dist = DIST
    base = SHELL.read_text(encoding='utf-8')
    assert '__STATIC__' in base, 'static shell missing __STATIC__ flag'
    head_start = base.index('<head>')
    head_open_end = base.index('>', head_start) + 1
    head_close = base.index('</head>', head_open_end)
    main_start = base.index('<main id="app"')
    main_end = base.index('</main>') + len('</main>')

    hosts = ['/image/compress/', '/image/resize/', '/image/convert/']
    paths = hosts + ['/image/' + p['slug'] + '/' for p in PAGES]

    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto(BASE + '/image/convert/')
        page.wait_for_selector('.tool-hd h1')
        total = page.evaluate('VARIANTS.length')
        assert total == 35, total
        assert page.evaluate('TOOLS.length') == 62
        for i, path in enumerate(paths, 1):
            data = page.evaluate("""(p) => {
              history.pushState(null, '', p); route();
              return {
                h1: document.querySelector('.tool-hd h1')?.textContent || '',
                head: document.head.innerHTML,
                main: document.querySelector('#app').outerHTML,
                canonical: document.querySelector('link[rel="canonical"]')?.href || '',
                title: document.title
              };
            }""", path)
            expected = ('图片格式转换' if path.endswith('/convert/')
                        else '图片压缩' if path.endswith('/compress/')
                        else '调整图片尺寸' if path.endswith('/resize/')
                        else next(p['name'] for p in PAGES if '/image/' + p['slug'] + '/' == path))
            assert data['h1'] == expected, (path, data['h1'], expected)
            assert data['canonical'] == ORIGIN + path, (path, data['canonical'])
            assert 'FAQPage' in data['head'] and 'HowTo' in data['head'], path
            assert '/image/' in data['main']
            html = (base[:head_open_end] + data['head'] + '</head>'
                    + base[head_close + len('</head>'):main_start] + data['main'] + base[main_end:])
            out = dist / path.strip('/') / 'index.html'
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(normalize_head(html, out), encoding='utf-8')
            if i % 10 == 0 or i == len(paths):
                print(f'  rendered {i}/{len(paths)}')
        browser.close()
    assert not errors, errors[:5]
    print('prerendered', len(paths), 'pages with no page errors')


# --------------------------------------------------------------------------
def full_sections():
    full = (DIST / 'llms-full.txt').read_text(encoding='utf-8')
    marker = '\n## 图片压缩到 20KB\n'
    if marker in full:
        full = full[:full.index(marker)]
    full = full.rstrip() + '\n\n'
    for p in PAGES:
        seo = p['seo']
        sec = f'## {p["name"]}\n\nURL: {ORIGIN}/image/{p["slug"]}/\n分类: 图片（规格页）\n更新日期: {TODAY}\n\n{p["desc"]}\n\n'
        sec += '### 这个工具做什么\n\n' + seo['what'] + '\n\n'
        sec += '### 怎么用\n\n' + ''.join(f'{i}. {x}\n' for i, x in enumerate(seo['howto'], 1)) + '\n'
        sec += '### 适用场景\n\n' + ''.join('- ' + x + '\n' for x in seo['scenarios']) + '\n'
        sec += '### 输入输出与限制\n\n' + ''.join(x + '\n\n' for x in seo['details'])
        sec += '### 常见问题\n\n' + ''.join('#### ' + q['q'] + '\n\n' + q['a'] + '\n\n' for q in seo['qa'])
        sec += f'### 相关工具\n\n- [{HOST_NAME[p["host"]]}]({ORIGIN}/image/{p["host"].split("-", 1)[1]}/)：完整参数版\n\n'
        full += sec
    return full


def refine():
    """Refresh only the preset data table + llms-full, after copy tweaks."""
    s = APP.read_text(encoding='utf-8')
    start = s.index('const PRESET_PAGES = ')
    end = s.index(';\n\n/** 按 label', start)
    s = s[:start] + 'const PRESET_PAGES = ' + json.dumps(PAGES, ensure_ascii=False, indent=2) + s[end:]
    APP.write_text(s, encoding='utf-8')
    (DIST / 'llms-full.txt').write_text(full_sections(), encoding='utf-8')
    print('refined preset copy in app.js + llms-full.txt')


# --------------------------------------------------------------------------
def sync():
    # sitemap
    sm = DIST / 'sitemap.xml'
    xml = sm.read_text(encoding='utf-8')
    anchor = '</urlset>'
    assert anchor in xml
    add = ''
    for p in PAGES:
        url = f'{ORIGIN}/image/{p["slug"]}/'
        assert url not in xml, url
        add += f'  <url>\n    <loc>{url}</loc>\n    <lastmod>{TODAY}</lastmod>\n  </url>\n'
    sm.write_text(xml.replace(anchor, add + anchor, 1), encoding='utf-8')
    print('sitemap: +', len(PAGES), 'urls')

    # llms.txt
    lt = DIST / 'llms.txt'
    txt = lt.read_text(encoding='utf-8')
    assert '常用规格' not in txt
    txt = txt.rstrip() + '\n\n### 常用规格页（35 个，参数已预填）\n\n'
    for p in PAGES:
        txt += f'- [{p["name"]}]({ORIGIN}/image/{p["slug"]}/)：{p["desc"]}\n'
    lt.write_text(txt, encoding='utf-8')

    # llms-full.txt
    lf = DIST / 'llms-full.txt'
    lf.write_text(full_sections(), encoding='utf-8')
    print('llms.txt / llms-full.txt updated')

    # entry links on home + category pages (static html only, no runtime change)
    hot = [
        ('/image/compress-to-100kb/', '压缩到 100KB'),
        ('/image/compress-to-1mb/', '压缩到 1MB'),
        ('/image/resize-to-512x512/', '调整为 512×512'),
        ('/image/resize-to-1280x720/', '调整为 1280×720'),
        ('/image/png-to-jpg/', 'PNG 转 JPG'),
        ('/image/to-webp/', '图片转 WebP'),
    ]
    links = ''.join(f'<a class="chip" href="{u}">{n}</a>' for u, n in hot)
    for rel in ['index.html', 'image/index.html']:
        f = DIST / rel
        s = f.read_text(encoding='utf-8')
        assert '常用规格' not in s
        # Put it OUTSIDE <main id="app">: route() clears #app on boot, so an
        # inner block would flash and disappear for real visitors.
        block = ('<section class="wrap variant-nav"><div class="sec-hd"><h2 style="font-size:15px">常用规格</h2></div>'
                 '<p class="hint">这些页面已经预填好参数，打开即可用。</p><div class="chips">'
                 + links + '</div></section>')
        s = s.replace('</main>', '</main>' + block, 1)
        f.write_text(s, encoding='utf-8')
    print('home + category entry links added')

    # service worker cache bust
    sw = DIST / 'sw.js'
    s = sw.read_text(encoding='utf-8')
    m = re.search(r"['\"]([\w-]*v\d+)['\"]", s)
    old = m.group(1) if m else ''
    if old:
        s = s.replace(old, '2026-11-13-preset-v1', 1)
    else:
        raise AssertionError('sw cache version not found')
    sw.write_text(s, encoding='utf-8')
    print('sw cache:', old, '->', '2026-11-13-preset-v1')


# --------------------------------------------------------------------------
def verify():
    from playwright.sync_api import sync_playwright
    results = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
        page = browser.new_page(viewport={'width': 1280, 'height': 900})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        for group, sample in [
            ('compress', PAGES[0:2] + PAGES[6:8]),
            ('resize', [PAGES[8], PAGES[17], PAGES[27]]),
            ('format', PAGES[-2:]),
        ]:
            for p in sample:
                path = f'/image/{p["slug"]}/'
                page.goto(BASE + path)
                page.wait_for_selector('.tool-hd h1')
                r = page.evaluate("""() => ({
                  h1: document.querySelector('.tool-hd h1')?.textContent,
                  title: document.title,
                  canonical: document.querySelector('link[rel="canonical"]')?.href,
                  desc: document.querySelector('meta[name=description]')?.content,
                  schema: document.querySelectorAll('script[type="application/ld+json"]').length,
                  chips: document.querySelectorAll('.variant-nav .chip').length,
                  faq: document.querySelectorAll('.doc details').length,
                  hasDrop: !!document.querySelector('.dropzone, [data-drop], .dz'),
                  opts: document.querySelectorAll('div.opt').length,
                  total: TOOLS.length, variants: VARIANTS.length
                })""")
                assert r['h1'] == p['name'], (path, r['h1'])
                assert r['canonical'] == ORIGIN + path, (path, r['canonical'])
                assert 'FAQPage' in page.content() and 'HowTo' in page.content(), path
                assert r['chips'] >= 7, (path, r['chips'])
                assert r['faq'] >= 3, (path, r['faq'])
                assert r['total'] == 62 and r['variants'] == 35, r
                assert r['opts'] >= 3, (path, r['opts'])
                # preset really applied
                if p['preset']['kind'] == 'target':
                    val = page.evaluate("""() => {
                      const o = [...document.querySelectorAll('div.opt')].find(e => e.querySelector(':scope > label')?.textContent.trim().startsWith('目标体积'));
                      const t = [...document.querySelectorAll('div.opt')].find(e => e.querySelector(':scope > label')?.textContent.startsWith('按目标体积压缩'));
                      const f = [...document.querySelectorAll('div.opt')].find(e => e.querySelector(':scope > label')?.textContent.startsWith('输出格式'));
                      return [o?.querySelector('input')?.value, t?.querySelector('input')?.checked, f?.querySelector('select')?.value];
                    }""")
                    assert val == [str(p['preset']['kb']), True, 'jpg'], (path, val)
                elif p['preset']['kind'] == 'size':
                    val = page.evaluate("""() => {
                      const g = (t) => [...document.querySelectorAll('div.opt')].find(e => e.querySelector(':scope > label')?.textContent.startsWith(t))?.querySelector('input');
                      return [g('宽度')?.value, g('高度')?.value, g('锁定宽高比')?.checked];
                    }""")
                    assert val == [str(p['preset']['w']), str(p['preset']['h']), False], (path, val)
                else:
                    val = page.evaluate("""() => {
                      const o = [...document.querySelectorAll('div.opt')].find(e => e.querySelector(':scope > label')?.textContent.startsWith('目标格式'));
                      return o?.querySelector('select')?.value;
                    }""")
                    assert val == p['preset']['fmt'], (path, val)
                results.append((path, r['title'], 'preset=ok'))
        # host pages keep their catalogue + gain the spec nav
        for path, count in [('/image/compress/', 8), ('/image/resize/', 20), ('/image/convert/', 7)]:
            page.goto(BASE + path)
            page.wait_for_selector('.tool-hd h1')
            n = page.locator('.variant-nav .chip').count()
            assert n == count, (path, n, count)
            results.append((path, 'host', f'chips={n}'))
        # global surfaces
        home = (DIST / 'index.html').read_text(encoding='utf-8')
        assert home.count('class="chip"') >= 12
        sm = (DIST / 'sitemap.xml').read_text(encoding='utf-8')
        assert all(f'/image/{p["slug"]}/' in sm for p in PAGES)
        assert sm.count('<loc>') == 69 + 35, sm.count('<loc>')
        # home/category spec entry must survive route() clearing #app
        for path in ['/', '/image/']:
            page.goto(BASE + path)
            page.wait_for_selector('#app')
            page.wait_for_timeout(250)
            assert page.locator('section.variant-nav .chip').count() == 6, path
        results.append(('/ + /image/', 'entry links', 'survive boot'))
        browser.close()
    pages = sorted(DIST.rglob('index.html'))
    bad_head = [str(p) for p in pages if '<head>' not in p.read_text(encoding='utf-8')[:1500]]
    bad_url = [str(p) for p in pages if '127.0.0.1:8765' in p.read_text(encoding='utf-8')]
    assert not bad_head, bad_head[:5]
    assert not bad_url, bad_url[:5]
    print('  all', len(pages), 'html pages: <head> ok, no localhost urls')
    assert not errors, errors[:5]
    for row in results:
        print('  OK', row[0], '|', row[1][:40], '|', row[2])
    print('verified', len(results), 'pages, no console errors')


if __name__ == '__main__':
    steps = sys.argv[1:] or ['all']
    if 'all' in steps:
        steps = ['patch', 'render', 'fixall', 'sync', 'verify']
    for step in steps:
        print('===', step, '===')
        {'patch': patch, 'refine': refine, 'render': render, 'fixall': fixall,
         'sync': sync, 'verify': verify}[step]()
