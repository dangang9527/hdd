"""Responsive + visual smoke check for the new preset pages."""
import os
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')
PAGES = ['/image/compress-to-100kb/', '/image/resize-to-1280x720/', '/image/png-to-jpg/']
WIDTHS = [(1440, 900), (768, 1024), (390, 844)]
report = {'checks': [], 'errors': []}

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
    for width, height in WIDTHS:
        ctx = browser.new_context(viewport={'width': width, 'height': height},
                                  device_scale_factor=1, service_workers='block')
        page = ctx.new_page()
        page.on('pageerror', lambda e: report['errors'].append(str(e)))
        for path in PAGES:
            page.goto(BASE + path)
            page.wait_for_selector('.variant-nav .chip')
            page.wait_for_timeout(200)
            m = page.evaluate("""() => ({
              sw: document.documentElement.scrollWidth,
              iw: window.innerWidth,
              chips: document.querySelectorAll('.variant-nav .chip').length,
              btn: (() => { const b=document.querySelector('[data-primary-actions] button');
                            return b ? Math.round(b.getBoundingClientRect().height) : 0; })()
            })""")
            assert m['sw'] <= m['iw'] + 1, (path, width, m)
            assert m['chips'] >= 7, (path, m)
            report['checks'].append({'path': path, 'width': width, **m})
            if path == PAGES[0] and width in (1440, 390):
                tag = 'desktop' if width == 1440 else 'mobile'
                page.screenshot(path=str(ROOT / f'preset-{tag}.png'), full_page=(width == 390))
        ctx.close()
    browser.close()

assert not report['errors'], report['errors'][:5]
(ROOT / 'preset-visual-verification.json').write_text(
    json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PASS', len(report['checks']), 'responsive checks, 0 overflows, 2 screenshots')
