from pathlib import Path as _P
if not (_P(__file__).parent / '.test-fixtures').exists():
    raise SystemExit('缺少测试素材：请在仓库根目录创建 .test-fixtures/ 并放入测试图片；该目录不随仓库分发，见 README「测试」章节。')
import os
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')
import os
import base64, json, time
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
heic = base64.b64encode((ROOT / '.test-fixtures' / 'example.heic').read_bytes()).decode()
report = {'cases': [], 'errors': [], 'console': []}

with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
    ctx = browser.new_context(viewport={'width': 1440, 'height': 1000}, accept_downloads=True)
    page = ctx.new_page()
    page.on('pageerror', lambda e: report['errors'].append(str(e)))
    page.on('console', lambda m: report['console'].append(m.text) if m.type == 'error' else None)

    page.goto(BASE + '/')
    page.wait_for_selector('.ui-sidebar')
    assert '/image/heic/' in page.locator('#cat-image').inner_html()
    report['cases'].append('Homepage shows the HEIC card and 21 image tools')

    page.locator('a.card[href="/image/heic/"]').click()
    page.wait_for_selector('.tool-hd h1')
    assert page.locator('.tool-hd h1').inner_text() == 'HEIC 照片转换'
    report['cases'].append('SPA navigation from the homepage lands on the tool')

    def run(name, fmt='JPG', edge='0', q=None, extra=None):
        with page.expect_file_chooser() as fc:
            page.locator('.dz').first.click()
        fc.value.set_files({'name': name, 'mimeType': 'image/heic', 'buffer': base64.b64decode(heic)})
        page.locator('select').first.select_option(fmt.lower())
        if q:
            page.locator('input[type=range]').first.evaluate(
                "(el,v)=>{el.value=v;el.dispatchEvent(new Event('input',{bubbles:true}))}", q)
        if edge != '0':
            page.locator('select').nth(1).select_option(edge)
        started = time.time()
        page.get_by_role('button', name='转换所选照片', exact=True).click()
        page.locator('.workspace-results.on').wait_for(timeout=60000)
        return time.time() - started

    first = run('IMG_4821.heic')
    page.locator('.workspace-results').inner_text()
    assert page.locator('.result-i').count() == 1
    note = page.locator('.workspace-results .file-meta').first.inner_text()
    assert '1440×960' in note, note
    report['cases'].append(f'JPG conversion of real iPhone HEIC works (first run incl. engine download: {first:.1f}s)')

    with page.expect_download() as dl:
        page.get_by_role('button', name='下载', exact=True).click()
    assert dl.value.suggested_filename == 'IMG_4821.jpg'
    report['cases'].append('Downloaded file keeps the base name with .jpg suffix')

    page.goto(BASE + '/image/heic/')
    page.wait_for_selector('.tool-hd h1')
    run('IMG_0002.HEIC', fmt='PNG')
    assert page.locator('.workspace-results .file-name').first.inner_text().lower().endswith('.png'), page.locator('.workspace-results .file-name').first.inner_text()
    report['cases'].append('PNG output works')

    page.goto(BASE + '/image/heic/')
    page.wait_for_selector('.tool-hd h1')
    fast = run('IMG_0003.heic', fmt='WEBP', edge='1280')
    assert '1280×' in page.locator('.workspace-results .file-meta').first.inner_text()
    assert fast < first, (fast, first)
    report['cases'].append(f'WebP + 1280px resize works and the engine is cached ({fast:.1f}s)')

    # batch of two
    page.goto(BASE + '/image/heic/')
    page.wait_for_selector('.tool-hd h1')
    with page.expect_file_chooser() as fc:
        page.locator('.dz').first.click()
    fc.value.set_files([
        {'name': 'batch-a.heic', 'mimeType': 'image/heic', 'buffer': base64.b64decode(heic)},
        {'name': 'batch-b.heic', 'mimeType': 'image/heic', 'buffer': base64.b64decode(heic)},
    ])
    page.get_by_role('button', name='转换所选照片', exact=True).click()
    page.locator('.workspace-results.on').wait_for(timeout=90000)
    assert page.locator('.result-i').count() >= 3  # two rows + zip row
    assert '2 个文件' in page.locator('.workspace-results').inner_text()
    with page.expect_download() as z:
        page.get_by_role('button', name='下载 ZIP').click()
    assert z.value.suggested_filename.endswith('.zip')
    report['cases'].append('Batch of two converts and packs into a ZIP')

    # a fake .heic must fail clearly, not silently
    page.goto(BASE + '/image/heic/')
    page.wait_for_selector('.tool-hd h1')
    with page.expect_file_chooser() as fc:
        page.locator('.dz').first.click()
    fc.value.set_files({'name': 'not-really.heic', 'mimeType': 'image/heic',
                        'buffer': b'this is definitely not a heif container' * 40})
    page.get_by_role('button', name='转换所选照片', exact=True).click()
    page.locator('.errbox.on').wait_for(timeout=60000)
    msg = page.locator('.errbox').inner_text()
    assert '失败' in msg or '不是有效' in msg, msg
    report['cases'].append('A renamed non-HEIC file fails with an explicit message: ' + msg.strip()[:60])

    # generic converter points HEIC users to the new page
    page.goto(BASE + '/image/convert/')
    page.wait_for_selector('.tool-hd h1')
    with page.expect_file_chooser() as fc:
        page.locator('.dz').first.click()
    fc.value.set_files({'name': 'IMG_9.heic', 'mimeType': 'image/heic', 'buffer': base64.b64decode(heic)})
    page.wait_for_timeout(400)
    body = page.locator('body').inner_text()
    assert 'HEIC 照片转换' in body
    report['cases'].append('Generic converter points HEIC uploads to the dedicated tool')

    # mobile layout + search
    page.set_viewport_size({'width': 390, 'height': 844})
    page.goto(BASE + '/image/heic/')
    page.wait_for_selector('.tool-hd h1')
    m = page.evaluate('({w:innerWidth,sw:document.documentElement.scrollWidth,btn:document.querySelector(".btn-lg").getBoundingClientRect().height})')
    assert m['sw'] <= 390 and m['btn'] >= 44, m
    report['cases'].append(f'Mobile layout has no horizontal overflow and a {m["btn"]:.0f}px primary button')
    page.set_viewport_size({'width': 1440, 'height': 1000})
    page.goto(BASE + '/')
    page.locator('#searchBtn').click()
    page.locator('#searchInput').fill('heic')
    page.wait_for_timeout(200)
    assert 'HEIC' in page.locator('#searchList').inner_text()
    report['cases'].append('Search finds the tool by "heic"')
    browser.close()

report['summary'] = {'cases': len(report['cases']), 'page_errors': len(report['errors']),
                     'console_errors': len(report['console'])}
assert not report['errors'], report['errors']
(ROOT / 'heic-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report['summary'], ensure_ascii=False))
for c in report['cases']:
    print(' -', c)
print('console errors:', report['console'][:4])
