/* ==========================================================================
   B 档新增工具（v7）· 12 个纯前端能力，零外部依赖
   全部复用现有 Field / DropZone / toolUI / Result / encodeGif / SEO_CONTENT。
   设计约束：逐张解码 → 处理 → 导出 → 立刻释放画布，避免 HEIC 那类 OOM 回归。
   ========================================================================== */
(function registerBTools() {
  'use strict';

  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const bHex = (s, d) => {
    const t = String(s || '').trim().replace(/^#/, '');
    return /^[0-9a-fA-F]{6}$/.test(t) ? '#' + t : d;
  };
  const bOut = (name, suffix, ext) => (baseOf(name || 'image') + '-' + suffix + '.' + ext);
  const bEven = (n) => Math.max(2, Math.round(n / 2) * 2);   // GIF / 视频编码器更喜欢偶数边长

  /** 圆角路径：优先原生 roundRect，旧浏览器手写 arcTo 回退 */
  function bRoundRect(ctx, x, y, w, h, r) {
    r = clamp(r, 0, Math.min(w, h) / 2);
    ctx.beginPath();
    if (typeof ctx.roundRect === 'function') { ctx.roundRect(x, y, w, h, r); return; }
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /** 自定义颜色控件：套现有 .opt 结构，样式与 Field 一致 */
  function bColor(label, value, repaint) {
    const inp = h('input', { type: 'color', value, 'aria-label': label, oninput: repaint });
    const el = h('div.opt', null, h('label', null, label), inp);
    return { el, get: () => inp.value, input: inp };
  }

  /** 分段控件默认 nowrap 不换行，选项多的页面在窄屏会撑出横向滚动条 */
  function bSeg(opts) {
    const f = Field.seg(opts);
    f.el.classList.add('b-seg-wrap');
    return f;
  }

  /**
   * 通用「图片效果」挂载器。
   * cfg = {
   *   fields(repaint) -> { key: FieldLike },
   *   draw(ctx, src, v, W, H)       绘制到目标画布
   *   outputSize?(w, h, v) -> [W,H] 默认同尺寸
   *   before?(ctx, W, H, v)         画背景等
   *   formats, defaultFmt, previewTitle, note, fileName(v)
   * }
   */
  function bImageMount(cfg) {
    return function mount(root, ctx) {
      const pv = previewBox({ title: cfg.previewTitle || '效果预览', emptyText: '先拖入图片，再调整下方参数查看效果' });
      let src = null, thumb = null, srcName = 'image';
      let f = null;

      function repaint() {
        if (!f || !thumb) return;
        const v = Object.fromEntries(Object.entries(f).map(([k, x]) => [k, x.get()]));
        // 预览是缩略图，几何类参数（圆角/边框/留白）要按同一比例缩小才不会失真
        v.__k = src ? thumb.width / src.width : 1;
        const [pw, ph] = cfg.outputSize
          ? cfg.outputSize(thumb.width, thumb.height, v.__k, v) : [thumb.width, thumb.height];
        const { canvas, ctx: c } = newCanvas(pw, ph);
        cfg.before?.(c, canvas.width, canvas.height, v);
        cfg.draw(c, thumb, v, canvas.width, canvas.height);
        canvas.style.maxWidth = '100%';
        pv.set(canvas, src ? `${src.width} × ${src.height} · 预览为缩略图，导出按所选尺寸` : '');
      }

      f = cfg.fields(repaint);

      const fmt = Field.select({
        label: '输出格式', value: cfg.defaultFmt || 'png',
        options: (cfg.formats || ['png', 'jpg', 'webp']).map((x) => ({
          value: x,
          label: x === 'png' ? 'PNG（无损 / 透明）' : x === 'jpg' ? 'JPG（体积小）' : x === 'webp' ? 'WebP（体积小）' : x.toUpperCase(),
        })),
      });
      const edge = Field.select({
        label: '输出尺寸', value: '0',
        options: [
          { value: '0', label: '保持原尺寸' },
          { value: '1920', label: '长边 1920 px' },
          { value: '1280', label: '长边 1280 px' },
          { value: '800', label: '长边 800 px' },
        ],
        hint: '大图或批量处理时建议缩小，可显著降低内存占用',
      });

      const dz = DropZone({
        accept: 'image/*', multiple: true,
        title: '把图片拖到这里', sub: '支持 PNG / JPG / WebP，可一次选多张',
        async onFiles(files) {
          if (!files.length) { src = null; thumb = null; pv.clear(); return; }
          try {
            const bmp = await loadBitmap(files[0]);
            src = drawToCanvas(bmp, { maxEdge: 4096 });
            bmp.close?.();
            thumb = drawToCanvas(src, { maxEdge: 700 });
            srcName = files[0].name;
            repaint();
          } catch (e) {
            pv.clear();
            toast('预览失败：' + (e.message || e), 'err');
          }
        },
      });

      const ui = toolUI({
        zone: dz,
        opts: [...Object.values(f), fmt, edge],
        extraTop: pv.el,
        note: cfg.note ? h('div.hint', { style: { marginTop: '10px' } }, cfg.note) : null,
        cancelable: true,
        btnLabel: '开始处理',
        async onRun({ prog, res, signal }) {
          const files = dz.dz.get();
          if (!files.length) throw new Error('请先拖入至少一张图片');
          const v = Object.fromEntries(Object.entries(f).map(([k, x]) => [k, x.get()]));
          v.__k = 1;
          const out = [];
          const limit = Number(edge.get());
          for (let i = 0; i < files.length; i++) {
            if (signal.aborted) throw new DOMException('已取消', 'AbortError');
            prog.set((i / files.length) * 92, `处理 ${i + 1} / ${files.length}`);
            const file = files[i];
            const bmp = await loadBitmap(file);
            let w = bmp.width, hh = bmp.height;
            if (limit && Math.max(w, hh) > limit) {
              const k = limit / Math.max(w, hh);
              w = Math.max(1, Math.round(w * k)); hh = Math.max(1, Math.round(hh * k));
            }
            const source = drawToCanvas(bmp, { width: w, height: hh });
            bmp.close?.();
            const [ow, oh] = cfg.outputSize ? cfg.outputSize(w, hh, 1, v) : [w, hh];
            const { canvas, ctx: c } = newCanvas(ow, oh);
            cfg.before?.(c, ow, oh, v);
            cfg.draw(c, source, v, ow, oh);
            const ext = fmt.get();
            const blob = await exportCanvas(canvas, ext, 0.92);
            canvas.width = 0; canvas.height = 0;
            source.width = 0; source.height = 0;
            out.push({
              name: bOut(file.name, cfg.fileName ? cfg.fileName(v) : '效果', ext),
              blob,
              note: `${ow} × ${oh} · ${fmtBytes(blob.size)}`,
            });
            if (i % 4 === 3) await sleep(0);
          }
          prog.set(100);
          res.show(out, {
            title: `✓ 处理完成，共 ${out.length} 张`,
            summary: `输出 ${fmt.get().toUpperCase()} · 共 ${fmtBytes(out.reduce((s, x) => s + x.blob.size, 0))}`,
          });
          setTimeout(() => prog.hide(), 400);
        },
      });

      root.appendChild(ui.panel);
      _pageCleanups.add(() => { src = null; thumb = null; pv.clear(); });
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    };
  }

  /* ------------------------------------------------------------------ *
   * 1 / 图片调色与滤镜
   * ------------------------------------------------------------------ */
  tool({
    id: 'image-adjust', cat: 'image', name: '图片调色与滤镜', ico: 'image', priority: 20,
    desc: '亮度、对比度、饱和度、色相与模糊，附带黑白 / 复古 / 反色预设，实时预览后按原尺寸导出',
    tags: ['调色', '滤镜', '亮度', '对比度', '饱和度', '黑白', '灰度', '反色', '复古', '滤镜', 'adjust', 'filter'],
    takes: ['image'], forFormats: ['png', 'jpg', 'jpeg', 'webp'],
    mount: bImageMount({
      defaultFmt: 'jpg',
      previewTitle: '调色预览',
      note: '亮度等参数作用于整张图；预设可与滑块叠加。导出 JPG 时透明区域会填白。',
      fileName: () => '调色',
      before(c, W, H) { c.fillStyle = '#ffffff'; c.fillRect(0, 0, W, H); },
      fields(repaint) {
        return {
          preset: bSeg({
            label: '滤镜预设', value: 'none', onChange: repaint,
            options: [
              { value: 'none', label: '原图' }, { value: 'gray', label: '黑白' },
              { value: 'sepia', label: '复古' }, { value: 'invert', label: '反色' },
              { value: 'warm', label: '暖调' }, { value: 'cool', label: '冷调' },
              { value: 'vivid', label: '鲜艳' },
            ],
          }),
          bright: Field.slider({ label: '亮度', min: -100, max: 100, value: 0, unit: '%', onInput: repaint }),
          contrast: Field.slider({ label: '对比度', min: -100, max: 100, value: 0, unit: '%', onInput: repaint }),
          saturate: Field.slider({ label: '饱和度', min: -100, max: 100, value: 0, unit: '%', onInput: repaint }),
          hue: Field.slider({ label: '色相旋转', min: 0, max: 360, value: 0, unit: '°', onInput: repaint }),
          blur: Field.slider({ label: '柔化模糊', min: 0, max: 10, step: 0.5, value: 0, unit: 'px', onInput: repaint }),
        };
      },
      draw(c, src, v, W, H) {
        const base = {
          none: '', gray: 'grayscale(1)', sepia: 'sepia(.8) contrast(1.05)', invert: 'invert(1)',
          warm: 'sepia(.28) saturate(1.18)', cool: 'hue-rotate(190deg) saturate(.9)', vivid: 'saturate(1.55) contrast(1.08)',
        }[v.preset] || '';
        const parts = [base,
          `brightness(${1 + v.bright / 100})`,
          `contrast(${1 + v.contrast / 100})`,
          `saturate(${Math.max(0, 1 + v.saturate / 100)})`,
          `hue-rotate(${v.hue}deg)`];
        if (v.blur > 0) parts.push(`blur(${v.blur}px)`);
        c.filter = parts.filter(Boolean).join(' ');
        c.drawImage(src, 0, 0, W, H);
        c.filter = 'none';
      },
    }),
  });

  /* ------------------------------------------------------------------ *
   * 2 / 像素化与故障特效
   * ------------------------------------------------------------------ */
  function bEffects(c, src, v, W, H) {
    const mode = v.mode;
    const strength = clamp(Number(v.strength) || 0, 0, 100);
    if (mode === 'pixel') {
      const block = clamp(Math.round(v.block) || 12, 2, 120);
      const tw = Math.max(1, Math.ceil(W / block)), th = Math.max(1, Math.ceil(H / block));
      const { canvas: tmp, ctx: tc } = newCanvas(tw, th);
      tc.drawImage(src, 0, 0, tw, th);
      c.imageSmoothingEnabled = false;
      c.drawImage(tmp, 0, 0, tw, th, 0, 0, W, H);
      c.imageSmoothingEnabled = true;
      tmp.width = 0; tmp.height = 0;
      return;
    }
    c.drawImage(src, 0, 0, W, H);
    if (mode === 'scanline') {
      const im = c.getImageData(0, 0, W, H), d = im.data;
      const k = 1 - strength / 140;
      for (let y = 0; y < H; y += 2) {
        for (let x = 0; x < W; x++) {
          const i = (y * W + x) * 4;
          d[i] *= k; d[i + 1] *= k; d[i + 2] *= k;
        }
      }
      c.putImageData(im, 0, 0);
      return;
    }
    if (mode === 'noise') {
      const im = c.getImageData(0, 0, W, H), d = im.data;
      const amp = strength * 1.6;
      for (let i = 0; i < d.length; i += 4) {
        const n = (Math.random() - 0.5) * amp;
        d[i] = clamp(d[i] + n, 0, 255);
        d[i + 1] = clamp(d[i + 1] + n, 0, 255);
        d[i + 2] = clamp(d[i + 2] + n, 0, 255);
      }
      c.putImageData(im, 0, 0);
      return;
    }
    // rgb 色差 / glitch：按通道横向错位，glitch 另加随机条带位移
    const off = Math.max(1, Math.round(strength / 8));
    const im = c.getImageData(0, 0, W, H), d = im.data;
    const copy = new Uint8ClampedArray(d);
    for (let y = 0; y < H; y++) {
      let shift = mode === 'glitch' && Math.random() < strength / 320
        ? Math.round((Math.random() - 0.5) * strength) : 0;
      for (let x = 0; x < W; x++) {
        const i = (y * W + x) * 4;
        const xr = clamp(x + off + shift, 0, W - 1);
        const xb = clamp(x - off + shift, 0, W - 1);
        const ri = (y * W + xr) * 4, bi = (y * W + xb) * 4;
        d[i] = copy[ri];
        d[i + 1] = copy[i + 1];
        d[i + 2] = copy[bi + 2];
      }
    }
    c.putImageData(im, 0, 0);
  }

  tool({
    id: 'image-effects', cat: 'image', name: '像素化与故障特效', ico: 'zap', priority: 21,
    desc: '整图马赛克、RGB 色差、扫描线、噪点与故障条带，强度可调，导出后依然是普通图片',
    tags: ['像素化', '马赛克', '故障', 'glitch', '色差', '扫描线', '噪点', '特效', 'pixelate'],
    takes: ['image'], forFormats: ['png', 'jpg', 'jpeg', 'webp'],
    mount: bImageMount({
      defaultFmt: 'png',
      previewTitle: '特效预览',
      note: '像素化会先降采样再放大，块越大越糊；故障与噪点含随机成分，每次导出结果略有差异。',
      fileName: (v) => v.mode,
      fields(repaint) {
        return {
          mode: bSeg({
            label: '特效', value: 'pixel', onChange: repaint,
            options: [
              { value: 'pixel', label: '像素化' }, { value: 'rgb', label: 'RGB 色差' },
              { value: 'glitch', label: '故障条带' }, { value: 'scanline', label: '扫描线' },
              { value: 'noise', label: '噪点' },
            ],
          }),
          strength: Field.slider({ label: '强度', min: 0, max: 100, value: 35, unit: '%', onInput: repaint }),
          block: Field.number({ label: '像素块大小', value: 12, min: 2, max: 120, step: 1, unit: 'px', hint: '仅「像素化」模式生效', onInput: repaint }),
        };
      },
      draw: bEffects,
    }),
  });

  /* ------------------------------------------------------------------ *
   * 3 / 圆角与边框
   * ------------------------------------------------------------------ */
  tool({
    id: 'image-round', cat: 'image', name: '圆角与边框', ico: 'crop', priority: 22,
    desc: '给图片切圆角、加描边与留白，可选投影和背景色，导出带透明通道的 PNG',
    tags: ['圆角', '边框', '描边', '阴影', '留白', '圆角矩形', 'round', 'border', '头像'],
    takes: ['image'], forFormats: ['png', 'jpg', 'jpeg', 'webp'],
    mount: bImageMount({
      defaultFmt: 'png', formats: ['png', 'jpg', 'webp'],
      previewTitle: '圆角预览',
      note: '圆角外侧默认透明，导出 PNG 才能保留；选背景色后会铺满整张画布，JPG 也适用。',
      fileName: () => '圆角',
      fields(repaint) {
        return {
          radius: Field.slider({ label: '圆角半径', min: 0, max: 300, value: 48, unit: 'px', onInput: repaint }),
          pad: Field.number({ label: '四周留白', value: 24, min: 0, max: 400, step: 2, unit: 'px', onInput: repaint }),
          border: Field.number({ label: '边框宽度', value: 0, min: 0, max: 60, step: 1, unit: 'px', onInput: repaint }),
          color: bColor('边框颜色', '#b64f30', repaint),
          bg: Field.select({
            label: '背景', value: 'transparent', onChange: repaint,
            options: [
              { value: 'transparent', label: '透明（仅 PNG）' },
              { value: 'white', label: '白色' },
              { value: 'custom', label: '自定义颜色' },
            ],
          }),
          bgColor: bColor('自定义背景色', '#f6f3ec', repaint),
          shadow: Field.toggle({ label: '加投影', checked: false, onChange: repaint }),
        };
      },
      outputSize(w, h, k, v) {
        const p = Math.round((Number(v.pad) || 0) * k);
        return [w + 2 * p, h + 2 * p];
      },
      before(c, W, H, v) {
        const bg = v.bg === 'white' ? '#ffffff'
          : v.bg === 'custom' ? bHex(v.bgColor, '#f6f3ec') : null;
        if (bg) { c.fillStyle = bg; c.fillRect(0, 0, W, H); }
      },
      draw(c, src, v, W, H) {
        const k = v.__k || 1;
        const p = Math.round((Number(v.pad) || 0) * k);
        const r = Math.round((Number(v.radius) || 0) * k);
        const bw = Math.round((Number(v.border) || 0) * k);
        const iw = Math.max(1, W - 2 * p), ih = Math.max(1, H - 2 * p);
        if (v.shadow) {
          c.save();
          c.shadowColor = 'rgba(28,25,23,.30)';
          c.shadowBlur = Math.max(6, 22 * k);
          c.shadowOffsetY = Math.max(2, 8 * k);
          c.fillStyle = '#ffffff';
          bRoundRect(c, p, p, iw, ih, r);
          c.fill();
          c.restore();
        }
        c.save();
        bRoundRect(c, p, p, iw, ih, r);
        c.clip();
        c.drawImage(src, p, p, iw, ih);
        c.restore();
        if (bw > 0 && iw > bw * 2 && ih > bw * 2) {
          c.save();
          c.strokeStyle = bHex(v.color, '#b64f30');
          c.lineWidth = bw;
          bRoundRect(c, p + bw / 2, p + bw / 2, iw - bw, ih - bw, Math.max(0, r - bw / 2));
          c.stroke();
          c.restore();
        }
      },
    }),
  });

  /* ------------------------------------------------------------------ *
   * 4 / 图片叠加混合（两个输入区，单独写 mount）
   * ------------------------------------------------------------------ */
  tool({
    id: 'image-overlay', cat: 'image', name: '图片叠加混合', ico: 'merge', priority: 23,
    desc: '把两张图按正片叠底、滤色、叠加等模式合成一张，可调透明度、缩放与对齐位置',
    tags: ['叠加', '合成', '混合模式', '正片叠底', '滤色', '双层', 'overlay', 'blend', '双重曝光'],
    takes: ['image'], forFormats: ['png', 'jpg', 'jpeg', 'webp'],
    mount(root, ctx) {
      const pv = previewBox({ title: '叠加预览', emptyText: '分别放入底图和叠加图，即可看到合成效果' });
      let baseBmp = null, overBmp = null, baseName = 'image';

      const mode = Field.select({
        label: '混合模式', value: 'source-over',
        options: [
          { value: 'source-over', label: '正常' }, { value: 'multiply', label: '正片叠底（变暗）' },
          { value: 'screen', label: '滤色（变亮）' }, { value: 'overlay', label: '叠加（增对比）' },
          { value: 'darken', label: '变暗' }, { value: 'lighten', label: '变亮' },
          { value: 'difference', label: '差值' },
        ],
        onChange: paint,
      });
      const alpha = Field.slider({ label: '叠加图不透明度', min: 0, max: 100, value: 100, unit: '%', onInput: paint });
      const scale = Field.slider({ label: '叠加图缩放', min: 10, max: 200, value: 100, unit: '%', onInput: paint });
      const pos = bSeg({
        label: '对齐位置', value: 'center', onChange: paint,
        options: [
          { value: 'center', label: '居中' }, { value: 'tl', label: '左上' },
          { value: 'tr', label: '右上' }, { value: 'bl', label: '左下' },
          { value: 'br', label: '右下' }, { value: 'fit', label: '铺满拉伸' },
        ],
      });
      const fmt = Field.select({
        label: '输出格式', value: 'png',
        options: [
          { value: 'png', label: 'PNG（无损）' }, { value: 'jpg', label: 'JPG（体积小）' },
          { value: 'webp', label: 'WebP' },
        ],
      });

      const dzBase = DropZone({
        accept: 'image/*', multiple: false, title: '底图拖到这里', sub: '决定输出尺寸的那一张',
        async onFiles(files) {
          if (!files.length) { baseBmp = null; pv.clear(); return; }
          baseName = files[0].name;
          baseBmp?.close?.();
          baseBmp = await loadBitmap(files[0]);
          paint();
        },
      });
      const dzOver = DropZone({
        accept: 'image/*', multiple: false, title: '叠加图拖到这里', sub: '会盖在底图上方，支持透明 PNG',
        async onFiles(files) {
          if (!files.length) { overBmp = null; paint(); return; }
          overBmp?.close?.();
          overBmp = await loadBitmap(files[0]);
          paint();
        },
      });

      function drawTo(c, base, over, W, H) {
        if (fmt.get() === 'jpg') { c.fillStyle = '#ffffff'; c.fillRect(0, 0, W, H); }
        c.drawImage(base, 0, 0, W, H);
        if (!over) return;
        const k = Number(scale.get()) / 100;
        let w = W * k, h = H * k;
        if (pos.get() === 'fit') { w = W; h = H; }
        let x = (W - w) / 2, y = (H - h) / 2;
        if (pos.get() === 'tl' || pos.get() === 'bl') x = 0;
        if (pos.get() === 'tr' || pos.get() === 'br') x = W - w;
        if (pos.get() === 'tl' || pos.get() === 'tr') y = 0;
        if (pos.get() === 'bl' || pos.get() === 'br') y = H - h;
        c.save();
        c.globalAlpha = Number(alpha.get()) / 100;
        c.globalCompositeOperation = mode.get();
        c.drawImage(over, x, y, w, h);
        c.restore();
      }

      function paint() {
        if (!baseBmp) { pv.clear(); return; }
        const maxEdge = 700;
        const k = Math.min(1, maxEdge / Math.max(baseBmp.width, baseBmp.height));
        const W = Math.max(1, Math.round(baseBmp.width * k)), H = Math.max(1, Math.round(baseBmp.height * k));
        const { canvas, ctx: c } = newCanvas(W, H);
        drawTo(c, baseBmp, overBmp, W, H);
        canvas.style.maxWidth = '100%';
        pv.set(canvas, `${baseBmp.width} × ${baseBmp.height} · 预览为缩略图`);
      }

      const ui = toolUI({
        zone: dzBase,
        opts: [mode, alpha, scale, pos, fmt],
        extra: h('div', { style: { marginTop: '10px' } }, dzOver),
        extraTop: pv.el,
        note: h('div.hint', { style: { marginTop: '10px' } }, '输出尺寸跟随底图；叠加图会等比缩放后再对齐。JPG 输出会填白底。'),
        btnLabel: '合成并导出',
        async onRun({ prog, res }) {
          if (!baseBmp) throw new Error('请先放入底图');
          if (!overBmp) throw new Error('请再放一张叠加图');
          prog.set(20, '正在合成…');
          const W = baseBmp.width, H = baseBmp.height;
          const { canvas, ctx: c } = newCanvas(W, H);
          drawTo(c, baseBmp, overBmp, W, H);
          const ext = fmt.get();
          const blob = await exportCanvas(canvas, ext, 0.92);
          canvas.width = 0; canvas.height = 0;
          prog.set(100);
          res.show([{
            name: bOut(baseName, '叠加', ext),
            blob,
            note: `${W} × ${H} · ${mode.el.querySelector('select').selectedOptions[0]?.textContent || ''} · ${fmtBytes(blob.size)}`,
          }], { title: '✓ 合成完成' });
          setTimeout(() => prog.hide(), 400);
        },
      });

      root.appendChild(ui.panel);
      _pageCleanups.add(() => { baseBmp?.close?.(); overBmp?.close?.(); baseBmp = null; overBmp = null; });
      if (ctx.prefill) dzBase.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * 5 / SVG 转 PNG
   * ------------------------------------------------------------------ */
  tool({
    id: 'svg-to-png', cat: 'image', name: 'SVG 转 PNG', ico: 'convert', priority: 24,
    desc: '把 SVG 源码或 .svg 文件渲染成 PNG / JPG / WebP，可指定宽高、倍数与背景色',
    tags: ['svg', '转png', 'svg转图片', '矢量图', '图标导出', 'rasterize', 'png'],
    takes: ['image'], forFormats: ['svg', 'png', 'jpg', 'jpeg', 'webp'],
    mount(root, ctx) {
      const pv = previewBox({ title: '渲染预览', emptyText: '拖入 .svg 文件或在下方粘贴 SVG 源码' });
      let svgText = '', srcName = 'drawing';

      const ed = editorPane({
        title: 'SVG 源码（可直接粘贴）', rows: 8,
        placeholder: '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100">...</svg>',
        onInput: (v) => { svgText = v; queueMicrotask(paint); },
      });

      const width = Field.number({ label: '输出宽度', value: 0, min: 0, max: 8192, step: 1, unit: 'px', hint: '0 表示按 SVG 自身尺寸', onInput: paint });
      const height = Field.number({ label: '输出高度', value: 0, min: 0, max: 8192, step: 1, unit: 'px', hint: '0 表示按 SVG 自身尺寸或按比例推算', onInput: paint });
      const keep = Field.toggle({ label: '锁定宽高比', checked: true, hint: '开启时高度由 SVG 比例推算', onChange: paint });
      const scale = Field.select({
        label: '额外倍数', value: '1',
        options: [
          { value: '1', label: '1×' }, { value: '2', label: '2×（高清）' },
          { value: '3', label: '3×' }, { value: '4', label: '4×' },
        ], onChange: paint,
      });
      const bgMode = Field.select({
        label: '背景', value: 'transparent',
        options: [
          { value: 'transparent', label: '透明（仅 PNG / WebP）' },
          { value: 'white', label: '白色' }, { value: 'custom', label: '自定义颜色' },
        ], onChange: paint,
      });
      const bgColor = bColor('自定义背景色', '#ffffff', paint);
      const fmt = Field.select({
        label: '输出格式', value: 'png',
        options: [
          { value: 'png', label: 'PNG（无损 / 透明）' }, { value: 'jpg', label: 'JPG（白底）' },
          { value: 'webp', label: 'WebP' },
        ],
      });

      const dz = DropZone({
        accept: '.svg,image/svg+xml', multiple: false,
        title: '把 .svg 文件拖到这里', sub: '也可以直接在下方粘贴 SVG 源码',
        async onFiles(files) {
          if (!files.length) { svgText = ''; ed.ta.value = ''; pv.clear(); return; }
          srcName = files[0].name;
          svgText = await files[0].text();
          ed.ta.value = svgText;
          ed.stat.textContent = `${svgText.length} 字符`;
          paint();
        },
      });

      /** 规范化 SVG：补 xmlns、补 width/height，避免不同浏览器按 300×150 默认值渲染 */
      function normalize(text) {
        let t = String(text || '').trim();
        if (!t) throw new Error('还没有 SVG 内容：拖入 .svg 文件或粘贴源码');
        if (!/<svg[\s>]/i.test(t)) throw new Error('内容里没有 <svg> 根标签，请检查是否复制完整');
        const vb = t.match(/viewBox\s*=\s*["']\s*[\d.-]+\s+[\d.-]+\s+([\d.]+)\s+([\d.]+)/i);
        const w = vb ? Math.max(1, Math.round(+vb[1])) : 512;
        const hh = vb ? Math.max(1, Math.round(+vb[2])) : 512;
        t = t.replace(/<svg([^>]*?)>/i, (m, attrs) => {
          let a = attrs;
          if (!/\sxmlns\s*=/i.test(a)) a += ' xmlns="http://www.w3.org/2000/svg"';
          if (!/\swidth\s*=/i.test(a)) a += ` width="${w}"`;
          if (!/\sheight\s*=/i.test(a)) a += ` height="${hh}"`;
          return '<svg' + a + '>';
        });
        return { text: t, natW: w, natH: hh };
      }

      function bgOf() {
        if (fmt.get() === 'jpg') return '#ffffff';
        if (bgMode.get() === 'white') return '#ffffff';
        if (bgMode.get() === 'custom') return bHex(bgColor.get(), '#ffffff');
        return null;
      }

      async function render(W, H) {
        const { text, natW, natH } = normalize(svgText);
        const mul = Number(scale.get()) || 1;
        let ow = Math.round((Number(width.get()) || natW) * mul);
        let oh = Math.round((Number(height.get()) || (keep.get() ? natH * (ow / (mul * natW)) : natH)) * mul);
        if (keep.get() && !(Number(height.get()) > 0)) oh = Math.max(1, Math.round(ow * natH / natW));
        ow = clamp(ow, 1, 8192); oh = clamp(oh, 1, 8192);
        const blob = new Blob([text], { type: 'image/svg+xml;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        try {
          const img = await new Promise((res, rej) => {
            const i = new Image();
            i.onload = () => res(i);
            i.onerror = () => rej(new Error('SVG 无法渲染，请检查标签是否闭合、属性是否合法'));
            i.src = url;
          });
          const { canvas, ctx: c } = newCanvas(W || ow, H || oh);
          const bg = bgOf();
          if (bg) { c.fillStyle = bg; c.fillRect(0, 0, canvas.width, canvas.height); }
          c.drawImage(img, 0, 0, canvas.width, canvas.height);
          return { canvas, ow: canvas.width, oh: canvas.height };
        } finally {
          URL.revokeObjectURL(url);
        }
      }

      let paintToken = 0;
      async function paint() {
        const token = ++paintToken;
        if (!svgText.trim()) { pv.clear(); return; }
        try {
          const { canvas, ow, oh } = await render(0, 0);
          if (token !== paintToken) { canvas.width = 0; canvas.height = 0; return; }
          canvas.style.maxWidth = '100%';
          pv.set(canvas, `输出 ${ow} × ${oh} · 预览为缩略显示`);
        } catch (e) {
          if (token === paintToken) pv.clear();
        }
      }

      const ui = toolUI({
        zone: dz,
        opts: [width, height, keep, scale, bgMode, bgColor, fmt],
        extra: h('div', { style: { marginTop: '12px' } }, ed.el),
        extraTop: pv.el,
        note: h('div.hint', { style: { marginTop: '10px' } },
          'SVG 里的外链图片、字体和脚本出于浏览器安全策略不会加载，复杂素材请先内嵌或转成路径。'),
        btnLabel: '渲染并导出',
        async onRun({ prog, res }) {
          prog.set(25, '正在渲染 SVG…');
          const { canvas, ow, oh } = await render(0, 0);
          const ext = fmt.get();
          const blob = await exportCanvas(canvas, ext, 0.92);
          canvas.width = 0; canvas.height = 0;
          prog.set(100);
          res.show([{
            name: bOut(srcName.replace(/\.svg$/i, ''), `${ow}x${oh}`, ext),
            blob,
            note: `${ow} × ${oh} · ${ext.toUpperCase()} · ${fmtBytes(blob.size)}`,
          }], { title: '✓ 渲染完成' });
          setTimeout(() => prog.hide(), 400);
        },
      });

      root.appendChild(ui.panel);
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * 6 / 颜色替换 / 去纯色背景
   * ------------------------------------------------------------------ */
  tool({
    id: 'image-color-replace', cat: 'image', name: '颜色替换与去背景', ico: 'diff', priority: 25,
    desc: '按颜色容差把指定色块变透明或换成另一种颜色，适合去纯色底、改 logo 配色',
    tags: ['去背景', '抠图', '透明', '颜色替换', '去白底', '容差', 'chroma', '抠色'],
    takes: ['image'], forFormats: ['png', 'jpg', 'jpeg', 'webp'],
    mount: bImageMount({
      defaultFmt: 'png', formats: ['png', 'webp'],
      previewTitle: '去背景预览',
      note: '适合纯色或近似纯色背景；人像发丝、渐变和阴影边缘无法精确抠出，复杂抠图请用专业工具。',
      fileName: () => '去背',
      fields(repaint) {
        return {
          target: Field.text({ label: '要替换的颜色', value: '#ffffff', placeholder: '#RRGGBB', hint: '填十六进制颜色，如 #ffffff', mono: true, onInput: repaint }),
          tolerance: Field.slider({ label: '颜色容差', min: 0, max: 150, value: 35, unit: '', onInput: repaint }),
          mode: bSeg({
            label: '处理方式', value: 'transparent', onChange: repaint,
            options: [{ value: 'transparent', label: '变透明' }, { value: 'replace', label: '换成指定色' }],
          }),
          replacement: bColor('替换成', '#b64f30', repaint),
          feather: Field.toggle({ label: '边缘柔化', checked: true, hint: '容差范围内按距离渐变透明度，边缘更自然', onChange: repaint }),
        };
      },
      draw(c, src, v, W, H) {
        c.drawImage(src, 0, 0, W, H);
        const hex = bHex(v.target, '#ffffff');
        const tr = parseInt(hex.slice(1, 3), 16), tg = parseInt(hex.slice(3, 5), 16), tb = parseInt(hex.slice(5, 7), 16);
        const tol = Number(v.tolerance) || 0;
        const rep = bHex(v.replacement, '#b64f30');
        const rr = parseInt(rep.slice(1, 3), 16), rg = parseInt(rep.slice(3, 5), 16), rb = parseInt(rep.slice(5, 7), 16);
        const im = c.getImageData(0, 0, W, H), d = im.data;
        for (let i = 0; i < d.length; i += 4) {
          const dist = Math.sqrt((d[i] - tr) ** 2 + (d[i + 1] - tg) ** 2 + (d[i + 2] - tb) ** 2);
          if (dist > tol) continue;
          if (v.mode === 'replace') {
            d[i] = rr; d[i + 1] = rg; d[i + 2] = rb;
          } else if (v.feather && tol > 0) {
            d[i + 3] = Math.round(d[i + 3] * clamp(dist / tol, 0, 1));
          } else {
            d[i + 3] = 0;
          }
        }
        c.putImageData(im, 0, 0);
      },
    }),
  });

  /* ------------------------------------------------------------------ *
   * 7 / DPI（PPI）设置 —— 只改元数据，不动一个像素
   * ------------------------------------------------------------------ */
  function bCrc32(u8) {
    if (!bCrc32.table) {
      const t = new Uint32Array(256);
      for (let n = 0; n < 256; n++) {
        let c = n;
        for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
        t[n] = c >>> 0;
      }
      bCrc32.table = t;
    }
    let crc = 0xffffffff;
    for (let i = 0; i < u8.length; i++) crc = bCrc32.table[(crc ^ u8[i]) & 0xff] ^ (crc >>> 8);
    return (crc ^ 0xffffffff) >>> 0;
  }

  function bScanChunks(u8, dv, onChunk) {
    let pos = 8;
    while (pos + 12 <= u8.length) {
      const len = dv.getUint32(pos);
      const type = String.fromCharCode(u8[pos + 4], u8[pos + 5], u8[pos + 6], u8[pos + 7]);
      const end = Math.min(u8.length, pos + 12 + len);
      if (onChunk(pos, type, len, end) === false) return;
      pos = end;
      if (type === 'IEND') return;
    }
  }

  function bReadDpi(buf, ext) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf);
    if (ext === 'png') {
      if (dv.getUint32(0) !== 0x89504e47) return null;
      let dpi = null;
      bScanChunks(u8, dv, (pos, type) => {
        if (type === 'pHYs') {
          const unit = u8[pos + 16];
          if (unit === 1) dpi = Math.round(dv.getUint32(pos + 8) * 0.0254);
          return false;
        }
      });
      return dpi;
    }
    // JPEG：APP0 / JFIF 里的密度字段
    let pos = 2, dpi = null;
    while (pos + 4 <= u8.length) {
      if (u8[pos] !== 0xff) { pos++; continue; }
      const marker = u8[pos + 1];
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { pos += 2; continue; }
      const len = dv.getUint16(pos + 2);
      if (len < 2) break;
      const isJfif = marker === 0xe0 && u8[pos + 4] === 0x4a && u8[pos + 5] === 0x46 && u8[pos + 6] === 0x49 && u8[pos + 7] === 0x46;
      if (isJfif && len >= 16) {
        const units = u8[pos + 11], x = dv.getUint16(pos + 12);
        dpi = units === 1 ? x : units === 2 ? Math.round(x * 2.54) : null;
        break;
      }
      if (marker === 0xda) break;
      pos += 2 + len;
    }
    return dpi;
  }

  function bPngWithDpi(buf, dpi) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf);
    if (dv.getUint32(0) !== 0x89504e47) throw new Error('不是有效的 PNG 文件');
    const ppm = Math.round(dpi / 0.0254);
    const chunk = new Uint8Array(21);
    const cd = new DataView(chunk.buffer);
    cd.setUint32(0, 9);
    chunk.set([0x70, 0x48, 0x59, 0x73], 4);           // pHYs
    cd.setUint32(8, ppm);
    cd.setUint32(12, ppm);
    chunk[16] = 1;                                      // 单位：米
    cd.setUint32(17, bCrc32(chunk.slice(4, 17)));
    const parts = [u8.slice(0, 8)];
    let inserted = false;
    bScanChunks(u8, dv, (pos, type, len, end) => {
      if (type === 'pHYs') return;                      // 丢掉旧的
      parts.push(u8.slice(pos, end));
      if (type === 'IHDR' && !inserted) { parts.push(chunk); inserted = true; }
    });
    if (!inserted) parts.splice(1, 0, chunk);
    const total = parts.reduce((s, p) => s + p.length, 0);
    const out = new Uint8Array(total);
    let o = 0;
    for (const p of parts) { out.set(p, o); o += p.length; }
    return new Blob([out], { type: 'image/png' });
  }

  function bJpegWithDpi(buf, dpi) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf);
    if (u8[0] !== 0xff || u8[1] !== 0xd8) throw new Error('不是有效的 JPEG 文件');
    let pos = 2;
    while (pos + 4 <= u8.length) {
      if (u8[pos] !== 0xff) { pos++; continue; }
      const marker = u8[pos + 1];
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { pos += 2; continue; }
      const len = dv.getUint16(pos + 2);
      if (len < 2) break;
      const isJfif = marker === 0xe0 && u8[pos + 4] === 0x4a && u8[pos + 5] === 0x46 && u8[pos + 6] === 0x49 && u8[pos + 7] === 0x46;
      if (isJfif && len >= 16) {
        const out = u8.slice();
        const od = new DataView(out.buffer);
        out[pos + 11] = 1;                              // 单位：每英寸
        od.setUint16(pos + 12, dpi);
        od.setUint16(pos + 14, dpi);
        return new Blob([out], { type: 'image/jpeg' });
      }
      if (marker === 0xda) break;
      pos += 2 + len;
    }
    // 没有 JFIF APP0：补一个标准段（18 字节）
    const seg = new Uint8Array(18);
    seg[0] = 0xff; seg[1] = 0xe0;
    new DataView(seg.buffer).setUint16(2, 16);
    seg.set([0x4a, 0x46, 0x49, 0x46, 0x00], 4);
    seg[9] = 1; seg[10] = 1; seg[11] = 1;
    new DataView(seg.buffer).setUint16(12, dpi);
    new DataView(seg.buffer).setUint16(14, dpi);
    const out = new Uint8Array(u8.length + seg.length);
    out.set(u8.slice(0, 2), 0);
    out.set(seg, 2);
    out.set(u8.slice(2), 2 + seg.length);
    return new Blob([out], { type: 'image/jpeg' });
  }

  tool({
    id: 'image-dpi', cat: 'image', name: '图片 DPI 设置', ico: 'resize', priority: 26,
    desc: '读取并修改 PNG / JPEG 的 DPI 元数据，设成 72 / 96 / 300 或任意值，像素尺寸完全不变',
    tags: ['dpi', 'ppi', '分辨率', '300dpi', '打印', '元数据', '密度'],
    takes: ['image'], forFormats: ['png', 'jpg', 'jpeg'],
    mount(root, ctx) {
      const info = h('div.hint', { style: { marginTop: '10px' }, role: 'status', 'aria-live': 'polite' }, '拖入 PNG 或 JPEG 后显示当前 DPI');
      const preset = Field.select({
        label: '目标 DPI', value: '300',
        options: [
          { value: '72', label: '72 DPI — 屏幕' }, { value: '96', label: '96 DPI — Windows 屏幕' },
          { value: '150', label: '150 DPI — 普通打印' }, { value: '300', label: '300 DPI — 高清印刷' },
          { value: '600', label: '600 DPI — 精细印刷' }, { value: 'custom', label: '自定义' },
        ],
        onChange: syncCustom,
      });
      const custom = Field.number({ label: '自定义 DPI', value: 300, min: 1, max: 2400, step: 1, unit: 'dpi' });
      function syncCustom() { custom.el.classList.toggle('hide', preset.get() !== 'custom'); }
      const dz = DropZone({
        accept: 'image/png,image/jpeg,.png,.jpg,.jpeg', multiple: true,
        title: '把 PNG 或 JPEG 拖到这里', sub: '只修改元数据，不重新编码，画质与像素完全不变',
        async onFiles(files) {
          if (!files.length) { info.textContent = '拖入 PNG 或 JPEG 后显示当前 DPI'; return; }
          const lines = [];
          for (const f of files.slice(0, 5)) {
            const ext = (extOf(f.name) || '').toLowerCase();
            if (ext !== 'png' && ext !== 'jpg' && ext !== 'jpeg') { lines.push(`${f.name}：不支持的格式`); continue; }
            const d = bReadDpi(await f.arrayBuffer(), ext === 'png' ? 'png' : 'jpg');
            lines.push(`${f.name}：当前 ${d ? d + ' DPI' : '未写入 DPI（多数软件按 72 或 96 处理）'}`);
          }
          info.textContent = lines.join(' · ');
        },
      });
      const ui = toolUI({
        zone: dz, opts: [preset, custom],
        extraTop: h('div', { style: { marginTop: '12px' } }, info),
        note: h('div.hint', { style: { marginTop: '10px' } },
          'PNG 写在 pHYs 块、JPEG 写在 JFIF APP0 段。WebP / GIF 没有标准 DPI 字段，会被跳过。DPI 只影响打印尺寸，不改变屏幕显示大小。'),
        btnLabel: '写入 DPI',
        async onRun({ prog, res }) {
          const files = dz.dz.get();
          if (!files.length) throw new Error('请先拖入 PNG 或 JPEG 图片');
          const dpi = clamp(Math.round(preset.get() === 'custom' ? Number(custom.get()) : Number(preset.get())), 1, 2400);
          if (!Number.isFinite(dpi) || dpi < 1) throw new Error('请填写有效的 DPI 数值');
          const out = [];
          let skipped = 0;
          for (let i = 0; i < files.length; i++) {
            prog.set((i / files.length) * 95, `写入 ${i + 1} / ${files.length}`);
            const f = files[i];
            const ext = (extOf(f.name) || '').toLowerCase();
            if (ext !== 'png' && ext !== 'jpg' && ext !== 'jpeg') { skipped++; continue; }
            const buf = await f.arrayBuffer();
            const blob = ext === 'png' ? bPngWithDpi(buf, dpi) : bJpegWithDpi(buf, dpi);
            out.push({
              name: bOut(f.name, dpi + 'dpi', ext),
              blob,
              note: `${dpi} DPI · 像素不变 · ${fmtBytes(blob.size)}`,
            });
          }
          if (!out.length) throw new Error('没有可处理的 PNG / JPEG 文件');
          prog.set(100);
          res.show(out, {
            title: `✓ 已写入 ${dpi} DPI，共 ${out.length} 个文件`,
            summary: skipped ? `另有 ${skipped} 个不支持格式的文件被跳过` : '像素数据未重新编码，画质不变',
          });
          setTimeout(() => prog.hide(), 400);
        },
      });
      root.appendChild(ui.panel);
      syncCustom();
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * 8 / EXIF 写入 —— 重建一个干净的 APP1 段
   * ------------------------------------------------------------------ */
  function bBuildExifApp1(fields) {
    const enc = new TextEncoder();
    const ascii = (s) => {
      const b = enc.encode(String(s));
      const o = new Uint8Array(b.length + 1);
      o.set(b);
      return o;
    };
    const ifd0 = [];
    const push = (tag, val) => { if (val) ifd0.push({ tag, type: 2, data: ascii(val) }); };
    push(0x010e, fields.desc);
    push(0x010f, fields.make);
    push(0x0110, fields.model);
    push(0x0131, fields.software || 'hddtool');
    push(0x0132, fields.date);
    push(0x013b, fields.artist);
    push(0x8298, fields.copyright);
    ifd0.push({ tag: 0x0112, type: 3, value: 1 });       // Orientation = 正常
    const exif = [];
    if (fields.date) exif.push({ tag: 0x9003, type: 2, data: ascii(fields.date) });
    // EXIF 的 ASCII 字段按规范只收 7-bit。中文以 UTF-8 写入后，个别老软件会按
    // 本地编码解析成乱码，因此额外写一条标准 UserComment（UNICODE + UTF-16BE），
    // 让 ExifTool / Adobe 一类工具也能正确读到原文。
    const hasNonAscii = Object.values(fields).some((v) => v && /[^\x00-\x7F]/.test(v));
    if (hasNonAscii) {
      const summary = [fields.desc, fields.artist, fields.copyright, fields.make, fields.model]
        .filter(Boolean).join(' | ');
      const units = [];
      for (const ch of summary) {
        const cp = ch.codePointAt(0);
        if (cp <= 0xffff) units.push(cp >> 8, cp & 255);
        else {
          const v = cp - 0x10000, hi = 0xd800 + (v >> 10), lo = 0xdc00 + (v & 0x3ff);
          units.push(hi >> 8, hi & 255, lo >> 8, lo & 255);
        }
      }
      const comment = new Uint8Array(8 + units.length);
      comment.set([0x55, 0x4e, 0x49, 0x43, 0x4f, 0x44, 0x45, 0x00], 0);   // "UNICODE\0"
      comment.set(new Uint8Array(units), 8);
      exif.push({ tag: 0x9286, type: 7, data: comment });
    }
    if (exif.length) ifd0.push({ tag: 0x8769, pointer: true });
    ifd0.sort((a, b) => a.tag - b.tag);
    exif.sort((a, b) => a.tag - b.tag);

    const ifd0Size = 2 + 12 * ifd0.length + 4;
    const exifSize = exif.length ? 2 + 12 * exif.length + 4 : 0;
    // Layout: header -> IFD0 -> ExifIFD -> IFD0 string data -> ExifIFD data.
    // The 0x8769 pointer must point at where the ExifIFD is ACTUALLY written;
    // putting the string pool between the two IFDs would overwrite the sub-IFD.
    const exifOffset = 8 + ifd0Size;
    let cur = exifOffset + exifSize;
    const dataParts = [];
    for (const e of ifd0) {
      if (e.pointer || e.type === 3) continue;
      dataParts.push({ bytes: e.data, offset: cur });
      e.offset = cur;
      cur += e.data.length + (e.data.length % 2);
    }
    for (const e of exif) {
      dataParts.push({ bytes: e.data, offset: cur });
      e.offset = cur;
      cur += e.data.length + (e.data.length % 2);
    }

    const tiff = new Uint8Array(cur);
    const dv = new DataView(tiff.buffer);
    tiff[0] = 0x49; tiff[1] = 0x49;                       // little endian
    dv.setUint16(2, 42, true);
    dv.setUint32(4, 8, true);
    let p = 8;
    dv.setUint16(p, ifd0.length, true); p += 2;
    for (const e of ifd0) {
      dv.setUint16(p, e.tag, true);
      dv.setUint16(p + 2, e.pointer ? 4 : e.type, true);
      if (e.type === 3) {
        dv.setUint32(p + 4, 1, true);
        dv.setUint16(p + 8, e.value || 1, true);
        dv.setUint16(p + 10, 0, true);
      } else if (e.pointer) {
        dv.setUint32(p + 4, 1, true);
        dv.setUint32(p + 8, exifOffset, true);
      } else {
        dv.setUint32(p + 4, e.data.length, true);
        dv.setUint32(p + 8, e.offset, true);
      }
      p += 12;
    }
    dv.setUint32(p, 0, true); p += 4;                    // IFD0 结束
    if (exif.length) {
      dv.setUint16(p, exif.length, true); p += 2;
      for (const e of exif) {
        dv.setUint16(p, e.tag, true);
        dv.setUint16(p + 2, e.type, true);
        dv.setUint32(p + 4, e.data.length, true);
        dv.setUint32(p + 8, e.offset, true);
        p += 12;
      }
      dv.setUint32(p, 0, true);
    }
    for (const d of dataParts) tiff.set(d.bytes, d.offset);

    const payload = new Uint8Array(6 + tiff.length);
    payload.set([0x45, 0x78, 0x69, 0x66, 0x00, 0x00], 0);   // "Exif\0\0"
    payload.set(tiff, 6);
    const seg = new Uint8Array(4 + payload.length);
    seg[0] = 0xff; seg[1] = 0xe1;
    new DataView(seg.buffer).setUint16(2, payload.length + 2);
    seg.set(payload, 4);
    return seg;
  }

  function bJpegWithExif(buf, fields) {
    const u8 = new Uint8Array(buf), dv = new DataView(buf);
    if (u8[0] !== 0xff || u8[1] !== 0xd8) throw new Error('EXIF 写入只支持 JPEG 文件');
    const parts = [u8.slice(0, 2), bBuildExifApp1(fields)];
    let pos = 2;
    while (pos + 4 <= u8.length) {
      if (u8[pos] !== 0xff) { parts.push(u8.slice(pos)); break; }
      const marker = u8[pos + 1];
      if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) { pos += 2; continue; }
      const len = dv.getUint16(pos + 2);
      if (len < 2) { parts.push(u8.slice(pos)); break; }
      const end = Math.min(u8.length, pos + 2 + len);
      const isExif = marker === 0xe1 && u8[pos + 4] === 0x45 && u8[pos + 5] === 0x78 && u8[pos + 6] === 0x69 && u8[pos + 7] === 0x66;
      if (!isExif) parts.push(u8.slice(pos, end));
      pos = end;
      if (marker === 0xda) { if (pos < u8.length) parts.push(u8.slice(pos)); break; }
    }
    const total = parts.reduce((s, x) => s + x.length, 0);
    const out = new Uint8Array(total);
    let o = 0;
    for (const x of parts) { out.set(x, o); o += x.length; }
    return new Blob([out], { type: 'image/jpeg' });
  }

  function bExifDate(s) {
    const t = String(s || '').trim();
    if (!t) return '';
    // 接受 "2026:11:15 10:30:00" 或 "2026-11-15T10:30"
    const m = t.match(/^(\d{4})[:\-](\d{2})[:\-](\d{2})[ T](\d{2}):(\d{2})(?::(\d{2}))?/);
    if (!m) return '';
    return `${m[1]}:${m[2]}:${m[3]} ${m[4]}:${m[5]}:${m[6] || '00'}`;
  }

  tool({
    id: 'image-exif-edit', cat: 'image', name: 'EXIF 编辑与写入', ico: 'image', priority: 27,
    desc: '给 JPEG 写入拍摄时间、作者、版权和描述等 EXIF 字段，像素数据不重新编码',
    tags: ['exif', '元数据', '写入', '版权', '作者', '拍摄时间', '编辑', 'iptc'],
    takes: ['image'], forFormats: ['jpg', 'jpeg'],
    mount(root, ctx) {
      const date = Field.text({ label: '拍摄时间', value: '', placeholder: '2026:11:15 10:30:00', hint: '格式 YYYY:MM:DD HH:MM:SS，留空表示不写入' });
      const artist = Field.text({ label: '作者 / 摄影', value: '', placeholder: '张三' });
      const copyright = Field.text({ label: '版权声明', value: '', placeholder: '© 2026 张三' });
      const desc = Field.text({ label: '图片描述', value: '', placeholder: '一句话说明' });
      const make = Field.text({ label: '设备厂商', value: '', placeholder: '可选' });
      const model = Field.text({ label: '设备型号', value: '', placeholder: '可选' });
      const nowBtn = h('button.btn.btn-sm.btn-ghost', {
        type: 'button',
        onclick: () => {
          const d = new Date();
          const pad = (x) => String(x).padStart(2, '0');
          date.input.value = `${d.getFullYear()}:${pad(d.getMonth() + 1)}:${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
        },
      }, '填入当前时间');

      const dz = DropZone({
        accept: 'image/jpeg,.jpg,.jpeg', multiple: true,
        title: '把 JPEG 照片拖到这里', sub: '批量写入同一组 EXIF 字段',
      });
      const ui = toolUI({
        zone: dz,
        opts: [date, artist, copyright, desc, make, model],
        extra: h('div', { style: { marginTop: '10px' } }, nowBtn),
        note: h('div.hint', { style: { marginTop: '10px' } },
          '会移除原有 APP1 / EXIF 段并重建一个干净版本，因此原照片的 GPS、曝光参数等字段也会一并清除；需要保留原始元数据请先用「图片 EXIF 查看与清除」导出备份。中文按 UTF-8 写入，并额外写一条标准 UserComment，个别老软件仍可能显示乱码。'),
        btnLabel: '写入 EXIF',
        async onRun({ prog, res }) {
          const files = dz.dz.get();
          if (!files.length) throw new Error('请先拖入 JPEG 照片');
          if (date.get().trim() && !bExifDate(date.get())) throw new Error('拍摄时间格式不对，请用 2026:11:15 10:30:00 这样的写法');
          const fields = {
            date: bExifDate(date.get()),
            artist: artist.get().trim(), copyright: copyright.get().trim(),
            desc: desc.get().trim(), make: make.get().trim(), model: model.get().trim(),
          };
          if (!Object.values(fields).some(Boolean)) throw new Error('至少填写一个字段再写入');
          const out = [];
          for (let i = 0; i < files.length; i++) {
            prog.set((i / files.length) * 95, `写入 ${i + 1} / ${files.length}`);
            const f = files[i];
            const ext = (extOf(f.name) || '').toLowerCase();
            if (ext !== 'jpg' && ext !== 'jpeg') continue;
            const blob = bJpegWithExif(await f.arrayBuffer(), fields);
            out.push({ name: bOut(f.name, 'exif', ext), blob, note: `EXIF 已写入 · ${fmtBytes(blob.size)}` });
          }
          if (!out.length) throw new Error('没有可处理的 JPEG 文件');
          prog.set(100);
          res.show(out, { title: `✓ 已写入 ${out.length} 张照片的 EXIF` });
          setTimeout(() => prog.hide(), 400);
        },
      });
      root.appendChild(ui.panel);
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * 9 / 图片配色提取
   * ------------------------------------------------------------------ */
  function bHexOf(r, g, b) {
    return '#' + [r, g, b].map((x) => clamp(Math.round(x), 0, 255).toString(16).padStart(2, '0')).join('');
  }

  function bExtractPalette(canvas, n, skipNeutral) {
    const w = Math.min(160, Math.max(1, canvas.width));
    const hh = Math.max(1, Math.round(w * canvas.height / Math.max(1, canvas.width)));
    const { canvas: small, ctx } = newCanvas(w, hh);
    ctx.drawImage(canvas, 0, 0, w, hh);
    const d = ctx.getImageData(0, 0, w, hh).data;
    const bins = new Map();
    for (let i = 0; i < d.length; i += 4) {
      if (d[i + 3] < 128) continue;
      const r = d[i], g = d[i + 1], b = d[i + 2];
      if (skipNeutral && ((r > 244 && g > 244 && b > 244) || (r < 12 && g < 12 && b < 12))) continue;
      const key = ((r >> 4) << 8) | ((g >> 4) << 4) | (b >> 4);
      const e = bins.get(key) || { n: 0, r: 0, g: 0, b: 0 };
      e.n++; e.r += r; e.g += g; e.b += b;
      bins.set(key, e);
    }
    small.width = 0; small.height = 0;
    const list = [...bins.values()]
      .map((e) => ({ n: e.n, r: Math.round(e.r / e.n), g: Math.round(e.g / e.n), b: Math.round(e.b / e.n) }))
      .sort((a, b) => b.n - a.n);
    const out = [];
    for (const c of list) {
      if (out.some((o) => Math.abs(o.r - c.r) + Math.abs(o.g - c.g) + Math.abs(o.b - c.b) < 46)) continue;
      out.push(c);
      if (out.length >= n) break;
    }
    return out;
  }

  tool({
    id: 'image-palette', cat: 'image', name: '图片配色提取', ico: 'zap', priority: 28,
    desc: '从照片里提取主色，生成色卡 PNG、CSS 变量和 JSON 调色板，做设计稿配色很顺手',
    tags: ['配色', '调色板', '取色', '主色', '色卡', 'palette', 'css变量', '设计师'],
    takes: ['image'], forFormats: ['png', 'jpg', 'jpeg', 'webp'],
    mount(root, ctx) {
      const pv = previewBox({ title: '色卡预览', emptyText: '拖入一张图片，自动提取主色' });
      const swatches = h('div.b-palette-swatches');
      let src = null, srcName = 'image', colors = [];

      const count = Field.number({ label: '提取颜色数', value: 6, min: 2, max: 16, step: 1, unit: '色', onInput: paint });
      const skip = Field.toggle({ label: '忽略纯白与纯黑', checked: true, onChange: paint });
      const sortBy = Field.select({
        label: '排列顺序', value: 'count', onChange: paint,
        options: [{ value: 'count', label: '按占比' }, { value: 'hue', label: '按色相' }],
      });

      const dz = DropZone({
        accept: 'image/*', multiple: false,
        title: '把图片拖到这里', sub: '从整张图统计颜色，透明像素会被忽略',
        async onFiles(files) {
          if (!files.length) { src = null; pv.clear(); swatches.replaceChildren(); return; }
          const bmp = await loadBitmap(files[0]);
          src = drawToCanvas(bmp, { maxEdge: 1200 });
          bmp.close?.();
          srcName = files[0].name;
          paint();
        },
      });

      function paint() {
        if (!src) { pv.clear(); swatches.replaceChildren(); return; }
        colors = bExtractPalette(src, clamp(Math.round(Number(count.get()) || 6), 2, 16), skip.get());
        if (sortBy.get() === 'hue') {
          colors = colors.slice().sort((a, b) => {
            const hue = (c) => {
              const mx = Math.max(c.r, c.g, c.b), mn = Math.min(c.r, c.g, c.b), d = mx - mn;
              if (!d) return 0;
              let hh = mx === c.r ? ((c.g - c.b) / d) % 6 : mx === c.g ? (c.b - c.r) / d + 2 : (c.r - c.g) / d + 4;
              return (hh * 60 + 360) % 360;
            };
            return hue(a) - hue(b);
          });
        }
        if (!colors.length) { pv.clear(); swatches.replaceChildren(); return; }
        const sw = Math.max(60, Math.min(150, Math.floor(720 / colors.length)));
        const { canvas, ctx: c } = newCanvas(sw * colors.length, 150);
        swatches.replaceChildren(...colors.map((col) => {
          const hex = bHexOf(col.r, col.g, col.b);
          return h('div.b-swatch', null,
            h('i', { style: { background: hex } }),
            h('code', null, hex));
        }));
        colors.forEach((col, i) => {
          const hex = bHexOf(col.r, col.g, col.b);
          c.fillStyle = hex;
          c.fillRect(i * sw, 0, sw, 150);
          const lum = (0.299 * col.r + 0.587 * col.g + 0.114 * col.b) / 255;
          c.fillStyle = lum > 0.6 ? '#2b2723' : '#ffffff';
          c.font = '600 13px system-ui, sans-serif';
          c.textAlign = 'center';
          c.fillText(hex.toUpperCase(), i * sw + sw / 2, 82);
        });
        canvas.style.maxWidth = '100%';
        pv.set(canvas, `共 ${colors.length} 色 · 色卡 ${canvas.width} × ${canvas.height}`);
      }

      const ui = toolUI({
        zone: dz, opts: [count, skip, sortBy],
        extraTop: h('div', null, pv.el, swatches),
        note: h('div.hint', { style: { marginTop: '10px' } },
          '颜色按 16 级分箱量化后取占比最高的若干组，并合并相近色；结果是「主色参考」，不是逐像素精确还原。'),
        btnLabel: '导出色卡与配色',
        async onRun({ prog, res }) {
          if (!src || !colors.length) throw new Error('请先拖入一张图片');
          prog.set(30, '正在生成色卡…');
          const sw = Math.max(60, Math.min(150, Math.floor(720 / colors.length)));
          const { canvas, ctx: c } = newCanvas(sw * colors.length, 150);
          colors.forEach((col, i) => {
            const hex = bHexOf(col.r, col.g, col.b);
            c.fillStyle = hex; c.fillRect(i * sw, 0, sw, 150);
            const lum = (0.299 * col.r + 0.587 * col.g + 0.114 * col.b) / 255;
            c.fillStyle = lum > 0.6 ? '#2b2723' : '#ffffff';
            c.font = '600 13px system-ui, sans-serif';
            c.textAlign = 'center';
            c.fillText(hex.toUpperCase(), i * sw + sw / 2, 82);
          });
          const png = await canvasToBlob(canvas, 'image/png');
          canvas.width = 0; canvas.height = 0;
          const hexes = colors.map((col) => bHexOf(col.r, col.g, col.b));
          const css = ':root {\n' + hexes.map((x, i) => `  --palette-${i + 1}: ${x};`).join('\n') + '\n}\n';
          const json = JSON.stringify(hexes.map((x, i) => ({
            name: `palette-${i + 1}`, hex: x,
            rgb: [colors[i].r, colors[i].g, colors[i].b],
          })), null, 2) + '\n';
          prog.set(100);
          res.show([
            { name: bOut(srcName, '色卡', 'png'), blob: png, note: `${colors.length} 色 · ${fmtBytes(png.size)}` },
            { name: bOut(srcName, '配色', 'css'), blob: new Blob([css], { type: 'text/css' }), note: 'CSS 自定义属性' },
            { name: bOut(srcName, '配色', 'json'), blob: new Blob([json], { type: 'application/json' }), note: '含 HEX 与 RGB' },
          ], { title: `✓ 提取到 ${colors.length} 个主色` });
          setTimeout(() => prog.hide(), 400);
        },
      });
      root.appendChild(ui.panel);
      _pageCleanups.add(() => { src = null; swatches.replaceChildren(); });
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * GIF 通用：解码一个动图，缓存帧供预览与再次导出
   * ------------------------------------------------------------------ */
  function bGifZone(onDecoded) {
    return DropZone({
      accept: 'image/gif,.gif', multiple: false,
      title: '把 GIF 动图拖到这里', sub: '需要 Chrome 108+ / Safari 17+ 的逐帧解码能力',
      async onFiles(files) {
        if (!files.length) { onDecoded(null, null, ''); return; }
        const f = files[0];
        if ((extOf(f.name) || '').toLowerCase() !== 'gif') {
          onDecoded(null, f, '这不是 .gif 文件，请先转成 GIF 再来');
          return;
        }
        try {
          const data = await decodeGifFrames(f);
          onDecoded(data, f, '');
        } catch (e) {
          onDecoded(null, f, e.message || '解析失败');
        }
      },
    });
  }

  function bFramesToData(frames, W, H, transform) {
    return frames.map((f) => {
      if (!transform) return f.canvas.getContext('2d').getImageData(0, 0, W, H);
      const { canvas, ctx } = newCanvas(W, H);
      ctx.drawImage(f.canvas, 0, 0);
      transform(ctx, W, H, f);
      const im = ctx.getImageData(0, 0, W, H);
      canvas.width = 0; canvas.height = 0;
      return im;
    });
  }

  function bGifError(data, file, info) {
    if (data) return null;
    if (typeof ImageDecoder === 'undefined') return '当前浏览器不支持逐帧解码 GIF（需要 Chrome 108+ / Safari 17+）';
    if (info) return info;
    if (file && (extOf(file.name) || '').toLowerCase() !== 'gif') return '请拖入 .gif 动图';
    return '请先拖入一个有效的 .gif 动图';
  }

  /* ------------------------------------------------------------------ *
   * 10 / GIF 倒放
   * ------------------------------------------------------------------ */
  tool({
    id: 'gif-reverse', cat: 'media', name: 'GIF 倒放', ico: 'gif', priority: 29,
    desc: '把 GIF 帧顺序反过来重新编码，也可做正放接倒放的来回循环，画面不重新压缩',
    tags: ['gif', '倒放', '反转', '逆向', '来回', 'pingpong', '循环', '动图'],
    takes: ['image'], forFormats: ['gif'],
    mount(root, ctx) {
      let data = null, srcFile = null, err = '';
      const info = h('div.hint', { style: { marginTop: '8px' }, role: 'status', 'aria-live': 'polite' }, '先拖入一个 GIF 动图');
      const mode = bSeg({
        label: '播放方式', value: 'reverse',
        options: [{ value: 'reverse', label: '纯倒放' }, { value: 'pingpong', label: '来回循环' }],
      });
      const colors = Field.select({
        label: '色数', value: '256',
        options: [
          { value: '256', label: '256 色 — 最好' }, { value: '128', label: '128 色' },
          { value: '64', label: '64 色 — 体积更小' },
        ],
      });
      const dz = bGifZone((d, f, e) => {
        data = d; srcFile = f; err = e;
        info.textContent = d
          ? `已解析 ${d.frames.length} 帧 · ${d.width} × ${d.height} · 总时长 ${d.frames.reduce((s, x) => s + x.delay, 0).toFixed(2)}s`
          : (e || '等待文件');
      });
      const ui = toolUI({
        zone: dz, opts: [mode, colors], extraTop: h('div', { style: { marginTop: '12px' } }, info),
        note: h('div.hint', { style: { marginTop: '10px' } },
          '倒放会重新编码 GIF；GIF 本身只有 256 色，反复编码会略微增加色阶损失，建议用 256 色。'),
        btnLabel: '生成倒放 GIF', cancelable: true,
        async onRun({ prog, res, signal }) {
          const problem = bGifError(data, srcFile, err);
          if (problem) throw new Error(problem);
          const { frames, width, height } = data;
          const reversed = frames.slice().reverse();
          const list = mode.get() === 'pingpong'
            ? frames.concat(frames.slice(1, -1).reverse()) : reversed;
          if (signal.aborted) throw new DOMException('已取消', 'AbortError');
          prog.set(20, '正在重排帧…');
          const imgs = bFramesToData(list, width, height);
          prog.set(45, '正在编码 GIF…');
          const blob = encodeGif({
            width, height, frames: imgs,
            delays: list.map((f) => Math.max(2, Math.round(f.delay * 100))),
            loop: 0, maxColors: Number(colors.get()),
            onProgress: (i, n) => prog.set(45 + (i / n) * 50, `编码 ${i} / ${n}`),
          });
          prog.set(100);
          const dur = list.reduce((s, f) => s + f.delay, 0);
          res.show([{
            name: bOut(srcFile.name, mode.get() === 'pingpong' ? '来回' : '倒放', 'gif'),
            blob,
            note: `${width} × ${height} · ${list.length} 帧 · ${dur.toFixed(2)}s · ${fmtBytes(blob.size)}`,
          }], { title: `✓ 已生成 ${list.length} 帧倒放 GIF` });
          setTimeout(() => prog.hide(), 400);
        },
      });
      root.appendChild(ui.panel);
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * 11 / GIF 加文字
   * ------------------------------------------------------------------ */
  function bWrapLines(c, text, maxW) {
    const lines = [];
    for (const raw of String(text || '').split('\n')) {
      let cur = '';
      for (const ch of raw) {
        if (c.measureText(cur + ch).width > maxW && cur) { lines.push(cur); cur = ch; }
        else cur += ch;
      }
      lines.push(cur);
    }
    return lines.slice(0, 6);
  }

  tool({
    id: 'gif-text', cat: 'media', name: 'GIF 加文字', ico: 'gif', priority: 30,
    desc: '在 GIF 每一帧上叠加同一段文字或水印，支持字号、位置、描边与透明度，中文不会乱码',
    tags: ['gif', '加字', '字幕', '水印', '表情包', '文字', '动图', 'caption'],
    takes: ['image'], forFormats: ['gif'],
    mount(root, ctx) {
      let data = null, srcFile = null, err = '';
      const info = h('div.hint', { style: { marginTop: '8px' }, role: 'status', 'aria-live': 'polite' }, '先拖入一个 GIF 动图');
      const text = Field.text({ label: '文字内容', value: '黑点工具', placeholder: '支持换行，最多 6 行', hint: '会叠加到每一帧' });
      const size = Field.number({ label: '字号', value: 28, min: 8, max: 160, step: 1, unit: 'px' });
      const color = bColor('文字颜色', '#ffffff', () => {});
      const pos = bSeg({
        label: '位置', value: 'bottom',
        options: [{ value: 'top', label: '顶部' }, { value: 'center', label: '居中' }, { value: 'bottom', label: '底部' }],
      });
      const font = Field.select({
        label: '字体', value: 'sans',
        options: [
          { value: 'sans', label: '系统黑体' }, { value: 'serif', label: '宋体 / 衬线' },
          { value: 'mono', label: '等宽' },
        ],
      });
      const stroke = Field.toggle({ label: '加描边', checked: true, hint: '浅色文字在亮背景上更清楚' });
      const alpha = Field.slider({ label: '文字不透明度', min: 10, max: 100, value: 100, unit: '%' });
      const colors = Field.select({
        label: '色数', value: '256',
        options: [{ value: '256', label: '256 色' }, { value: '128', label: '128 色' }, { value: '64', label: '64 色' }],
      });
      const dz = bGifZone((d, f, e) => {
        data = d; srcFile = f; err = e;
        info.textContent = d ? `已解析 ${d.frames.length} 帧 · ${d.width} × ${d.height}` : (e || '等待文件');
      });
      const ui = toolUI({
        zone: dz, opts: [text, size, color, pos, font, stroke, alpha, colors],
        extraTop: h('div', { style: { marginTop: '12px' } }, info),
        note: h('div.hint', { style: { marginTop: '10px' } },
          '文字会烧进每一帧，导出后不可再编辑；帧数很多的 GIF 编码需要一点时间。'),
        btnLabel: '生成带字 GIF', cancelable: true,
        async onRun({ prog, res, signal }) {
          const problem = bGifError(data, srcFile, err);
          if (problem) throw new Error(problem);
          if (!String(text.get()).trim()) throw new Error('请填写要叠加的文字');
          const { frames, width, height } = data;
          const fs = clamp(Math.round(Number(size.get()) || 28), 8, 160);
          const stack = font.get() === 'serif' ? '"Songti SC", "SimSun", serif'
            : font.get() === 'mono' ? '"JetBrains Mono", Consolas, monospace'
              : '"PingFang SC", "Microsoft YaHei", system-ui, sans-serif';
          const v = { size: fs, color: color.get(), pos: pos.get(), font: stack, stroke: stroke.get(), alpha: Number(alpha.get()) / 100, text: text.get() };
          if (signal.aborted) throw new DOMException('已取消', 'AbortError');
          prog.set(15, '正在叠加文字…');
          const imgs = bFramesToData(frames, width, height, (c, W, H) => {
            c.font = `700 ${v.size}px ${v.font}`;
            c.textAlign = 'center'; c.textBaseline = 'middle';
            const lines = bWrapLines(c, v.text, W * 0.9);
            const lh = v.size * 1.25;
            let y = v.pos === 'top' ? v.size * 0.9 + lh / 2
              : v.pos === 'bottom' ? H - lines.length * lh + lh / 2 - v.size * 0.4
                : H / 2 - (lines.length - 1) * lh / 2;
            c.save();
            c.globalAlpha = v.alpha;
            if (v.stroke) {
              c.lineWidth = Math.max(2, v.size / 7);
              c.strokeStyle = 'rgba(0,0,0,.85)';
              c.lineJoin = 'round';
            }
            lines.forEach((line, i) => {
              const yy = y + i * lh;
              if (v.stroke) c.strokeText(line, W / 2, yy);
              c.fillStyle = v.color;
              c.fillText(line, W / 2, yy);
            });
            c.restore();
          });
          prog.set(50, '正在编码 GIF…');
          const blob = encodeGif({
            width, height, frames: imgs,
            delays: frames.map((f) => Math.max(2, Math.round(f.delay * 100))),
            loop: 0, maxColors: Number(colors.get()),
            onProgress: (i, n) => prog.set(50 + (i / n) * 46, `编码 ${i} / ${n}`),
          });
          prog.set(100);
          res.show([{
            name: bOut(srcFile.name, '加字', 'gif'), blob,
            note: `${width} × ${height} · ${frames.length} 帧 · ${fmtBytes(blob.size)}`,
          }], { title: `✓ 已为 ${frames.length} 帧叠加文字` });
          setTimeout(() => prog.hide(), 400);
        },
      });
      root.appendChild(ui.panel);
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * 12 / GIF 转视频（MediaRecorder + captureStream(0)，无 ffmpeg.wasm）
   * ------------------------------------------------------------------ */
  function bVideoMime() {
    if (typeof MediaRecorder === 'undefined') return null;
    const list = [
      'video/mp4;codecs=avc1.42E01E', 'video/mp4;codecs=avc1',
      'video/mp4', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm',
    ];
    return list.find((m) => MediaRecorder.isTypeSupported(m)) || null;
  }

  tool({
    id: 'gif-to-video', cat: 'media', name: 'GIF 转 MP4 / WebM', ico: 'video', priority: 31,
    desc: '把 GIF 动图录成 MP4 或 WebM 视频，保留每帧时长，不需要上传也不需要下载编码引擎',
    tags: ['gif', '转mp4', '转视频', 'webm', '动图转视频', 'mediaRecorder'],
    takes: ['image', 'video'], forFormats: ['gif', 'mp4', 'webm'],
    mount(root, ctx) {
      let data = null, srcFile = null, err = '';
      const info = h('div.hint', { style: { marginTop: '8px' }, role: 'status', 'aria-live': 'polite' }, '先拖入一个 GIF 动图');
      const fpsCap = Field.select({
        label: '最短帧间隔', value: '40',
        options: [
          { value: '20', label: '20 ms（更贴原速）' }, { value: '40', label: '40 ms（推荐）' },
          { value: '80', label: '80 ms（更稳）' },
        ],
        hint: '浏览器录制是实时的，过短的帧间隔容易丢帧',
      });
      const bg = Field.select({
        label: '背景', value: 'white',
        options: [{ value: 'white', label: '白色' }, { value: 'black', label: '黑色' }],
      });
      const dz = bGifZone((d, f, e) => {
        data = d; srcFile = f; err = e;
        if (d) {
          const dur = d.frames.reduce((s, x) => s + x.delay, 0);
          info.textContent = `已解析 ${d.frames.length} 帧 · ${d.width} × ${d.height} · 原时长 ${dur.toFixed(2)}s，录制大约需要同样久`;
        } else info.textContent = e || '等待文件';
      });
      const ui = toolUI({
        zone: dz, opts: [fpsCap, bg], extraTop: h('div', { style: { marginTop: '12px' } }, info),
        note: h('div.hint', { style: { marginTop: '10px' } },
          '用浏览器自带的录制接口逐帧重绘，录制耗时约等于动图时长，期间请保持页面在前台。浏览器不支持 MP4 编码时会自动导出 WebM。'),
        btnLabel: '开始录制', cancelable: true,
        async onRun({ prog, res, signal }) {
          const problem = bGifError(data, srcFile, err);
          if (problem) throw new Error(problem);
          const mime = bVideoMime();
          if (!mime) throw new Error('当前浏览器不支持 MediaRecorder 录制，建议使用最新版 Chrome 或 Edge');
          const { frames, width, height } = data;
          const W = bEven(width), H = bEven(height);
          const { canvas, ctx: c } = newCanvas(W, H);
          c.fillStyle = bg.get() === 'black' ? '#000000' : '#ffffff';
          c.fillRect(0, 0, W, H);
          c.drawImage(frames[0].canvas, 0, 0, W, H);
          const stream = canvas.captureStream(0);
          const track = stream.getVideoTracks()[0];
          let rec;
          try {
            rec = new MediaRecorder(stream, { mimeType: mime, videoBitsPerSecond: 4000000 });
          } catch (e) {
            track.stop();
            throw new Error('无法启动录制：' + (e.message || e));
          }
          const chunks = [];
          rec.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
          const stopped = new Promise((resolve) => { rec.onstop = resolve; });
          rec.start(200);
          const minDelay = Number(fpsCap.get()) / 1000;
          let acc = 0;
          const t0 = performance.now();
          for (let i = 0; i < frames.length; i++) {
            if (signal.aborted) { try { rec.stop(); } catch {} track.stop(); throw new DOMException('已取消', 'AbortError'); }
            c.fillStyle = bg.get() === 'black' ? '#000000' : '#ffffff';
            c.fillRect(0, 0, W, H);
            c.drawImage(frames[i].canvas, 0, 0, W, H);
            track.requestFrame?.();
            acc += Math.max(minDelay, frames[i].delay || 0.1);
            const wait = Math.max(0, t0 + acc * 1000 - performance.now());
            await new Promise((r) => setTimeout(r, wait));
            prog.set((i / frames.length) * 96, `录制 ${i + 1} / ${frames.length}`);
          }
          if (rec.state !== 'inactive') rec.stop();
          await stopped;
          track.stop();
          canvas.width = 0; canvas.height = 0;
          if (!chunks.length) throw new Error('没有录到视频数据，请换用 Chrome / Edge 再试');
          const outType = mime.split(';')[0];
          const ext = outType === 'video/mp4' ? 'mp4' : 'webm';
          const blob = new Blob(chunks, { type: outType });
          prog.set(100);
          res.show([{
            name: bOut(srcFile.name, '视频', ext), blob,
            note: `${W} × ${H} · ${frames.length} 帧 · ${ext.toUpperCase()} · ${fmtBytes(blob.size)}`,
          }], { title: '✓ 录制完成', summary: `输出 ${ext.toUpperCase()}，若浏览器不支持 MP4 编码会自动使用 WebM` });
          setTimeout(() => prog.hide(), 400);
        },
      });
      root.appendChild(ui.panel);
      if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
    },
  });

  /* ------------------------------------------------------------------ *
   * 差异化 SEO 正文：每页独立的 what / howto / scenarios / details / qa
   * ------------------------------------------------------------------ */
  Object.assign(SEO_CONTENT, {
    'image-adjust': {
      what: '图片调色与滤镜在浏览器里调整亮度、对比度、饱和度、色相和柔化程度，并提供黑白、复古、反色、暖调、冷调、鲜艳六种预设。参数可与预设叠加，边拖滑块边看预览，确认后再按原尺寸导出，支持一次处理多张。',
      howto: [
        '把 PNG / JPG / WebP 图片拖进输入框，可以一次选多张',
        '选择一个滤镜预设，或直接用滑块调整亮度、对比度、饱和度、色相与柔化模糊',
        '看上方预览确认效果，并选择输出格式与输出尺寸',
        '点「开始处理」，处理完逐张下载或点「下载 ZIP」打包',
      ],
      scenarios: [
        '照片偏暗或曝光过度，想快速拉回正常亮度',
        '电商图要和店铺整体色调统一，批量加一层暖调',
        '做海报时需要黑白底图或反色效果，又不想打开修图软件',
        '截图里有轻微隐私信息，先柔化再分享',
      ],
      details: [
        '输入：PNG / JPG / WebP，可批量；输出：PNG / JPG / WebP。',
        '导出默认保持原尺寸；长边超过 4096 px 的图会先等比缩小再处理，避免浏览器占用过多内存。',
        '滤镜使用 Canvas 2D 的 filter 属性，效果与浏览器渲染一致；不同浏览器的色彩管理可能让结果有细微差别。',
        'JPG 不支持透明，导出 JPG 时透明区域会填成白色；需要透明请选 PNG 或 WebP。',
      ],
      qa: [
        { q: '调色会损失画质吗？', a: '会重新编码一次。选 PNG 是无损的；选 JPG / WebP 是有损压缩，质量设为 92%，日常使用基本看不出来。想完全不重编码，可以只改元数据，用「图片 DPI 设置」那类工具。' },
        { q: '预设和滑块能一起用吗？', a: '能。预设本质是一组滤镜字符串，会先作用，再叠加亮度、对比度、饱和度、色相和模糊。全部调回中性值就等于只看预设。' },
        { q: '批量处理时每张都用同一组参数吗？', a: '是。参数对整批文件生效，预览显示的是第一张。若一批图明暗差异很大，建议分组处理。' },
        { q: '「柔化模糊」和马赛克一样吗？', a: '不一样。柔化模糊是高斯模糊，边缘会渐变；马赛克是块状像素化，属于「像素化与故障特效」那个工具。' },
        { q: '大图处理会不会让浏览器崩溃？', a: '默认限制长边 4096 px，逐张解码、逐张导出并立刻释放画布，不会把整批图同时留在内存里。仍建议一次不超过 30 张，或在「输出尺寸」里选 1920 px。' },
      ],
    },
    'image-effects': {
      what: '像素化与故障特效把整张图做成马赛克、RGB 色差、故障条带、扫描线或噪点效果，强度和像素块大小都能调。所有效果都在 Canvas 像素层面完成，导出后就是一张普通 PNG / JPG / WebP 图片。',
      howto: [
        '拖入一张或多张 PNG / JPG / WebP 图片',
        '选择特效类型：像素化、RGB 色差、故障条带、扫描线或噪点',
        '调整强度，像素化模式还可以指定像素块大小',
        '看预览后选输出格式，点「开始处理」下载',
      ],
      scenarios: [
        '做封面或海报时需要复古电视、赛博故障质感',
        '截图里有一小块敏感信息，用像素化整体遮挡后再发',
        '给表情包加色差和扫描线，做出老显示器效果',
        '设计稿需要一组颗粒噪点素材',
      ],
      details: [
        '输入：PNG / JPG / WebP，可批量；输出：PNG / JPG / WebP。',
        '故障条带与噪点含随机成分，同一个参数每次导出的画面不会完全相同。',
        '像素化是先降采样再放大，块越大越糊；输出尺寸仍是所选的图片尺寸，不会改变画布大小。',
        '处理在每张图自己的像素数据上进行，不会把整批图同时加载到内存。',
      ],
      qa: [
        { q: '这个和「图片标注与打码」有什么区别？', a: '标注工具是在图上画框、箭头和局部马赛克，适合遮挡某一块；这个工具是把整张图统一做成某种特效，适合风格化处理。' },
        { q: '像素块大小填多少合适？', a: '一般 8–20 px。人像遮挡建议 20 px 以上，做点阵风格可以用 4–8 px。预览就是最终效果的缩略版。' },
        { q: '为什么每次导出的故障效果不一样？', a: '故障条带和噪点按随机数生成，这是刻意的。需要完全一致的图，请选像素化、扫描线或 RGB 色差，或导出一次后重复使用同一个文件。' },
        { q: '导出会变成分层文件吗？', a: '不会。导出的是一张扁平化的普通图片，任何看图软件和浏览器都能打开。' },
      ],
    },
    'image-round': {
      what: '圆角与边框给图片切圆角、加描边、加四周留白和投影，还能指定背景色。导出的是带透明通道的 PNG，圆角外侧可以保持透明，适合做头像、卡片封面和商品图。',
      howto: [
        '拖入一张或多张 PNG / JPG / WebP 图片',
        '设圆角半径、四周留白和边框宽度，再选边框颜色',
        '按需打开投影，或给圆角外侧铺一层背景色',
        '确认预览后点「开始处理」，导出 PNG 保留透明',
      ],
      scenarios: [
        '把方形头像切成圆角，放进产品卡片里',
        '给商品截图加一圈细描边和留白，直接贴进公众号',
        '做 App 图标预览，需要圆角加投影',
        '批量给一组封面图切统一圆角',
      ],
      details: [
        '输入：PNG / JPG / WebP，可批量；输出：PNG / JPG / WebP。',
        '输出尺寸 = 原图尺寸 + 两侧留白，圆角半径、边框宽度和留白会按预览缩放比例等比显示。',
        '透明只在 PNG / WebP 有效；导出 JPG 或选择白色背景时会把圆角外侧填白。',
        '投影画在图片下方，需要留白大于 0 才看得完整。',
      ],
      qa: [
        { q: '为什么导出的图比原图大？', a: '因为加了四周留白。把「四周留白」设成 0 就只切圆角，输出尺寸与原图一致。' },
        { q: '圆角外侧怎么保持透明？', a: '背景选「透明（仅 PNG）」，输出格式选 PNG。选 JPG 时透明区域会被填成白色，这是 JPEG 格式本身的限制。' },
        { q: '圆角半径有上限吗？', a: '有。半径会自动夹到短边的一半，也就是最大只能切成正圆或胶囊形，不会出现负尺寸。' },
        { q: '和「图片裁剪」有什么不同？', a: '裁剪是改变取景范围；圆角只改变四个角的形状，不裁掉画面内容。' },
      ],
    },
    'image-overlay': {
      what: '图片叠加混合把一张底图和一张叠加图按正常、正片叠底、滤色、叠加、变暗、变亮或差值模式合成一张，可调叠加图的不透明度、缩放和对齐位置，常用于双重曝光与光影贴图。',
      howto: [
        '在第一格放入底图，它决定最终输出的尺寸',
        '在第二格放入叠加图，支持带透明通道的 PNG',
        '选择混合模式，调整不透明度、缩放百分比和对齐位置',
        '看预览后点「合成并导出」，选择 PNG / JPG / WebP',
      ],
      scenarios: [
        '给照片叠一层光斑或纹理，做双重曝光效果',
        '把Logo半透明压在封面图右下角',
        '用正片叠底把线稿压到纸张纹理上',
        '两张同机位照片做差值，检查画面变化',
      ],
      details: [
        '输入：两张 PNG / JPG / WebP 图片；输出：单张 PNG / JPG / WebP。',
        '输出尺寸完全跟随底图；叠加图按指定百分比相对底图缩放，再按所选位置对齐。',
        '「铺满拉伸」会忽略宽高比，把叠加图直接拉到与底图同尺寸。',
        '导出 JPG 时会先铺白底，否则半透明区域在 JPEG 里无法表示。',
      ],
      qa: [
        { q: '两个输入框分别放什么？', a: '第一个是底图，决定画布大小，永远铺满；第二个是叠加图，盖在上方，可以缩放、移动、调透明度。' },
        { q: '正片叠底和滤色怎么选？', a: '正片叠底 overall 变暗，适合压纹理和阴影；滤色 overall 变亮，适合加光斑、火焰和高光。拿不准就用「正常」加不透明度。' },
        { q: '叠出来的图颜色不对？', a: '不同混合模式对透明像素的处理不同。叠加图有透明区域时，建议导出 PNG，或把背景设成白色，避免 JPG 填白后颜色突变。' },
        { q: '一次能合成多张吗？', a: '这个页面一次合成两张。多张请分几次操作，或用「图片拼接」做并排拼接。' },
      ],
    },
    'svg-to-png': {
      what: 'SVG 转 PNG 把 SVG 源码或 .svg 文件在浏览器里栅格化成 PNG / JPG / WebP，可指定输出宽高、锁定宽高比、按 1×–4× 倍数放大，并选择透明或自定义背景色。矢量放大不会糊。',
      howto: [
        '拖入 .svg 文件，或直接在源码框里粘贴 SVG 文本',
        '填输出宽度（0 表示用 SVG 自身尺寸），按需锁定宽高比',
        '选择额外倍数和背景，预览确认后点「渲染并导出」',
        '下载 PNG / JPG / WebP，文件名会带上实际像素尺寸',
      ],
      scenarios: [
        '前端拿到 SVG 图标，需要导出 2× / 3× 的 PNG 给设计或 App 用',
        '把在线图表导出的 SVG 转成可插入 PPT 的位图',
        '给 SVG 二维码加白底，方便打印',
        '批量把设计稿里的矢量元素转成固定尺寸素材',
      ],
      details: [
        '输入：.svg 文件或粘贴的 SVG 源码；输出：PNG / JPG / WebP，最大 8192 × 8192 px。',
        '会自动补 xmlns 和 width / height 属性，避免浏览器按默认的 300 × 150 渲染。',
        'SVG 里的外链图片、外部字体和脚本出于浏览器安全策略不会加载，复杂素材请先内嵌或转成路径。',
        '只处理当前一份源码；多个文件请逐个转换。',
      ],
      qa: [
        { q: '为什么转出来是 300 × 150？', a: '通常是 SVG 既没有 width / height 也没有 viewBox。本页面会从 viewBox 推断尺寸并补写属性；如果两者都缺，会按 512 × 512 兜底。建议在源码里明确写 viewBox。' },
        { q: '放大 4× 会糊吗？', a: '不会。SVG 是矢量，先按目标尺寸重新栅格化，不是把小图拉大，所以 4× 依然锐利。' },
        { q: 'SVG 里的图片没显示？', a: '浏览器禁止 SVG 作为图片加载时再请求外链资源。请把图片转成 data URI 内嵌，或把文字转成路径。' },
        { q: 'JPG 能透明吗？', a: '不能。选 JPG 时无论背景怎么设，都会铺白底；要透明请选 PNG 或 WebP 并把背景设为透明。' },
      ],
    },
    'image-dpi': {
      what: '图片 DPI 设置读取并修改 PNG 的 pHYs 块、JPEG 的 JFIF APP0 段里的分辨率元数据，可设成 72 / 96 / 150 / 300 / 600 或任意自定义值。只改一个元数据字段，像素一个都不动。',
      howto: [
        '拖入一张或多张 PNG / JPEG 图片',
        '看提示里显示的当前 DPI，没有写入过时多数软件按 72 或 96 处理',
        '选目标 DPI 预设，或切到「自定义」填数值',
        '点「写入 DPI」，下载带新 DPI 的文件',
      ],
      scenarios: [
        '投稿或印刷要求 300 DPI，但导出工具默认写了 72',
        '扫描件要按实际尺寸打印，需要正确的分辨率元数据',
        '设计交付前统一一批图片的 DPI 标记',
        '核对某个文件到底有没有写 DPI',
      ],
      details: [
        '输入：PNG / JPEG，可批量；输出：同格式、同像素、同编码数据。',
        'PNG 写在 pHYs 块（单位：每米像素数），JPEG 写在 JFIF APP0 段（单位：每英寸点数）。',
        'WebP、GIF 没有通用的标准 DPI 字段，会被跳过并在结果里提示数量。',
        'DPI 只影响「按物理尺寸打印」时的换算，不会让图片在屏幕上变大或变清晰。',
      ],
      qa: [
        { q: '改成 300 DPI 会让图片更清晰吗？', a: '不会。DPI 只是写在文件里的一句说明，像素数量完全不变，画质也不会变。想更清晰只能重新采样或重新导出更高分辨率。' },
        { q: '为什么 Photoshop 里看到的还是 72？', a: '有些软件优先用自己的默认 DPI 或缓存了旧值。请用文件属性或 exiftool 之类工具复核 pHYs / JFIF 字段，必要时重新打开文件。' },
        { q: '会压缩或重新编码图片吗？', a: '不会。这个工具直接复制原始字节，只插入或替换一个元数据块，因此文件体积变化通常只有几十字节。' },
        { q: 'WebP 能设 DPI 吗？', a: '不能。WebP 没有像 PNG pHYs / JPEG JFIF 那样被广泛支持的分辨率字段，这个页面会跳过 WebP 文件。' },
      ],
    },
    'image-exif-edit': {
      what: 'EXIF 编辑与写入给 JPEG 照片添加拍摄时间、作者、版权声明、图片描述、设备厂商和型号等字段，用浏览器重建一个干净的 APP1 / EXIF 段，不重新编码像素数据。',
      howto: [
        '拖入一张或多张 JPEG 照片，可批量写入同一组字段',
        '填写拍摄时间（YYYY:MM:DD HH:MM:SS）、作者、版权等信息，至少填一项',
        '需要时可以点「填入当前时间」',
        '点「写入 EXIF」，下载带新元数据的 JPEG',
      ],
      scenarios: [
        '发布作品前统一补上作者和版权声明',
        '扫描或修复后的照片缺拍摄时间，补写便于归档',
        '批量给一组素材打上项目描述',
        '交付前把 GPS 等隐私字段清掉，只保留必要的版权信息',
      ],
      details: [
        '输入：JPEG（.jpg / .jpeg），可批量；输出：JPEG，像素数据原样复制。',
        '会移除原有的 APP1 / EXIF 段并重建，因此原照片的 GPS、曝光参数、缩略图等字段也会一并清除。',
        '写入的是 EXIF IFD0 常备的 ASCII 字段与 DateTimeOriginal，不涉及 ICC、XMP 和 IPTC。',
        'PNG / WebP 不走 EXIF 标准，本工具不处理。',
      ],
      qa: [
        { q: '和「图片 EXIF 查看与清除」有什么区别？', a: '那个页面是读出并清除已有元数据；这个页面是往里写新字段。两者都只处理 JPEG，且不会重新编码画面。' },
        { q: '写入后原来的 GPS 还在吗？', a: '不在。本工具重建整个 APP1 段，原有 GPS、快门光圈等都会清掉，请先用查看工具导出备份。只想去掉定位、保留其余信息的话请用清除工具。' },
        { q: '拍摄时间要怎么写？', a: '用 2026:11:15 10:30:00 这种格式，也接受 2026-11-15T10:30。留空就不写时间字段。' },
        { q: '中文作者名会乱码吗？', a: 'EXIF 的 ASCII 字段按规范只收 7 位字符。本工具把中文按 UTF-8 写入（现代软件可正常显示），并额外写一条带 UNICODE 标记的标准 UserComment，方便 ExifTool、Adobe 一类工具读取。个别仍按本地 ANSI 解析的老软件可能显示乱码，追求最大兼容性时建议用英文填写作者与版权。' },
        { q: '写入会损失画质吗？', a: '不会。工具只复制 JPEG 字节流并替换元数据段，图像压缩数据原封不动，画质和体积几乎不变。' },
      ],
    },
    'image-palette': {
      what: '图片配色提取从照片里统计主色，合并相近颜色后生成一张色卡 PNG、一份 CSS 自定义属性文件和一份 JSON 调色板。适合把一张参考图的色彩快速搬进设计稿。',
      howto: [
        '拖入一张 PNG / JPG / WebP 图片',
        '设提取颜色数（2–16），按需忽略纯白与纯黑',
        '选按占比或按色相排列，看下方色板和预览',
        '点「导出色卡与配色」，一次拿到 PNG、CSS 和 JSON 三个文件',
      ],
      scenarios: [
        '拿到一张喜欢的摄影作品，想抽出色系用在网页上',
        '品牌视觉要从产品图里提取主色',
        '做 PPT 或海报前先定一组协调的配色',
        '给前端整理一份可直接粘贴的 CSS 变量',
      ],
      details: [
        '输入：单张 PNG / JPG / WebP；输出：色卡 PNG + CSS 变量 + JSON 三个文件。',
        '颜色按 RGB 各 16 级分箱量化，取占比最高的若干组并合并相近色，结果是主色参考而非逐像素精确还原。',
        '透明像素与可选的纯白 / 纯黑会被排除，避免大面积背景占满整个色板。',
        '色卡按指定颜色数横向排列，每格底部标注 HEX 值。',
      ],
      qa: [
        { q: '提取得准吗？', a: '这是量化统计，不是色彩语义分析。大面积纯色、渐变主色会提取得很准；细节丰富、颜色分散的照片只能给到「主要色系」参考。' },
        { q: 'CSS 文件里是什么？', a: '一组 --palette-1 到 --palette-N 的自定义属性，直接粘到 :root 里就能用。JSON 里另外给了 RGB 数组，方便接到代码里。' },
        { q: '为什么有时少于设定的颜色数？', a: '如果图片颜色本来就单一，或合并相近色后剩下的组不足，就会少给几个。这是为了避免色板上出现一堆肉眼分不出的近似色。' },
        { q: '能一次处理多张图吗？', a: '这个页面一次一张，配色需要逐张确认。批量改图请用「图片批处理工作台」。' },
      ],
    },
    'image-color-replace': {
      what: '颜色替换与去背景按颜色容差找到接近指定色值的像素，把它们变成透明或换成另一种颜色，支持边缘柔化。适合处理纯色底的 Logo、图标和截图，导出带透明通道的 PNG 或 WebP。',
      howto: [
        '拖入一张或多张 PNG / JPG / WebP 图片',
        '填要替换的颜色（如白底 #ffffff），调整颜色容差',
        '选「变透明」或「换成指定色」，按需打开边缘柔化',
        '看预览后点「开始处理」，导出 PNG 或 WebP',
      ],
      scenarios: [
        '白底 Logo 要变成透明底，贴到深色页面上',
        '截图里的纯色块要统一换成品牌色',
        '商品图纯色背景需要快速去底',
        '把扫描件的大片底色清成透明',
      ],
      details: [
        '输入：PNG / JPG / WebP，可批量；输出：PNG / WebP（保留透明）。',
        '容差按 RGB 三维欧氏距离计算，0 表示只匹配完全相同颜色，数值越大命中范围越广。',
        '边缘柔化会让接近容差上限的像素按距离渐变透明，边缘比一刀切更自然。',
        '只按颜色判断，不理解物体轮廓：渐变背景、阴影、发丝和半透明边缘无法精确抠出。',
      ],
      qa: [
        { q: '这个能抠人像吗？', a: '不能。它只按颜色相似度判断，人像发丝、阴影、渐变背景都会误伤。复杂抠图请用带语义分割的专业工具。' },
        { q: '容差填多少合适？', a: '纯色底从 30–40 起步；JPG 压缩过的白底有噪点，可能要 50–70。一边看预览一边调，边缘发灰就调小。' },
        { q: '为什么导出的 PNG 里还有白边？', a: '通常是容差太小，没覆盖到抗锯齿产生的浅色过渡像素。适当调大容差或打开边缘柔化，让过渡区渐变透明。' },
        { q: '能导出 JPG 透明图吗？', a: '不能，JPEG 格式本身不支持透明。这个页面只提供 PNG 和 WebP 两种输出。' },
      ],
    },
    'gif-reverse': {
      what: 'GIF 倒放把动图的帧顺序反过来重新编码，也可以生成「正放 + 倒放」的来回循环版本。每帧画面数据原样使用，只调整顺序和显示时长，适合做循环表情包。',
      howto: [
        '拖入一个 .gif 动图，等待逐帧解析完成',
        '选「纯倒放」或「来回循环」，再选色数',
        '点「生成倒放 GIF」，等编码完成下载',
      ],
      scenarios: [
        '表情包想做正反来回循环，衔接更自然',
        '产品演示动图倒着放一遍，做成回退动画',
        '把一段动图的最后一帧变成开头',
        '做无缝循环素材时补齐反向段',
      ],
      details: [
        '输入：单个 .gif；输出：.gif。需要 Chrome 108+ / Safari 17+ 的 ImageDecoder 逐帧解码能力。',
        '「来回循环」会把除首尾外的帧反向拼在后面，避免衔接处重复停两帧。',
        '每帧的显示时长跟着帧一起反转，因此总时长与原图一致（来回模式约为两倍）。',
        'GIF 最多 256 色，重新编码会略微增加色阶损失，画质优先请选 256 色。',
      ],
      qa: [
        { q: '倒放后画质会变差吗？', a: '画面数据本身没变，但 GIF 重新编码要重新建调色板，可能有一点色阶损失。选 256 色、少反复编码就能基本看不出来。' },
        { q: '来回循环为什么不是两倍帧数？', a: '因为首尾帧只保留一次，否则衔接处会出现两帧静止。实际帧数约为 2N-2。' },
        { q: '提示不支持逐帧解码怎么办？', a: 'ImageDecoder 需要 Chrome 108+ / Safari 17+。请升级浏览器；也可以先用「GIF 工具箱」的拆帧模式把帧导出来，再手动排序合成。' },
        { q: '和「GIF 工具箱」的调速有什么区别？', a: '调速只改每帧显示时长，顺序不变；倒放改的是帧顺序。两者可以配合用：先倒放，再用工具箱调速。' },
      ],
    },
    'gif-text': {
      what: 'GIF 加文字在动图的每一帧上叠加同一段文字或水印，可设字号、颜色、位置、字体、描边和不透明度，中文正常显示。文字会烧进画面，导出后就是一支普通 GIF。',
      howto: [
        '拖入一个 .gif 动图，等待逐帧解析',
        '填文字内容（支持换行），设字号、颜色和位置',
        '按需打开描边、调整不透明度，选字体和色数',
        '点「生成带字 GIF」，等编码完成下载',
      ],
      scenarios: [
        '给表情包配一句固定台词',
        '给演示动图加版权水印，转发也不掉',
        '做循环字幕动图',
        '给团队内部的动图素材统一打标签',
      ],
      details: [
        '输入：单个 .gif；输出：.gif。需要 Chrome 108+ / Safari 17+ 的 ImageDecoder 逐帧解码能力。',
        '文字按帧绘制，输出尺寸与原 GIF 一致；过长会自动换行，最多显示 6 行。',
        '描边用深色半透明轮廓，让浅色文字在亮背景上仍然可读。',
        '文字会被烧进像素，导出后不能再编辑或关闭；请保留原始 GIF 备份。',
      ],
      qa: [
        { q: '中文会乱码吗？', a: '不会。直接用系统字体绘制，中文、英文和 emoji 都按浏览器字形渲染；不同系统字体略有差别。' },
        { q: '能给不同帧写不同文字吗？', a: '这个页面给所有帧叠加同一段文字。要做逐帧字幕，可以先用「GIF 工具箱」拆帧，逐张加字后再合成。' },
        { q: '帧数很多会不会很慢？', a: '会。每帧都要绘制并重新编码，几百帧的 GIF 可能需要几十秒。页面有进度和取消按钮，中途可以停。' },
        { q: '文字位置偏了怎么办？', a: '顶部 / 底部位置按字数和字号自动算行高，最多 6 行。字特别大或行特别多时建议减小字号，避免超出画布。' },
      ],
    },
    'gif-to-video': {
      what: 'GIF 转 MP4 / WebM 用浏览器自带的录制接口把动图逐帧重绘成视频，保留每帧显示时长，不需要上传到服务器，也不需要下载几十 MB 的编码引擎。浏览器不支持 MP4 编码时会自动改用 WebM。',
      howto: [
        '拖入一个 .gif 动图，记下提示里的原时长',
        '选择最短帧间隔（默认 40 ms）和背景色',
        '点「开始录制」，保持页面在前台，等待约一个动图时长',
        '录制完成下载 MP4 或 WebM 文件',
      ],
      scenarios: [
        '网页里 GIF 体积太大，换成 MP4 省流量',
        '要把表情包发到只收视频的平台',
        '动图要放进 PPT 或剪辑软件，需要视频格式',
        '给动图配一段固定背景色再转视频',
      ],
      details: [
        '输入：单个 .gif；输出：MP4 或 WebM（取决于浏览器支持的录制格式）。',
        '录制是实时的：逐帧重绘并按原帧间隔等待，总耗时约等于动图时长，期间请保持页面在前台。',
        '输出宽高会取偶数值，部分编码器要求偶数边长。',
        '没有使用 ffmpeg.wasm，因此不会下载额外编码引擎；但也意味着无法精确控制码率与逐帧时间戳。',
      ],
      qa: [
        { q: '为什么导出的是 WebM 不是 MP4？', a: '取决于浏览器是否支持 H.264 的 MediaRecorder 编码。Chrome / Edge 新版本通常支持 MP4，不支持时页面会自动回退到 WebM，结果区会写明实际格式。' },
        { q: '为什么要等那么久？', a: '因为用的是实时录制，不是离线转码，每一帧都要按原来的显示时长真实等待。想更快可以选更大的「最短帧间隔」，但会轻微改变播放速度。' },
        { q: '录出来有丢帧吗？', a: '帧间隔特别短（低于 20 ms）时浏览器可能合并帧。默认 40 ms 是兼顾流畅与稳定的值，卡顿设备可以选 80 ms。' },
        { q: '这个和「视频转 GIF」是反过来的吗？', a: '方向相反但原理不同。「视频转 GIF」把视频帧编码成 GIF；这里把 GIF 帧录成视频。两者都在浏览器本地完成。' },
      ],
    },
  });
})();
