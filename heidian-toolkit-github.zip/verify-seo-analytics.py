import os
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')
import os
from pathlib import Path
from html.parser import HTMLParser
from urllib.parse import urlsplit, unquote
from xml.etree import ElementTree as ET
from collections import Counter
import json, mimetypes
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).parent
DIST = ROOT / 'dist'
class Head(HTMLParser):
    def __init__(self):
        super().__init__();self.metas={};self.links={};self.title='';self.in_title=False;self.in_ld=False;self.ld=[];self.buf='';self.scripts=[];self.h1=0
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='meta': self.metas[a.get('name',a.get('property',''))]=a.get('content','')
        if tag=='link': self.links[a.get('rel','')]=a.get('href','')
        if tag=='title':self.in_title=True
        if tag=='h1':self.h1+=1
        if tag=='script':
            if a.get('src'): self.scripts.append(a['src'])
            self.in_ld=a.get('type')=='application/ld+json';self.buf=''
    def handle_data(self,data):
        if self.in_title:self.title+=data
        if self.in_ld:self.buf+=data
    def handle_endtag(self,tag):
        if tag=='title':self.in_title=False
        if tag=='script' and self.in_ld:self.ld.append(json.loads(self.buf));self.in_ld=False
report={'static':[],'analytics_cases':[],'errors':[],'unexpected_assets':[],'external_analytics_requests_sent':0}
canonicals=[]
for file in sorted(DIST.rglob('*.html')):
    s=file.read_text(encoding='utf-8');h=Head();h.feed(s);is404=file.relative_to(DIST).as_posix() in ['404.html','404/index.html']
    assert h.title and h.metas.get('description') and h.links.get('canonical'),file
    assert sum(x.endswith('/analytics.js') for x in h.scripts)==1,file
    assert h.scripts.index(next(x for x in h.scripts if x.endswith('/analytics.js'))) < h.scripts.index(next(x for x in h.scripts if x.endswith('/app.js'))),file
    assert 'hm.baidu.com/hm.js?' not in s,file
    if is404:assert 'noindex' in h.metas['robots']
    else:
        assert h.h1==1 and h.ld,file
        assert 'index,follow' in h.metas['robots'],file
        assert h.metas.get('og:title') and h.metas.get('twitter:card'),file
        canonicals.append(h.links['canonical'])
    report['static'].append({'path':file.relative_to(DIST).as_posix(),'canonical':h.links['canonical'],'analytics':True,'indexable':not is404,'structured_data':bool(h.ld)})
assert len(set(canonicals))==len(canonicals),'Duplicate canonicals'
sitemap=ET.parse(DIST/'sitemap.xml')
locations=[n.text for n in sitemap.findall('.//{http://www.sitemaps.org/schemas/sitemap/0.9}loc')]
assert set(locations)==set(canonicals),{'missing':list(set(canonicals)-set(locations)),'extra':list(set(locations)-set(canonicals))}
assert 'Sitemap: https://example.com/sitemap.xml' in (DIST/'robots.txt').read_text(encoding='utf-8')
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
    context=browser.new_context(service_workers='block',viewport={'width':1280,'height':900})
    # Analytics is disabled in the open-source build; inject a dummy ID so
    # the PV queue logic can be verified. All provider requests are mocked above.
    context.add_init_script("window.HEIDIAN_ANALYTICS_ID='test-only';")
    def serve(route):
        u=urlsplit(route.request.url)
        if u.hostname=='hm.baidu.com':
            route.fulfill(status=200,content_type='application/javascript',body='window.__mockBaiduLoaded=true;');return
        if u.hostname not in ['hddtool.test','127.0.0.1']:
            route.abort();return
        file=DIST / unquote(u.path).lstrip('/')
        if file.is_dir():file=file/'index.html'
        if not file.is_file():
            report['unexpected_assets'].append(route.request.url);route.fulfill(status=404,body='Not found');return
        route.fulfill(status=200,content_type=mimetypes.guess_type(str(file))[0] or 'application/octet-stream',body=file.read_bytes())
    context.route('**/*',serve)
    page=context.new_page();page.on('pageerror',lambda e:report['errors'].append(str(e)))
    page.goto('https://hddtool.test/');page.wait_for_selector('.ui-sidebar')
    queue=page.evaluate('window._hmt');assert queue==[['_setAutoPageview',False],['_trackPageview','/']],queue
    page.locator('.ui-side-nav a[data-ui-key=image]').click()
    page.locator('a.card[href="/image/compress/"]').click()
    page.wait_for_selector('.tool-hd h1')
    assert page.locator('link[rel=canonical]').get_attribute('href')=='https://example.com/image/compress/'
    page.go_back();page.wait_for_timeout(80)
    queue=page.evaluate('window._hmt')
    expected=[['_setAutoPageview',False],['_trackPageview','/'],['_trackPageview','/image/'],['_trackPageview','/image/compress/'],['_trackPageview','/image/']]
    assert queue==expected,queue
    page.evaluate("window.dispatchEvent(new CustomEvent('toolkit:pageview',{detail:{path:'/image/'}}))")
    assert page.evaluate('window._hmt')==expected,'Repeated same route duplicated PV'
    report['analytics_cases'].append({'name':'Initial view, two SPA links, back navigation and duplicate suppression','queue':queue,'pass':True})
    for path in ['/image/annotate/','/image/batch/','/image/favicon/','/image/svg-optimize/','/text/code-format/']:
        page.goto('https://hddtool.test'+path)
        page.wait_for_selector('.ui-sidebar')
        assert page.evaluate('window._hmt')==[['_setAutoPageview',False],['_trackPageview',path]],path
        report['analytics_cases'].append({'name':'Previously uncovered page '+path,'pass':True})
    page.goto('https://hddtool.test/dev/timestamp/?secret=not-for-analytics#private')
    assert page.evaluate('window._hmt')==[['_setAutoPageview',False],['_trackPageview','/dev/timestamp/']]
    report['analytics_cases'].append({'name':'Tracking excludes URL query strings and fragments','pass':True})
    page.goto(BASE + '/')
    assert page.evaluate('typeof window._hmt')=='undefined'
    report['analytics_cases'].append({'name':'Local preview does not initialize analytics','pass':True})
    browser.close()
assert not report['errors'],report['errors']
assert not report['unexpected_assets'],report['unexpected_assets']
report['summary']={'html_pages':len(report['static']),'indexable_pages':len(canonicals),'sitemap_urls':len(locations),'tracking_coverage':len(report['static']),'analytics_browser_cases':len(report['analytics_cases']),'page_errors':len(report['errors']),'real_analytics_requests':0,'online_dashboard_verified':False}
(ROOT/'seo-analytics-verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report['summary'],ensure_ascii=False))
print('All code-level SEO/analytics checks passed; provider dashboard and live deployment remain unverified.')
