"""End-to-end verification for the 12 B-tier tools.

Every case injects a REAL file through the actual DropZone file chooser, clicks
the real primary button, captures the produced Blob(s) via the global download()
hook, and inspects the bytes with Pillow / binary parsing. A page that merely
renders without errors is NOT considered passing.
"""
from pathlib import Path as _P
if not (_P(__file__).parent / '.test-fixtures').exists():
    raise SystemExit('缺少测试素材：请在仓库根目录创建 .test-fixtures/ 并放入测试图片；该目录不随仓库分发，见 README「测试」章节。')

import os
from pathlib import Path
import base64
import io
import json
import re
import struct
from PIL import Image, ImageDraw
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
FIX = ROOT / '.test-fixtures'
FIX.mkdir(exist_ok=True)
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')

# ---------------------------------------------------------------- fixtures
W, H = 320, 240
base = Image.new('RGB', (W, H), 'white')
d = ImageDraw.Draw(base)
d.rectangle([40, 30, 150, 110], fill=(198, 79, 48))
d.rectangle([170, 90, 290, 200], fill=(42, 96, 140))
d.ellipse([110, 130, 210, 225], fill=(238, 190, 70))
png = FIX / 'b-src.png'
jpg = FIX / 'b-src.jpg'
base.save(png)
base.save(jpg, quality=94)

over = Image.new('RGBA', (W, H), (0, 0, 0, 0))
d2 = ImageDraw.Draw(over)
d2.ellipse([80, 40, 240, 200], fill=(80, 190, 120, 150))
over_png = FIX / 'b-over.png'
over.save(over_png)

svg = '''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 200 100">
  <rect width="200" height="100" fill="#b64f30"/>
  <circle cx="100" cy="50" r="34" fill="#f6f3ec"/>
</svg>'''
(FIX / 'b-src.svg').write_text(svg, encoding='utf-8')

# 6-frame animation: each frame has a distinct flat colour + a moving square
frames = []
colors = [(220, 70, 60), (70, 160, 220), (90, 200, 110), (240, 200, 70), (150, 90, 210), (40, 60, 80)]
for i, c in enumerate(colors):
    im = Image.new('RGB', (120, 90), c)
    dd = ImageDraw.Draw(im)
    dd.rectangle([i * 15, 25, i * 15 + 22, 55], fill=(255, 255, 255))
    frames.append(im)
gif = FIX / 'b-anim.gif'
frames[0].save(gif, save_all=True, append_images=frames[1:], duration=100, loop=0, disposal=2)

report = {'cases': [], 'errors': []}


def log(name, **kw):
    report['cases'].append({'name': name, **kw})
    print('  ', name, json.dumps(kw, ensure_ascii=False))


def arm(page):
    """Override the global download() so produced Blobs stay inspectable."""
    page.evaluate("""() => {
      window.__B_BLOBS__ = [];
      window.download = (blob, name) => { window.__B_BLOBS__.push({ blob, name }); };
    }""")


def add_file(page, path, index=0):
    with page.expect_file_chooser() as fc:
        page.locator('.dz').nth(index).click()
    fc.value.set_files(str(path))
    page.wait_for_timeout(450)


def run(page, path):
    page.locator('[data-primary-actions] button').first.click()
    page.locator('.workspace-results.on').wait_for(timeout=45000)
    names = page.locator('.workspace-results .file-name').all_inner_texts()
    return names


def blobs(page):
    """Click every real 下载 button, then pull the captured bytes into Python."""
    page.evaluate("""() => {
      [...document.querySelectorAll('.workspace-results .result-i button')]
        .filter(b => b.textContent.trim() === '下载')
        .forEach(b => b.click());
    }""")
    data = page.evaluate("""async () => Promise.all(window.__B_BLOBS__.map(async ({blob, name}) => {
      const u = new Uint8Array(await blob.arrayBuffer());
      let bin = '';
      for (let i = 0; i < u.length; i += 0x8000) bin += String.fromCharCode.apply(null, u.subarray(i, i + 0x8000));
      return { name, type: blob.type, size: blob.size, b64: btoa(bin) };
    }))""")
    return [(x['name'], x['type'], base64.b64decode(x['b64'])) for x in data]


def open_img(raw):
    return Image.open(io.BytesIO(raw))


def seg(page, label, value):
    page.evaluate("""({label, value}) => {
      const o = [...document.querySelectorAll('div.opt')].find(e =>
        e.querySelector(':scope > label')?.textContent.trim().startsWith(label));
      const b = [...o.querySelectorAll('.seg button')].find(x => x.dataset.v === value);
      b.click();
    }""", {'label': label, 'value': value})


def set_number(page, label, value):
    page.evaluate("""({label, value}) => {
      const o = [...document.querySelectorAll('div.opt')].find(e =>
        e.querySelector(':scope > label')?.textContent.trim().startsWith(label));
      const i = o.querySelector('input');
      i.value = String(value);
      i.dispatchEvent(new Event('input', { bubbles: true }));
    }""", {'label': label, 'value': value})


def set_text(page, label, value):
    page.evaluate("""({label, value}) => {
      const o = [...document.querySelectorAll('div.opt')].find(e =>
        e.querySelector(':scope > label')?.textContent.trim().startsWith(label));
      const i = o.querySelector('input');
      i.value = value;
      i.dispatchEvent(new Event('input', { bubbles: true }));
    }""", {'label': label, 'value': value})


def set_select(page, label, value):
    page.evaluate("""({label, value}) => {
      const o = [...document.querySelectorAll('div.opt')].find(e =>
        e.querySelector(':scope > label')?.textContent.trim().startsWith(label));
      const s = o.querySelector('select');
      s.value = value;
      s.dispatchEvent(new Event('change', { bubbles: true }));
    }""", {'label': label, 'value': value})


with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
    ctx = browser.new_context(viewport={'width': 1280, 'height': 900}, accept_downloads=True)
    page = ctx.new_page()
    page.on('pageerror', lambda e: report['errors'].append('PAGEERROR: ' + str(e)))
    page.on('console', lambda m: report['errors'].append('CONSOLE: ' + m.text) if m.type == 'error' else None)

    def goto(path):
        page.goto(BASE + path, wait_until='domcontentloaded')
        page.wait_for_selector('.dz')
        arm(page)

    # 1 ------------------------------------------------------------- 调色
    goto('/image/adjust/')
    add_file(page, png)
    seg(page, '滤镜预设', 'gray')
    run(page, '/image/adjust/')
    name, typ, raw = blobs(page)[0]
    im = open_img(raw).convert('RGB')
    px = [im.getpixel((x, y)) for x, y in [(60, 50), (200, 130), (160, 180)]]
    assert name.endswith('.jpg') and im.size == (W, H), (name, im.size)
    assert all(max(c) - min(c) <= 6 for c in px), px
    log('图片调色与滤镜', output=name, size=im.size, grayscale_samples=px)

    # 2 ------------------------------------------------------------- 特效
    goto('/image/effects/')
    add_file(page, png)
    set_number(page, '像素块大小', 16)
    run(page, '/image/effects/')
    name, typ, raw = blobs(page)[0]
    im = open_img(raw).convert('RGB')
    assert name.endswith('.png') and im.size == (W, H)
    orig = open_img(png.read_bytes()).convert('RGB')
    diff = sum(1 for y in range(0, H, 8) for x in range(0, W, 8)
               if im.getpixel((x, y)) != orig.getpixel((x, y)))
    assert diff > 20, diff
    log('像素化与故障特效', output=name, size=im.size, changed_samples=diff)

    # 3 ------------------------------------------------------------- 圆角
    goto('/image/round/')
    add_file(page, png)
    run(page, '/image/round/')
    name, typ, raw = blobs(page)[0]
    im = open_img(raw).convert('RGBA')
    assert im.size == (W + 48, H + 48), im.size
    assert im.getpixel((0, 0))[3] == 0, im.getpixel((0, 0))
    assert im.getpixel((im.width // 2, im.height // 2))[3] == 255
    log('圆角与边框', output=name, size=im.size, corner_alpha=0, center_alpha=255)

    # 4 ------------------------------------------------------------- 叠加
    goto('/image/overlay/')
    add_file(page, png, 0)
    add_file(page, over_png, 1)
    run(page, '/image/overlay/')
    name, typ, raw = blobs(page)[0]
    im = open_img(raw)
    assert name.endswith('.png') and im.size == (W, H), (name, im.size)
    log('图片叠加混合', output=name, size=im.size, bytes=len(raw))

    # 5 ------------------------------------------------------------- SVG
    goto('/image/svg-to-png/')
    page.locator('.editor textarea').fill(svg)
    set_number(page, '输出宽度', 400)
    page.wait_for_timeout(350)
    run(page, '/image/svg-to-png/')
    name, typ, raw = blobs(page)[0]
    im = open_img(raw)
    assert name.endswith('.png') and im.size == (400, 200), (name, im.size)
    assert im.convert('RGB').getpixel((10, 10))[0] > 150
    log('SVG 转 PNG', output=name, size=im.size)

    # 6 ------------------------------------------------------------- DPI
    goto('/image/dpi/')
    add_file(page, png)
    set_select(page, '目标 DPI', '300')
    run(page, '/image/dpi/')
    name, typ, raw = blobs(page)[0]
    im = open_img(raw)
    dpi = im.info.get('dpi')
    assert dpi and abs(dpi[0] - 300) < 1, dpi
    assert im.convert('RGB').tobytes() == base.tobytes(), 'pixels changed!'
    log('图片 DPI 设置', output=name, dpi=round(dpi[0], 2), pixels_unchanged=True)

    # 7 ------------------------------------------------------------- EXIF
    goto('/image/exif-edit/')
    add_file(page, jpg)
    set_text(page, '作者 / 摄影', '黑点工具测试')
    set_text(page, '拍摄时间', '2026:11:15 10:30:00')
    run(page, '/image/exif-edit/')
    name, typ, raw = blobs(page)[0]
    ex = open_img(raw).getexif()
    # Pillow decodes EXIF ASCII as latin-1; the file actually holds UTF-8.
    raw_artist = ex.get(315)
    artist = raw_artist.encode('latin-1').decode('utf-8') if isinstance(raw_artist, str) else raw_artist
    dt = ex.get(306)
    assert artist == '黑点工具测试', (artist, dict(ex))
    assert dt == '2026:11:15 10:30:00', dt
    uc = ex.get_ifd(34665).get(37510)      # 0x9286 UserComment
    assert uc and bytes(uc).startswith(b'UNICODE'), uc
    log('EXIF 编辑与写入', output=name, artist=artist, datetime=dt, user_comment=True)

    # 8 ------------------------------------------------------------- 配色
    goto('/image/palette/')
    add_file(page, png)
    run(page, '/image/palette/')
    got = blobs(page)
    assert len(got) == 3, [x[0] for x in got]
    css = next(x[2].decode('utf-8') for x in got if x[0].endswith('.css'))
    js = json.loads(next(x[2].decode('utf-8') for x in got if x[0].endswith('.json')))
    assert '--palette-1:' in css and len(js) >= 3
    card = open_img(next(x[2] for x in got if x[0].endswith('.png')))
    log('图片配色提取', outputs=[x[0] for x in got], colors=len(js), card=card.size, first=js[0]['hex'])

    # 9 ------------------------------------------------------------- 去背
    goto('/image/color-replace/')
    add_file(page, png)
    run(page, '/image/color-replace/')
    name, typ, raw = blobs(page)[0]
    im = open_img(raw).convert('RGBA')
    assert im.size == (W, H)
    assert im.getpixel((5, 5))[3] == 0, im.getpixel((5, 5))
    assert im.getpixel((80, 60))[3] == 255, im.getpixel((80, 60))
    log('颜色替换与去背景', output=name, corner_alpha=0, subject_alpha=255)

    # 10 ------------------------------------------------------------ 倒放
    goto('/media/gif-reverse/')
    add_file(page, gif)
    run(page, '/media/gif-reverse/')
    name, typ, raw = blobs(page)[0]
    out = open_img(raw)
    src = open_img(gif.read_bytes())
    assert out.n_frames == 6, out.n_frames
    out.seek(0); src.seek(5)
    a = out.convert('RGB').getpixel((5, 5))
    b = src.convert('RGB').getpixel((5, 5))
    assert sum(abs(x - y) for x, y in zip(a, b)) < 60, (a, b)
    log('GIF 倒放', output=name, frames=out.n_frames, first_frame=a, src_last=b)

    # 11 ------------------------------------------------------------ 加字
    goto('/media/gif-text/')
    add_file(page, gif)
    set_text(page, '文字内容', '黑点')
    run(page, '/media/gif-text/')
    name, typ, raw = blobs(page)[0]
    out = open_img(raw)
    assert out.n_frames == 6
    out.seek(0); src2 = open_img(gif.read_bytes()); src2.seek(0)
    o = out.convert('RGB'); s = src2.convert('RGB')
    diff = sum(1 for y in range(50, 90) for x in range(0, 120) if o.getpixel((x, y)) != s.getpixel((x, y)))
    assert diff > 30, diff
    log('GIF 加文字', output=name, frames=out.n_frames, changed_pixels=diff)

    # 12 ------------------------------------------------------------ 转视频
    goto('/media/gif-to-video/')
    add_file(page, gif)
    run(page, '/media/gif-to-video/')
    name, typ, raw = blobs(page)[0]
    assert name.endswith(('.webm', '.mp4')) and len(raw) > 1024, (name, len(raw))
    log('GIF 转视频', output=name, mime=typ, bytes=len(raw))

    browser.close()

assert not report['errors'], report['errors'][:6]
(ROOT / 'b-tools-verification.json').write_text(
    json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PASS', len(report['cases']), 'end-to-end cases | zero page errors')
