"""End-to-end check: a real image must actually process on the new preset pages."""
from pathlib import Path as _P
if not (_P(__file__).parent / '.test-fixtures').exists():
    raise SystemExit('缺少测试素材：请在仓库根目录创建 .test-fixtures/ 并放入测试图片；该目录不随仓库分发，见 README「测试」章节。')

import os
from pathlib import Path
import json
from PIL import Image, ImageDraw
import random
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
FIX = ROOT / '.test-fixtures'
FIX.mkdir(exist_ok=True)
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')

random.seed(2026)
img = Image.new('RGB', (800, 600))
px = img.load()
for y in range(600):
    for x in range(800):
        px[x, y] = ((x * 255) // 800, (y * 255) // 600, ((x + y) * 255) // 1400)
d = ImageDraw.Draw(img)
for _ in range(60):
    x, y = random.randrange(700), random.randrange(500)
    d.rectangle([x, y, x + random.randrange(20, 90), y + random.randrange(20, 90)],
                fill=(random.randrange(256), random.randrange(256), random.randrange(256)))
png = FIX / 'preset-test.png'
jpg = FIX / 'preset-test.jpg'
webp = FIX / 'preset-test.webp'
img.save(png)
img.save(jpg, quality=92)
img.save(webp, quality=90)

report = {'cases': [], 'errors': []}


def log(name, **kw):
    report['cases'].append({'name': name, **kw})
    print('  ', name, json.dumps(kw, ensure_ascii=False))


def run(page, path, file, expect_name=None, check_after_select=None):
    page.goto(BASE + path)
    page.wait_for_selector('.dz')
    page.wait_for_timeout(250)
    # DropZone creates its file input on demand, so drive the real chooser
    with page.expect_file_chooser() as fc:
        page.locator('.dz').first.click()
    fc.value.set_files(str(file))
    page.wait_for_timeout(600)
    if check_after_select:
        check_after_select(page)
    page.locator('[data-primary-actions] button').first.click()
    page.locator('.workspace-results.on').wait_for(timeout=30000)
    name = page.locator('.workspace-results .file-name').first.inner_text()
    meta = page.locator('.workspace-results .file-meta').first.inner_text() if page.locator('.workspace-results .file-meta').count() else ''
    if expect_name:
        assert expect_name(name), (path, name)
    return name, meta


with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
    ctx = browser.new_context(viewport={'width': 1280, 'height': 900}, accept_downloads=True)
    page = ctx.new_page()
    page.on('pageerror', lambda e: report['errors'].append(str(e)))

    # 1. exact pixel size must SURVIVE file selection (ctx.fixedSize hook)
    def size_survives(pg):
        v = pg.evaluate("""() => {
          const g = t => [...document.querySelectorAll('div.opt')]
            .find(e => e.querySelector(':scope > label')?.textContent.trim().startsWith(t))
            ?.querySelector('input');
          return [g('宽度')?.value, g('高度')?.value, g('锁定宽高比')?.checked];
        }""")
        assert v == ['512', '512', False], v

    n, m = run(page, '/image/resize-to-512x512/', png,
               expect_name=lambda s: '-512x512.' in s,
               check_after_select=size_survives)
    log('resize-to-512x512', file=n, meta=m[:60])

    # 2. target-KB compression really produces JPG under the target
    n, m = run(page, '/image/compress-to-500kb/', png,
               expect_name=lambda s: s.lower().endswith('.jpg'))
    assert 'KB' in m or 'B' in m, m
    log('compress-to-500kb', file=n, meta=m[:60])

    # 3. directed format conversion output is JPG
    n, m = run(page, '/image/png-to-jpg/', png,
               expect_name=lambda s: s.lower().endswith('.jpg'))
    log('png-to-jpg', file=n, meta=m[:60])

    # 4. WebP input on a format page
    n, m = run(page, '/image/to-png/', webp,
               expect_name=lambda s: s.lower().endswith('.png'))
    log('to-png (webp input)', file=n, meta=m[:60])

    browser.close()

assert not report['errors'], report['errors'][:5]
(ROOT / 'preset-function-verification.json').write_text(
    json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PASS', len(report['cases']), 'end-to-end cases, no page errors')
