"""Stress test the HEIC batch pipeline with real 12MP HEIC files (OOM regression)."""
from pathlib import Path as _P
if not (_P(__file__).parent / '.test-fixtures').exists():
    raise SystemExit('缺少测试素材：请在仓库根目录创建 .test-fixtures/ 并放入测试图片；该目录不随仓库分发，见 README「测试」章节。')

import os
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')

import os, time, json, psutil
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
FIX = ROOT / '.test-fixtures'
files = sorted(FIX.glob('iphone_*.heic'))[:20]
assert len(files) == 20, len(files)
payload = [{'name': p.name, 'mimeType': 'image/heic', 'buffer': p.read_bytes()} for p in files]
report = {'fixtures': len(payload), 'cases': [], 'errors': []}


def tree_rss():
    p = psutil.Process(os.getpid())
    total = p.memory_info().rss
    for c in p.children(recursive=True):
        try:
            total += c.memory_info().rss
        except Exception:
            pass
    return round(total / 1048576)


def run(label, edge, count=20):
    batch = payload[:count]
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
        page = browser.new_page(viewport={'width': 1440, 'height': 900})
        crashed = []
        page.on('crash', lambda _: crashed.append('CRASH'))
        page.on('pageerror', lambda e: report['errors'].append(str(e)))
        page.goto(BASE + '/image/heic/')
        page.wait_for_selector('.tool-hd h1')
        page.locator('select').nth(1).select_option(edge)
        with page.expect_file_chooser() as fc:
            page.locator('.dz').first.click()
        fc.value.set_files(batch)
        page.wait_for_timeout(250)
        base = tree_rss()
        started = time.time()
        page.get_by_role('button', name='转换所选照片', exact=True).click()
        peak = base
        for _ in range(150):
            page.wait_for_timeout(800)
            peak = max(peak, tree_rss())
            if page.locator('.workspace-results.on').count():
                break
        done = bool(page.locator('.workspace-results.on').count())
        rows = page.locator('.workspace-results .result-i').count()
        note = page.locator('.workspace-results .file-meta').first.inner_text() if done else ''
        head = page.locator('.workspace-results .result-hd').inner_text() if done else 'NOT_FINISHED'
        report['cases'].append({'label': label, 'count': count, 'edge': edge, 'done': done, 'rows': rows,
                                'seconds': round(time.time() - started, 1), 'peak_delta_mb': peak - base,
                                'crashed': bool(crashed), 'head': head, 'sample': note})
        print(f'{label}: done={done} rows={rows} {time.time()-started:.0f}s peak +{peak-base}MB crash={crashed} | {head} | {note}')
        browser.close()


run('20 张 · 默认 1920px', '1920')
run('20 张 · 保持原尺寸', '0')
assert not report['errors'], report['errors']
assert all(c['done'] and not c['crashed'] for c in report['cases'])
(ROOT / 'heic-stress-verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print('stress OK; peak deltas:', [c['peak_delta_mb'] for c in report['cases']])
