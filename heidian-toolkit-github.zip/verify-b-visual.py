"""Responsive / accessibility spot-check for the 12 B-tier tool pages."""
import os
from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parent
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')
PATHS = [
    '/image/adjust/', '/image/effects/', '/image/round/', '/image/overlay/',
    '/image/svg-to-png/', '/image/dpi/', '/image/exif-edit/', '/image/palette/',
    '/image/color-replace/', '/media/gif-reverse/', '/media/gif-text/',
    '/media/gif-to-video/',
]
WIDTHS = [320, 375, 768, 1440]
report = {'cases': [], 'overflows': [], 'errors': []}

with sync_playwright() as pw:
    browser = pw.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
    for width in WIDTHS:
        page = browser.new_page(viewport={'width': width, 'height': 900},
                                device_scale_factor=1)
        page.on('pageerror', lambda e: report['errors'].append(str(e)))
        page.goto(BASE + '/image/adjust/', wait_until='domcontentloaded')
        page.wait_for_selector('.tool-hd h1')
        for path in PATHS:
            got = page.evaluate("""(p) => {
              history.pushState(null, '', p); route();
              const opts = [...document.querySelectorAll('.opt')];
              return {
                overflow: document.documentElement.scrollWidth - window.innerWidth,
                opts: opts.length,
                unlabelled: opts.filter(o => !o.querySelector(':scope > label')).length,
                h1: !!document.querySelector('#app h1'),
                primaryH: document.querySelector('[data-primary-actions] button')?.getBoundingClientRect().height || 0,
                faq: document.querySelectorAll('.doc details').length,
              };
            }""", path)
            assert got['h1'] and got['opts'] >= 2, (path, got)
            assert got['faq'] >= 4, (path, got)
            if got['overflow'] > 1:
                report['overflows'].append({'width': width, 'path': path, 'px': got['overflow']})
            report['cases'].append({'width': width, 'path': path, **got})
        page.close()
        print('width', width, 'checked', len(PATHS), 'pages')

    # Delivery previews: desktop tool with preview canvas + mobile palette swatches
    d = browser.new_page(viewport={'width': 1440, 'height': 1000}, device_scale_factor=1)
    d.goto(BASE + '/image/adjust/', wait_until='domcontentloaded')
    d.wait_for_selector('.tool-hd h1')
    d.screenshot(path=str(ROOT / 'b-desktop.png'), full_page=False)
    d.close()

    m = browser.new_page(viewport={'width': 390, 'height': 844}, device_scale_factor=1)
    m.goto(BASE + '/image/palette/', wait_until='domcontentloaded')
    m.wait_for_selector('.tool-hd h1')
    m.screenshot(path=str(ROOT / 'b-mobile.png'), full_page=True)
    m.close()
    browser.close()

assert not report['overflows'], report['overflows'][:6]
assert not report['errors'], report['errors'][:5]
(ROOT / 'b-tools-visual-verification.json').write_text(
    json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print('PASS', len(report['cases']), 'responsive checks | 0 overflows | 2 screenshots')
