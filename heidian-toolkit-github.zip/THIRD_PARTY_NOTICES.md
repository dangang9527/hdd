# Third-Party Notices

本仓库的**源码**采用 MIT 许可，但运行时会按需从公共 CDN 加载以下第三方库。
本仓库**不包含**这些库的源码、WASM 二进制或打包产物；它们由使用者的浏览器
在打开对应工具时自行获取。各库的许可、版权与 NOTICE 以其上游仓库为准。

| 库 | 版本 | 用途 | 许可 | 上游 |
| --- | --- | --- | --- | --- |
| `heic-to` | 1.6.7 | HEIC / HEIF 解码（内含 libheif + libde265 WASM） | **LGPL-3.0** | [npm](https://www.npmjs.com/package/heic-to) |
| `pdfjs-dist` | 3.11.174 | PDF 渲染 | Apache-2.0 | [pdf.js](https://github.com/mozilla/pdf.js) |
| `pdf-lib` | 1.17.1 | PDF 生成与编辑 | MIT | [pdf-lib](https://github.com/Hopding/pdf-lib) |
| `lamejs` | 1.2.1 | MP3 编码 | **LGPL-3.0** | [lamejs](https://github.com/zhuker/lamejs) |
| `jsqr` | 1.4.0 | 二维码识别 | Apache-2.0 | [jsQR](https://github.com/cozmo/jsQR) |
| `qrcode-generator` | 1.4.4 | 二维码生成 | MIT | [qrcode-generator](https://github.com/kazuhikoarase/qrcode-generator) |
| `js-yaml` | 4.1.0 | YAML 转换 | MIT | [js-yaml](https://github.com/nodeca/js-yaml) |
| `marked` | 12.0.2 | Markdown 渲染 | MIT | [marked](https://github.com/markedjs/marked) |

`pdfjs-dist` 另可能经由 cdnjs 作为备用源加载，版本同为 3.11.174。

## LGPL-3.0 组件

`heic-to`（其 WASM 解码器来自 [libheif](https://github.com/strukturag/libheif) 与
[libde265](https://github.com/strukturag/libde265)，版权归 struktur AG 及各自贡献者）
和 `lamejs` 采用 LGPL-3.0。

本仓库按**固定 URL 在运行时动态加载**这些库，未把它们 vendored 进仓库、未修改、
也未与之静态链接，因此通常不构成随本仓库「再分发」该库。若你把它们下载进自己
的仓库、打进离线包或以其他方式随产品一并分发，需要自行履行 LGPL-3.0 义务，至少包括：

1. 随分发物提供 LGPL-3.0（及其引用的 GPL-3.0）许可文本与上游版权声明；
2. 提供对应源码或有效的获取途径（libheif / libde265 / lamejs 的上游仓库与构建脚本）；
3. 保证使用者可以用自己修改过的版本替换该库并正常运行——保持库以独立文件、
   可替换 URL 的形式加载，不要把它内联进不可替换的构建产物。

上游许可文本：<https://www.gnu.org/licenses/lgpl-3.0.html>、
<https://www.gnu.org/licenses/gpl-3.0.html>、
<https://www.apache.org/licenses/LICENSE-2.0>、
<https://opensource.org/license/mit>。

## 品牌资产

`dist/assets/logo.svg`、`og.png`、各尺寸 favicon / icon、站点名称与「黑点工具」
标识属于品牌素材，**不包含在 MIT 代码许可范围内**。使用本项目源码搭建自己的
站点时请替换为自有素材。

本站所有工具文案、FAQ、图标与 UI 排版均为原创，未复制任何第三方站点的内容、
源码或模型文件。
