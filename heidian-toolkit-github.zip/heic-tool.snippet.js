/* ---------- HEIC / HEIF 解码 ----------
 * iPhone 默认拍 HEIC。Chrome / Edge / Firefox 在多数平台上不能直接解码，
 * 所以这里先试一次原生解码（Safari、以及装了 HEIF 扩展的系统可以省掉 3 MB 下载），
 * 失败后才按需从 CDN 加载 libheif（wasm）引擎。文件本身不上传。
 */
async function decodeHeic(file) {
  try {
    const bitmap = await createImageBitmap(file);
    if (bitmap && bitmap.width) return { bitmap, via: 'native' };
  } catch { /* 大多数浏览器会走到引擎 */ }
  await loadLib('heic');
  const HeicTo = window.HeicTo;
  if (typeof HeicTo !== 'function') throw new Error('HEIC 解码引擎未就绪，请刷新页面重试');
  if (typeof HeicTo.isHeic === 'function') {
    let is = false;
    try { is = await HeicTo.isHeic(file); } catch { is = false; }
    if (!is) throw new Error('这个文件不是有效的 HEIC / HEIF（扩展名改了也不行）');
  }
  const bitmap = await HeicTo({ blob: file, type: 'bitmap' });
  if (!bitmap || !bitmap.width) throw new Error('HEIC 解码失败，文件可能损坏或是特殊编码');
  return { bitmap, via: 'engine' };
}

tool({
  id: 'image-heic',
  cat: 'image',
  name: 'HEIC 照片转换',
  ico: 'convert',
  priority: 2,
  desc: 'iPhone 的 HEIC / HEIF 照片转成 JPG、PNG 或 WebP，支持批量与打包下载',
  tags: ['heic', 'heif', 'iphone', '苹果', '照片', '转换', 'convert', 'jpg', 'png', 'webp', '批量'],
  takes: ['image'],
  forFormats: ['heic', 'heif'],
  faq: [
    { q: 'HEIC 是什么格式？', a: 'HEIC（HEIF 容器 + HEVC 编码）是 iPhone 从 iOS 11 起的默认照片格式，同画质下体积约为 JPG 的一半。Windows 与多数网站、聊天工具、老版安卓都认不出，转成 JPG 最稳妥。' },
    { q: '为什么提示要从 CDN 下载引擎？', a: 'Chrome、Edge、Firefox 一般不带 HEVC 解码能力，需要 libheif（WebAssembly，约 3 MB）来解。引擎只下载到你的浏览器并缓存，照片本身不发送到任何服务器。' },
    { q: '转成 JPG 会掉画质吗？', a: 'JPG 与 WebP 都是有损编码，质量设到 90% 以上肉眼几乎看不出差别；要给客户或存档、又不想有任何损失，就选 PNG，代价是体积大很多。' },
    { q: '实况照片、连拍会怎样？', a: '一个 HEIC 文件里通常只有一张主图，实况照片的视频部分独立存放，这里只导出静态主图；连拍的多帧若在同一文件中，取第一帧。' },
    { q: 'iPhone 怎么直接拍 JPG？', a: '设置 → 相机 → 格式 → 选「兼容性最佳」，之后新拍的照片就是 JPG；已经拍好的 HEIC 用这个工具批量转即可。' },
  ],
  mount(root, ctx) {
    const pv = previewBox({ title: '输出预览' });
    let pvCanvas = null;

    const dz = DropZone({
      accept: 'image/heic,image/heif,.heic,.heif',
      multiple: true,
      title: '把 iPhone 照片拖到这里',
      sub: 'HEIC / HEIF，可批量；一次几十张建议分批',
      onFiles(files) {
        if (!files.length) { pv.clear(); pvCanvas = null; }
      },
    });

    const qualityRow = h('div');
    const q = Field.slider({ label: '质量', min: 50, max: 100, value: 92, unit: '%', hint: '仅对 JPG / WebP 生效；PNG 无损' });
    qualityRow.appendChild(q.el);

    const fmt = Field.select({
      label: '输出格式',
      value: 'jpg',
      options: [
        { value: 'jpg', label: 'JPG（最通用，推荐）' },
        { value: 'png', label: 'PNG（无损，体积大）' },
        { value: 'webp', label: 'WebP（体积小，现代浏览器都认）' },
      ],
      onChange: (v) => {
        qualityRow.classList.toggle('hide', v === 'png');
        repaintPreview();
      },
    });

    const edge = Field.select({
      label: '最长边',
      value: '0',
      options: [
        { value: '0', label: '保持原尺寸' },
        { value: '4096', label: '缩到 4096 px' },
        { value: '2560', label: '缩到 2560 px' },
        { value: '1920', label: '缩到 1920 px' },
        { value: '1280', label: '缩到 1280 px' },
      ],
      hint: '只缩不放；缩图能明显减小体积',
      onChange: () => repaintPreview(),
    });

    async function repaintPreview() {
      if (!pvCanvas) return;
      const f = fmt.get();
      const canvas = drawToCanvas(pvCanvas, {
        width: pvCanvas.width, height: pvCanvas.height,
        bg: f === 'png' ? null : '#ffffff',
      });
      const blob = await exportCanvas(canvas, f, q.get() / 100);
      const label = f.toUpperCase();
      pv.set(canvas, `预览 · 输出 ${label}${f === 'png' ? '' : ` 质量 ${q.get()}%`}　约 ${fmtBytes(blob.size)}`);
    }

    const ui = toolUI({
      zone: dz,
      opts: [fmt, edge, qualityRow],
      btnLabel: '转换所选照片',
      extraTop: libNote('heic'),
      extra: pv.el,
      note: h('div.note', { html: ICONS.info },
        h('span', null, '解码与编码都在本机完成，照片不上传。首次使用需联网加载约 3 MB 的解码引擎，之后走浏览器缓存。')),
      async onRun({ prog, res }) {
        const files = dz.get();
        if (!files.length) throw new Error('请先选择 HEIC 照片');
        if (files.length > 200) throw new Error(`一次最多 200 张，当前 ${files.length} 张`);
        const total = files.reduce((n, f) => n + f.size, 0);
        if (total > 800 * 1024 * 1024) throw new Error('总大小超过 800 MB，请分批转换');

        const f = fmt.get();
        const qv = q.get() / 100;
        const maxEdge = +edge.get();
        const out = [];
        const failed = [];

        for (let i = 0; i < files.length; i++) {
          const file = files[i];
          prog.set((i / files.length) * 100, `正在转换 ${i + 1} / ${files.length}`);
          try {
            const { bitmap } = await decodeHeic(file);
            const canvas = drawToCanvas(bitmap, { maxEdge: maxEdge || undefined });
            bitmap.close?.();
            const src = f === 'png' ? canvas : drawToCanvas(canvas, { width: canvas.width, height: canvas.height, bg: '#ffffff' });
            const blob = await exportCanvas(src, f, qv);
            out.push({
              name: `${baseOf(file.name)}.${f}`,
              blob,
              note: `${fmtBytes(file.size)} → ${fmtBytes(blob.size)} · ${canvas.width}×${canvas.height}`,
            });
            if (!pvCanvas && canvas) {
              pvCanvas = drawToCanvas(canvas, { maxEdge: 900 });
              repaintPreview();
            }
          } catch (e) {
            failed.push(`${file.name}：${e?.message || e}`);
          }
        }

        prog.set(100);
        if (!out.length) throw new Error(`全部转换失败。${failed[0] || '请确认文件是 iPhone 拍摄的 HEIC'}`);
        const title = failed.length
          ? `✓ 完成 ${out.length} 张，${failed.length} 张没转成功`
          : `✓ 完成 ${out.length} 张`;
        res.show(out, {
          title,
          summary: failed.length ? failed.slice(0, 3).join('；') + (failed.length > 3 ? '…' : '') : null,
        });
        setTimeout(() => prog.hide(), 400);
      },
    });

    root.appendChild(ui.panel);
    if (ctx.prefill) dz.dz.addFiles(ctx.prefill);
  },
});

