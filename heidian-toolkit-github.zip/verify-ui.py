import os
from pathlib import Path
import base64, json
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).parent
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')
report = {'responsive': [], 'checks': [], 'tool_routes': [], 'errors': [], 'asset_failures': []}
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
    context = browser.new_context(viewport={'width': 1440, 'height': 1000}, service_workers='block')
    page = context.new_page()
    page.on('pageerror', lambda e: report['errors'].append(str(e)))
    page.on('response', lambda r: report['asset_failures'].append({'url':r.url,'status':r.status}) if r.status >= 400 and r.url.startswith(BASE) else None)
    page.goto(BASE)
    page.wait_for_selector('.ui-showcase')
    paths = page.evaluate('TOOLS.map(t=>t.path)')
    for width in [320, 390, 768, 1024, 1440, 1920]:
        page.set_viewport_size({'width': width, 'height': 1000 if width > 760 else 844})
        page.goto(BASE)
        page.wait_for_selector('.ui-showcase')
        measurement = page.evaluate('({width:innerWidth,scrollWidth:document.documentElement.scrollWidth,nav:!!document.querySelector(".ui-bottom-nav")})')
        measurement['pass'] = measurement['scrollWidth'] <= width
        report['responsive'].append(measurement)
    page.set_viewport_size({'width':1440, 'height':1000})
    page.goto(BASE)
    page.screenshot(path=str(ROOT/'desktop-preview.png'))
    page.locator('#homeSearch').fill('时间戳')
    page.wait_for_timeout(250)
    assert '时间戳' in page.locator('#homeResults').inner_text()
    report['checks'].append('Homepage live search returns matching tools')
    page.locator('#searchBtn').click()
    page.locator('#searchInput').fill('时间戳')
    page.wait_for_timeout(180)
    assert '时间戳' in page.locator('#searchList').inner_text()
    page.locator('#searchInput').press('Enter')
    page.wait_for_timeout(120)
    assert '/dev/timestamp/' in page.url
    report['checks'].append('Global search and Enter navigation work')
    page.goto(BASE+'/text/json-format/')
    page.locator('textarea').first.fill(json.dumps({'hello':'黑点工具','version':2026}, ensure_ascii=False))
    page.get_by_role('button',name='转换',exact=True).click()
    output = page.locator('textarea').nth(1).input_value()
    assert json.loads(output)['version'] == 2026
    report['checks'].append('JSON formatting produces valid formatted output')
    page.screenshot(path=str(ROOT/'desktop-tool-preview.png'))
    page.locator('textarea').first.fill('{broken')
    page.get_by_role('button',name='转换',exact=True).click()
    assert page.locator('.errbox.on').count() > 0
    report['checks'].append('Invalid JSON displays an explicit error state')
    page.goto(BASE+'/image/compress/')
    data = page.evaluate('''() => {const c=document.createElement('canvas');c.width=320;c.height=200;const x=c.getContext('2d');x.fillStyle='#b64f30';x.fillRect(0,0,320,200);x.fillStyle='#f7f7f2';x.fillRect(32,32,256,136);return c.toDataURL('image/png').split(',')[1]}''')
    with page.expect_file_chooser() as chooser:
        page.locator('.dz').first.click()
    chooser.value.set_files({'name':'ui-test.png','mimeType':'image/png','buffer':base64.b64decode(data)})
    page.get_by_role('button',name='开始压缩',exact=True).click()
    page.wait_for_timeout(800)
    page.get_by_role('button',name='下载',exact=True).wait_for()
    with page.expect_download() as download:
        page.get_by_role('button',name='下载',exact=True).click()
    assert download.value.suggested_filename.endswith('.webp')
    report['checks'].append('Image selection, local compression and WebP download work')
    for path in paths:
        page.goto(BASE+path,wait_until='domcontentloaded')
        page.wait_for_timeout(55)
        assert page.locator('.ui-sidebar').count() == 1
        assert page.locator('.tool-hd h1').count() == 1
        assert not page.locator('.errbox.on').count(), path
        report['tool_routes'].append({'path':path,'title':page.locator('.tool-hd h1').inner_text(),'pass':True})
    page.set_viewport_size({'width':390,'height':844})
    page.goto(BASE)
    page.wait_for_selector('.ui-showcase')
    page.screenshot(path=str(ROOT/'mobile-preview.png'))
    page.locator('.ui-bottom-nav button').first.click()
    assert page.locator('.ui-mobile-sheet').is_visible()
    page.screenshot(path=str(ROOT/'mobile-categories-preview.png'))
    page.locator('.ui-sheet-panel a[data-ui-key=pdf]').click()
    page.wait_for_timeout(100)
    assert '/pdf/' in page.url
    assert not page.locator('.ui-mobile-sheet').is_visible()
    assert not page.locator('#app').evaluate('(e)=>e.inert')
    report['checks'].append('Mobile category sheet opens, navigates and restores focus/background access')
    page.goto(BASE+'/image/compress/')
    page.screenshot(path=str(ROOT/'mobile-tool-preview.png'))
    page.locator('#themeBtn').click()
    assert page.locator('html').get_attribute('data-theme') == 'dark'
    page.screenshot(path=str(ROOT/'dark-tool-preview.png'))
    page.reload()
    assert page.locator('html').get_attribute('data-theme') == 'dark'
    page.locator('#themeBtn').click()
    report['checks'].append('Theme toggle works and preference persists across reload')
    for width in [320,390,768,1440]:
        page.set_viewport_size({'width':width,'height':900})
        for path in ['/image/compress/','/pdf/merge/','/text/json-format/','/dev/timestamp/','/media/audio-trim/']:
            page.goto(BASE+path)
            result=page.evaluate('({width:innerWidth,scrollWidth:document.documentElement.scrollWidth})')
            result['path']=path
            result['pass']=result['scrollWidth'] <= width
            report['responsive'].append(result)
    # Optional internal design showcase (not shipped here)
    if (ROOT/'design-overview.html').exists():
        page.goto((ROOT/'design-overview.html').as_uri())
        page.wait_for_load_state('load')
        assert page.locator('h1').inner_text() == '让小工具，得心应手。'
        assert page.locator('img').evaluate_all('(es)=>es.every(e=>e.complete && e.naturalWidth>0)')
    browser.close()
report['summary']={'tools_tested':len(report['tool_routes']),'interaction_checks':len(report['checks']),'viewport_checks':len(report['responsive']),'overflow_failures':sum(not r['pass'] for r in report['responsive']),'page_errors':len(report['errors']),'local_asset_failures':len(report['asset_failures'])}
(ROOT/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(report['summary'],ensure_ascii=False))
print(json.dumps(report['checks'],ensure_ascii=False))
print('ERRORS',report['errors'])
print('OVERFLOWS',[r for r in report['responsive'] if not r['pass']])
assert not report['errors']
assert not report['asset_failures']
assert all(r['pass'] for r in report['responsive'])
