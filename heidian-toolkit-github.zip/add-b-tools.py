"""B-tier real features (v7): 12 new standalone tools, prerender + SEO sync.

Unlike the A-tier preset pages, these are REAL entries in TOOLS: they show up
on the home page, category pages, search and sibling navigation. The catalogue
therefore grows 62 -> 74, and every static page carrying the counter is updated.

Usage:
  python add-b-tools.py inject    # app.js snippet + css + counters + sw version
  python add-b-tools.py render    # prerender every affected static page
  python add-b-tools.py sync      # sitemap / llms / llms-full
  python add-b-tools.py verify    # static + browser checks
  python add-b-tools.py pack      # zip v7
  python add-b-tools.py all
"""
import os
from pathlib import Path
import json
import re
import shutil
import sys
import zipfile

ROOT = Path(__file__).parent
DIST = ROOT / 'dist'
APP = DIST / 'assets' / 'app.js'
CSS = DIST / 'assets' / 'ui-2026.css'
SNIPPET = ROOT / 'b-tools.snippet.js'
SHELL = ROOT / 'preset-shell-template.html'
BASE = os.environ.get('SITE_BASE', 'http://127.0.0.1:8765')
ORIGIN = 'https://example.com'
TODAY = '2026-11-15'
OLD_COUNT, NEW_COUNT = 62, 74
SW_OLD, SW_NEW = '2026-11-13-preset-v1', '2026-11-15-btools-v1'

# (id, slug, cat) — name / desc / SEO copy comes from the live page at render time
B_PAGES = [
    ('image-adjust', 'adjust', 'image'),
    ('image-effects', 'effects', 'image'),
    ('image-round', 'round', 'image'),
    ('image-overlay', 'overlay', 'image'),
    ('svg-to-png', 'svg-to-png', 'image'),
    ('image-dpi', 'dpi', 'image'),
    ('image-exif-edit', 'exif-edit', 'image'),
    ('image-palette', 'palette', 'image'),
    ('image-color-replace', 'color-replace', 'image'),
    ('gif-reverse', 'gif-reverse', 'media'),
    ('gif-text', 'gif-text', 'media'),
    ('gif-to-video', 'gif-to-video', 'media'),
]
B_IDS = [x[0] for x in B_PAGES]
B_PATHS = [f'/{cat}/{slug}/' for _, slug, cat in B_PAGES]

EXTRA_CSS = """

/* ---- B 档新增控件：与 Quiet Utility 令牌保持一致 ---- */
.opt input[type=color]{width:100%;height:40px;padding:3px;border:1px solid var(--border);border-radius:var(--r-sm);background:var(--surface);color:var(--text);cursor:pointer}
.opt input[type=color]:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.b-palette-swatches{display:flex;flex-wrap:wrap;gap:10px;margin-top:14px}
.b-swatch{flex:1 1 74px;min-width:74px;display:flex;flex-direction:column;align-items:center;gap:6px}
.b-swatch i{display:block;width:100%;height:36px;border-radius:var(--r-sm);border:1px solid var(--border);box-shadow:var(--shadow)}
.b-swatch code{font-size:11.5px;color:var(--text-2);font-family:var(--mono,ui-monospace,Consolas,monospace);letter-spacing:0}
@media (max-width:640px){.b-swatch{flex:1 1 64px;min-width:64px}.b-swatch i{height:30px}}
"""

SEG_CSS = """
/* 选项较多的分段控件允许换行，避免窄屏横向溢出（只作用于 B 档页面） */
.opt.b-seg-wrap .seg{flex-wrap:wrap;gap:2px}
.opt.b-seg-wrap .seg button{flex:1 1 auto;min-width:max-content}
"""


def normalize_head(html, page_path):
    depth = len(page_path.relative_to(DIST).parts) - 1
    prefix = '../' * depth
    html = html.replace('http://127.0.0.1:8765/', prefix)
    # Stylesheet links are copied from the initial /image/convert/ DOM, so they
    # carry a hard-coded ../../ depth. Re-anchor them for the OUTPUT page depth.
    html = re.sub(r'(?:\.\./)+assets/(style\.css|ui-2026\.css)',
                  lambda m: prefix + 'assets/' + m.group(1), html)
    if '<head>' not in html[:1500]:
        m = re.search(r'<html[^>]*>', html)
        html = html[:m.end()] + '\n<head>' + html[m.end():]
        b = re.search(r'<body[^>]*>', html)
        html = html[:b.start()] + '</head>\n' + html[b.start():]
    return html


# --------------------------------------------------------------------------
def inject():
    app = APP.read_text(encoding='utf-8')
    if 'registerBTools()' in app:
        print('app.js already patched, skipping')
    else:
        anchor = '(function registerPresetPages() {'
        assert anchor in app, 'preset registration anchor missing'
        snippet = SNIPPET.read_text(encoding='utf-8')
        app = app.replace(anchor, snippet + '\n\n' + anchor, 1)
        APP.write_text(app, encoding='utf-8')
        print('injected', len(snippet.encode('utf-8')), 'bytes into app.js')

    css = CSS.read_text(encoding='utf-8')
    if '.b-palette-swatches' not in css:
        css = css.rstrip() + '\n' + EXTRA_CSS
        CSS.write_text(css, encoding='utf-8')
        print('appended B-tier component css')
    if '.b-seg-wrap' not in css:
        CSS.write_text(css.rstrip() + '\n' + SEG_CSS, encoding='utf-8')
        print('appended B-tier segmented-control css')

    # counter in every text-bearing file (footer / sidebar / llms / prose)
    changed = 0
    for p in sorted(DIST.rglob('*')):
        if not p.is_file() or p.suffix.lower() not in {'.html', '.htm', '.txt', '.xml', '.js', '.json'}:
            continue
        try:
            s = p.read_text(encoding='utf-8')
        except (UnicodeDecodeError, OSError):
            continue
        n = s.replace(f'{OLD_COUNT} 个工具', f'{NEW_COUNT} 个工具')
        if n != s:
            p.write_text(n, encoding='utf-8')
            changed += 1
    print(f'counter {OLD_COUNT} -> {NEW_COUNT} in {changed} files')

    sw = DIST / 'sw.js'
    s = sw.read_text(encoding='utf-8')
    if SW_OLD in s:
        sw.write_text(s.replace(SW_OLD, SW_NEW, 1), encoding='utf-8')
        print('sw cache:', SW_OLD, '->', SW_NEW)
    else:
        assert SW_NEW in s, 'sw version neither old nor new'
        print('sw cache already', SW_NEW)


# --------------------------------------------------------------------------
def collect_pages():
    paths = []
    for p in sorted(DIST.rglob('index.html')):
        rel = p.parent.relative_to(DIST).as_posix()
        path = '/' if rel == '.' else '/' + rel + '/'
        if path in ('/about/', '/404/'):     # prose pages: counter patched by inject()
            continue
        paths.append(path)
    return list(dict.fromkeys(paths + B_PATHS))


def render():
    from playwright.sync_api import sync_playwright
    assert SHELL.exists(), 'shell template missing'
    shell = SHELL.read_text(encoding='utf-8')
    paths = collect_pages()
    print('prerendering', len(paths), 'pages')

    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        page.goto(BASE + '/image/convert/')
        page.wait_for_selector('.tool-hd h1')
        total = page.evaluate('TOOLS.length')
        variants = page.evaluate('VARIANTS.length')
        assert total == NEW_COUNT, ('TOOLS', total)
        assert variants == 35, ('VARIANTS', variants)

        meta = page.evaluate("""(ids) => ids.map(id => {
          const t = toolById(id);
          return { id, name: t.name, desc: t.desc, cat: t.cat, path: t.path,
                   seo: SEO_CONTENT[id] };
        })""", B_IDS)
        assert len(meta) == len(B_IDS)
        for m in meta:
            assert m['name'] and m['seo'] and m['seo'].get('qa'), m['id']
        (ROOT / 'b-tools-seo.json').write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding='utf-8')
        print('collected live SEO data for', len(meta), 'tools')

        for i, path in enumerate(paths, 1):
            data = page.evaluate("""(p) => {
              history.pushState(null, '', p); route();
              return {
                h1: document.querySelector('h1')?.textContent || '',
                head: document.head.innerHTML,
                main: document.querySelector('#app').outerHTML,
                canonical: document.querySelector('link[rel="canonical"]')?.href || '',
                title: document.title
              };
            }""", path)
            assert data['canonical'] == ORIGIN + path, (path, data['canonical'])
            assert data['main'].startswith('<main'), path
            out = DIST / path.strip('/') / 'index.html'
            out.parent.mkdir(parents=True, exist_ok=True)
            base = out.read_text(encoding='utf-8') if out.exists() else shell
            head_start = base.index('<head>')
            head_open_end = base.index('>', head_start) + 1
            head_close = base.index('</head>', head_open_end)
            main_start = base.index('<main id="app"')
            main_end = base.index('</main>', main_start) + len('</main>')
            html = (base[:head_open_end] + data['head'] + '</head>'
                    + base[head_close + len('</head>'):main_start] + data['main'] + base[main_end:])
            out.write_text(normalize_head(html, out), encoding='utf-8')
            if i % 20 == 0 or i == len(paths):
                print(f'  rendered {i}/{len(paths)}')
        browser.close()
    assert not errors, errors[:5]
    print('prerendered', len(paths), 'pages, zero page errors')


# --------------------------------------------------------------------------
def full_section(m):
    seo = m['seo']
    cat = {'image': '图片', 'media': '音视频'}[m['cat']]
    s = f"## {m['name']}\n\nURL: {ORIGIN}{m['path']}\n分类: {cat}\n更新日期: {TODAY}\n\n{m['desc']}\n\n"
    s += '### 这个工具做什么\n\n' + seo['what'] + '\n\n'
    s += '### 怎么用\n\n' + ''.join(f'{i}. {x}\n' for i, x in enumerate(seo['howto'], 1)) + '\n'
    s += '### 适用场景\n\n' + ''.join('- ' + x + '\n' for x in seo['scenarios']) + '\n'
    s += '### 输入输出与限制\n\n' + ''.join(x + '\n\n' for x in seo['details'])
    s += '### 常见问题\n\n' + ''.join('#### ' + q['q'] + '\n\n' + q['a'] + '\n\n' for q in seo['qa'])
    s += '### 相关工具\n\n- [黑点工具首页](https://example.com/)：查看全部 74 个工具\n\n'
    return s


def sync():
    meta = json.loads((ROOT / 'b-tools-seo.json').read_text(encoding='utf-8'))

    sm = DIST / 'sitemap.xml'
    xml = sm.read_text(encoding='utf-8')
    anchor = '</urlset>'
    add = ''
    for m in meta:
        url = ORIGIN + m['path']
        if url in xml:
            continue
        add += f'  <url>\n    <loc>{url}</loc>\n    <lastmod>{TODAY}</lastmod>\n  </url>\n'
    sm.write_text(xml.replace(anchor, add + anchor, 1), encoding='utf-8')
    print('sitemap:', xml.count('<loc>'), '->', (DIST / 'sitemap.xml').read_text(encoding='utf-8').count('<loc>'))

    lt = DIST / 'llms.txt'
    txt = lt.read_text(encoding='utf-8')
    if '### 图片效果与动图工具' not in txt:
        txt = txt.rstrip() + '\n\n### 图片效果与动图工具（12 个）\n\n'
        for m in meta:
            txt += f"- [{m['name']}]({ORIGIN}{m['path']})：{m['desc']}\n"
        lt.write_text(txt, encoding='utf-8')
        print('llms.txt: +12 links')

    lf = DIST / 'llms-full.txt'
    full = lf.read_text(encoding='utf-8')
    marker = '\n## ' + meta[0]['name'] + '\n'
    if marker in full:
        full = full[:full.index(marker)]
    full = full.rstrip() + '\n\n'
    for m in meta:
        full += full_section(m)
    lf.write_text(full, encoding='utf-8')
    print('llms-full.txt: +12 full sections')


def fixall():
    fixed = 0
    for p in sorted(DIST.rglob('index.html')):
        s = p.read_text(encoding='utf-8')
        n = normalize_head(s, p)
        if n != s:
            p.write_text(n, encoding='utf-8')
            fixed += 1
    print('re-anchored head assets in', fixed, 'pages')


# --------------------------------------------------------------------------
def verify():
    from playwright.sync_api import sync_playwright
    meta = json.loads((ROOT / 'b-tools-seo.json').read_text(encoding='utf-8'))

    pages = sorted(DIST.rglob('index.html'))
    bad_url, bad_head, no_canon, no_schema = [], [], [], []
    for p in pages:
        s = p.read_text(encoding='utf-8')
        if '127.0.0.1:8765' in s: bad_url.append(str(p))
        if '<head>' not in s[:1500]: bad_head.append(str(p))
        if p.parent != DIST / '404' and 'rel="canonical"' not in s: no_canon.append(str(p))
        # 404 is deliberately noindex with no structured data
        if p.parent != DIST / '404' and 'application/ld+json' not in s: no_schema.append(str(p))
    app = APP.read_text(encoding='utf-8')
    sm = (DIST / 'sitemap.xml').read_text(encoding='utf-8')
    print('static pages:', len(pages), '| sitemap:', sm.count('<loc>'))
    print('bad localhost:', len(bad_url), '| missing head:', len(bad_head),
          '| no canonical:', len(no_canon), '| no schema:', len(no_schema))
    assert len(pages) == 117, len(pages)
    assert sm.count('<loc>') == 116, sm.count('<loc>')
    assert not bad_url and not bad_head and not no_canon and not no_schema
    assert 'registerBTools()' in app and '.b-palette-swatches' in CSS.read_text(encoding='utf-8')
    assert (DIST / 'sw.js').read_text(encoding='utf-8').count(SW_NEW) == 1
    assert not list(DIST.rglob('*62 个工具*')) and '62 个工具' not in (DIST / 'about/index.html').read_text(encoding='utf-8')

    with sync_playwright() as pw:
        browser = pw.chromium.launch(executable_path=os.environ.get('CHROME_PATH') or None)
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        errors = []
        page.on('pageerror', lambda e: errors.append(str(e)))
        checks = [
            '/', '/image/', '/media/', '/image/compress/', '/image/heic/',
            '/image/compress-to-100kb/', '/image/resize-to-512x512/',
        ] + B_PATHS
        for path in checks:
            page.goto(BASE + path, wait_until='domcontentloaded')
            page.wait_for_selector('#app h1', timeout=15000)
            got = page.evaluate("""() => ({
              title: document.title,
              canonical: document.querySelector('link[rel=canonical]')?.href || '',
              h1: document.querySelector('#app h1')?.textContent || '',
              schema: [...document.querySelectorAll('script[type="application/ld+json"]')].map(x=>x.textContent).join(' '),
              cards: document.querySelectorAll('.grid .card').length,
              analytics: !!document.querySelector('script[src*="analytics"]'),
              controls: document.querySelectorAll('.opt').length,
            })""")
            assert got['canonical'] == ORIGIN + path, (path, got['canonical'])
            assert got['h1'], path
            assert 'SoftwareApplication' in got['schema'] or path in ('/', '/image/', '/media/'), path
            assert got['analytics'], path
            if path in B_PATHS:
                assert 'HowTo' in got['schema'] and 'FAQPage' in got['schema'], path
                assert got['controls'] >= 2, (path, got['controls'])
            if path == '/':
                assert '74' in got['title'], got['title']
                print('home title:', got['title'])
            if path == '/image/':
                assert got['cards'] >= 29, got['cards']
                print('image category cards:', got['cards'])
            if path == '/media/':
                assert got['cards'] >= 9, got['cards']
                print('media category cards:', got['cards'])
        browser.close()
    assert not errors, errors[:5]
    print('browser checks:', len(checks), 'pages | zero page errors')
    print('STATIC + BROWSER VERIFY PASS')


# --------------------------------------------------------------------------
def pack():
    OUT = ROOT.parent / 'heidian-toolkit-ui-2026-btools-v7.zip'
    extras = [
        'add-b-tools.py', 'add-preset-pages.py', 'b-tools.snippet.js',
        'b-tools-seo.json', 'b-tools-release-notes.txt',
        'preset-shell-template.html', 'preset-pages-release-notes.txt',
        'deploy-checklist.txt', 'heic-release-notes.txt', 'heic-oom-fix-notes.txt',
        'design-overview.html', 'verify-b-tools.py', 'verify-b-visual.py',
        'b-tools-verification.json', 'b-tools-visual-verification.json',
        'b-desktop.png', 'b-mobile.png',
    ]
    files = [(p, 'dist/' + p.relative_to(DIST).as_posix()) for p in sorted(DIST.rglob('*'))
             if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.bak')]
    for name in extras:
        p = ROOT / name
        if p.exists():
            files.append((p, name))
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for src, arc in files:
            z.write(src, arc)
    z = zipfile.ZipFile(OUT)
    names = z.namelist()
    html = [n for n in names if n.startswith('dist/') and n.endswith('.html')]
    assert len(html) == 118, len(html)      # 117 index.html + 404.html? (see below)
    print('packed', OUT.name, OUT.stat().st_size, 'bytes,', len(files), 'files')


if __name__ == '__main__':
    steps = sys.argv[1:] or ['all']
    if 'all' in steps:
        steps = ['inject', 'render', 'fixall', 'sync', 'verify', 'pack']
    for step in steps:
        print('===', step, '===')
        {'inject': inject, 'render': render, 'fixall': fixall, 'sync': sync,
         'verify': verify, 'pack': pack}[step]()
